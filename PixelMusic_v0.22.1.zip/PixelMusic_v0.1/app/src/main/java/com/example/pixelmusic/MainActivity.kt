package com.example.pixelmusic

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.pixelmusic.ui.PixelMusicApp

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    private val songs = mutableListOf<MusicSong>()
    private val queue = mutableListOf<Int>()
    private var permissionGranted = false

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionGranted = granted
        if (granted) loadMusic()
        render()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) = render()
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = render()
        })
        permissionGranted = hasAudioPermission()
        if (permissionGranted) loadMusic() else requestAudioPermission()
        render()
    }

    private fun hasAudioPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        permissionLauncher.launch(permission)
    }

    private fun loadMusic() {
        songs.clear()
        songs += MusicRepository.querySongs(contentResolver)
        if (songs.isNotEmpty() && player.mediaItemCount == 0) {
            queue.clear()
            queue.addAll(songs.indices)
            player.setMediaItems(queue.map { MediaItem.fromUri(songs[it].uriString) })
            player.prepare()
        }
    }

    private fun render() {
        if (!::player.isInitialized) return
        val queueIndex = player.currentMediaItemIndex.coerceIn(0, (queue.size - 1).coerceAtLeast(0))
        val index = if (queue.isNotEmpty() && queueIndex in queue.indices) queue[queueIndex] else -1
        setContent {
            PixelMusicApp(
                    songs = songs.toList(),
                    currentIndex = if (songs.isEmpty()) -1 else index,
                    playing = player.isPlaying,
                    onSongClick = { i ->
                        if (i in songs.indices) {
                            val queuePosition = queue.indexOf(i)
                            if (queuePosition >= 0) player.seekToDefaultPosition(queuePosition)
                            else {
                                queue.add(i)
                                player.addMediaItem(MediaItem.fromUri(songs[i].uriString))
                                player.seekToDefaultPosition(queue.lastIndex)
                            }
                            player.play()
                            render()
                        }
                    },
                    onPlayPause = {
                        if (player.isPlaying) player.pause() else if (player.mediaItemCount > 0) player.play()
                        render()
                    },
                    onNext = { if (player.mediaItemCount > 0) player.seekToNextMediaItem(); player.play(); render() },
                    onPrevious = { if (player.mediaItemCount > 0) player.seekToPreviousMediaItem(); player.play(); render() },
                    positionProvider = { player.currentPosition },
                    durationProvider = { player.duration.takeIf { it != androidx.media3.common.C.TIME_UNSET } ?: 0L },
                    onSeekTo = { position -> player.seekTo(position) },
                    queueSongIndices = queue.toList(),
                    onQueueRemove = { queuePosition ->
                        if (queuePosition in queue.indices) {
                            player.removeMediaItem(queuePosition)
                            queue.removeAt(queuePosition)
                            render()
                        }
                    },
                    onQueueMove = { from, to ->
                        if (from in queue.indices && to in queue.indices && from != to) {
                            player.moveMediaItem(from, to)
                            val moved = queue.removeAt(from)
                            queue.add(to, moved)
                            render()
                        }
                    },
                    onQueueClear = {
                        player.clearMediaItems()
                        queue.clear()
                        render()
                    },
                    onQueueAdd = { songIndex ->
                        if (songIndex in songs.indices) {
                            queue.add(songIndex)
                            player.addMediaItem(MediaItem.fromUri(songs[songIndex].uriString))
                            if (player.playbackState == Player.STATE_IDLE) player.prepare()
                            render()
                        }
                    }
                )
        }
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}
