package com.example.pixelmusic

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer

/**
 * Headphone crossfeed: mixes a delayed, attenuated copy of each channel into the other.
 * Stereo PCM 16-bit / float only; other formats (e.g. mono) pass through unchanged
 * so playback never fails because of this processor.
 */
@UnstableApi
class CrossfeedAudioProcessor : BaseAudioProcessor() {

    @Volatile
    var enabled: Boolean = false

    /** 0f = off path, 1f = strong crossfeed (~40% mix). */
    @Volatile
    var strength: Float = 0.35f

    private var delaySamples: Int = 0
    private var delayL: FloatArray = FloatArray(0)
    private var delayR: FloatArray = FloatArray(0)
    private var delayIndex: Int = 0
    private var isFloat: Boolean = false
    /** false = always passthrough (mono / unsupported encoding). */
    private var canProcess: Boolean = false

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        // Always accept the format so the audio pipeline never fails on this processor.
        canProcess = inputAudioFormat.channelCount == 2 &&
            (inputAudioFormat.encoding == C.ENCODING_PCM_16BIT ||
                inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT)
        isFloat = inputAudioFormat.encoding == C.ENCODING_PCM_FLOAT
        if (canProcess) {
            delaySamples = (inputAudioFormat.sampleRate * 0.00035f).toInt().coerceAtLeast(1)
            delayL = FloatArray(delaySamples)
            delayR = FloatArray(delaySamples)
            delayIndex = 0
        } else {
            delaySamples = 0
            delayL = FloatArray(0)
            delayR = FloatArray(0)
            delayIndex = 0
        }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        if (!inputBuffer.hasRemaining()) return

        val active = canProcess && enabled && strength > 0.001f
        if (!active) {
            val out = replaceOutputBuffer(inputBuffer.remaining())
            out.put(inputBuffer)
            out.flip()
            return
        }

        val mix = (0.05f + strength.coerceIn(0f, 1f) * 0.35f)
        val direct = 1f - mix * 0.5f

        if (isFloat) {
            processFloat(inputBuffer, mix, direct)
        } else {
            processPcm16(inputBuffer, mix, direct)
        }
    }

    private fun processPcm16(inputBuffer: ByteBuffer, mix: Float, direct: Float) {
        val pairs = inputBuffer.remaining() / 4
        val out = replaceOutputBuffer(pairs * 4)
        var i = 0
        while (i < pairs) {
            val inL = inputBuffer.short.toInt() / 32768f
            val inR = inputBuffer.short.toInt() / 32768f

            val dL = delayL[delayIndex]
            val dR = delayR[delayIndex]
            delayL[delayIndex] = inL
            delayR[delayIndex] = inR
            delayIndex++
            if (delayIndex >= delaySamples) delayIndex = 0

            val outL = (inL * direct + dR * mix).coerceIn(-1f, 1f)
            val outR = (inR * direct + dL * mix).coerceIn(-1f, 1f)

            out.putShort((outL * 32767f).toInt().toShort())
            out.putShort((outR * 32767f).toInt().toShort())
            i++
        }
        out.flip()
    }

    private fun processFloat(inputBuffer: ByteBuffer, mix: Float, direct: Float) {
        val pairs = inputBuffer.remaining() / 8
        val out = replaceOutputBuffer(pairs * 8)
        var i = 0
        while (i < pairs) {
            val inL = inputBuffer.float
            val inR = inputBuffer.float

            val dL = delayL[delayIndex]
            val dR = delayR[delayIndex]
            delayL[delayIndex] = inL
            delayR[delayIndex] = inR
            delayIndex++
            if (delayIndex >= delaySamples) delayIndex = 0

            out.putFloat((inL * direct + dR * mix).coerceIn(-1f, 1f))
            out.putFloat((inR * direct + dL * mix).coerceIn(-1f, 1f))
            i++
        }
        out.flip()
    }

    override fun onFlush() {
        delayL.fill(0f)
        delayR.fill(0f)
        delayIndex = 0
    }

    override fun onReset() {
        delayL = FloatArray(0)
        delayR = FloatArray(0)
        delaySamples = 0
        delayIndex = 0
        canProcess = false
    }
}
