package com.example.pixelmusic

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.media.AudioManager
import android.media.audiofx.DynamicsProcessing
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import android.net.Uri
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.common.util.UnstableApi
import com.example.pixelmusic.ui.PixelMusicApp

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    private val songs = mutableListOf<MusicSong>()
    // Visible queue shown in the UI (kept independent from the playback playlist).
    private val queue = mutableListOf<Int>()
    // Song indices corresponding to the actual ExoPlayer playlist. In global shuffle mode
    // this contains the full library while the visible queue remains unchanged.
    private val playbackQueue = mutableListOf<Int>()
    /** Indices that define the current play scope (folder / artist / playlist / library). */
    private val activeScope = mutableListOf<Int>()
    private var permissionGranted = false
    private var dynamicsProcessing: DynamicsProcessing? = null
    private var equalizerEnabled = false
    private var equalizerAvailable = false
    private var equalizerGains = FloatArray(10) { 0f }
    private var masterVolumePercent = 100f
    private var enhancementEnabled = false
    private var enhancementMode = "natural"
    private var enhancementStrength = "medium"
    private val equalizerFrequencies = floatArrayOf(31f, 62f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f)

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionGranted = granted
        if (granted) {
            loadMusic()
            requestNotificationPermissionIfNeeded()
        }
        render()
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* media notification optional */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val audioPrefs = getSharedPreferences("pixelmusic_audio", MODE_PRIVATE)
        equalizerEnabled = audioPrefs.getBoolean("eq_enabled", false)
        masterVolumePercent = audioPrefs.getFloat("master_volume_percent", 100f).coerceIn(0f, 130f)
        equalizerGains = FloatArray(10) { i -> audioPrefs.getFloat("eq_band_$i", 0f).coerceIn(-10f, 10f) }
        enhancementEnabled = audioPrefs.getBoolean("enhancement_enabled", false)
        enhancementMode = audioPrefs.getString("enhancement_mode", "natural") ?: "natural"
        enhancementStrength = audioPrefs.getString("enhancement_strength", "medium") ?: "medium"
        if (enhancementStrength !in setOf("weak", "medium", "strong")) enhancementStrength = "medium"
        // Shared player + MediaSessionService so playback continues in the background
        // and the system media notification stays available.
        startService(Intent(this, PlaybackService::class.java))
        player = PlayerHolder.getOrCreate(this)
        player.volume = masterVolumePercent / 100f
        val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        val requestedSessionId = audioManager.generateAudioSessionId()
        if (requestedSessionId > 0) {
            runCatching {
                player.setAudioSessionId(requestedSessionId)
                initializeEqualizer(requestedSessionId)
            }.onFailure {
                equalizerAvailable = false
                dynamicsProcessing?.release()
                dynamicsProcessing = null
            }
        }
        player.addListener(object : Player.Listener {
            // Keep Compose controls synchronized with the player's intent as well as its
            // active playback state. Collection screens can initiate playback while the
            // player is briefly buffering, when isPlaying is still false.
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) ensurePlaybackService()
                render()
            }
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (playWhenReady) ensurePlaybackService()
                render()
            }
            override fun onPlaybackStateChanged(playbackState: Int) = render()
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = render()
            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) = render()
            override fun onRepeatModeChanged(repeatMode: Int) = render()
        })
        permissionGranted = hasAudioPermission()
        if (permissionGranted) {
            loadMusic()
            requestNotificationPermissionIfNeeded()
        } else {
            requestAudioPermission()
        }
        render()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun hasAudioPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        permissionLauncher.launch(permission)
    }

    private fun loadMusic() {
        songs.clear()
        val baseSongs = MusicRepository.querySongs(contentResolver)
        val metaPrefs = getSharedPreferences("pixelmusic_metadata", MODE_PRIVATE)
        songs += baseSongs.map { song ->
            song.copy(
                title = metaPrefs.getString("${song.id}_title", song.title) ?: song.title,
                artist = metaPrefs.getString("${song.id}_artist", song.artist) ?: song.artist,
                album = metaPrefs.getString("${song.id}_album", song.album) ?: song.album
            )
        }
        // Keep the play queue empty on startup. Songs are added only when the user
        // explicitly starts playback or adds tracks to the queue.
        if (player.mediaItemCount == 0) {
            queue.clear()
            playbackQueue.clear()
        }
    }


    /** Build a MediaItem with title/artist/album so the system media notification stays in sync. */
    private fun mediaItemFor(song: MusicSong): MediaItem {
        val metadata = MediaMetadata.Builder()
            .setTitle(song.title.ifBlank { "Unknown title" })
            .setArtist(song.artist.ifBlank { "Unknown artist" })
            .setAlbumTitle(song.album.ifBlank { "Unknown album" })
            .setIsPlayable(true)
            .apply {
                song.artworkUriString?.takeIf { it.isNotBlank() }?.let { art ->
                    setArtworkUri(Uri.parse(art))
                }
            }
            .build()
        return MediaItem.Builder()
            .setUri(song.uriString)
            .setMediaId(song.id.toString())
            .setMediaMetadata(metadata)
            .build()
    }

    private fun mediaItemsFor(indices: List<Int>): List<MediaItem> =
        indices.mapNotNull { i -> songs.getOrNull(i)?.let { mediaItemFor(it) } }

    /**
     * @param indices  queue order (e.g. all songs in a folder)
     * @param startSongIndex  song index in [songs] to begin at; if null or not in list, starts at first
     */
    private fun ensurePlaybackService() {
        val intent = Intent(this, PlaybackService::class.java)
        // Start as foreground while audio is requested so the process is less
        // likely to be reclaimed after a few minutes in the background.
        try {
            ContextCompat.startForegroundService(this, intent)
        } catch (_: Exception) {
            startService(intent)
        }
    }

    private fun hiddenFolderPaths(): Set<String> {
        val prefs = getSharedPreferences("pixelmusic_settings", MODE_PRIVATE)
        return prefs.getStringSet("folder_hidden_paths", emptySet())?.map { it.trimEnd('/') }?.toSet()
            ?: emptySet()
    }

    /** Library indices excluding tracks that live in a hidden folder. */
    private fun visibleLibraryIndices(): List<Int> {
        val hidden = hiddenFolderPaths()
        if (hidden.isEmpty()) return songs.indices.toList()
        return songs.indices.filter { idx ->
            val path = songs[idx].folderPath.trimEnd('/').ifBlank { "__UNKNOWN__" }
            path !in hidden
        }
    }

    private fun startPlayback(indices: List<Int>, startSongIndex: Int? = null) {
        ensurePlaybackService()
        val hidden = hiddenFolderPaths()
        val valid = indices.filter { idx ->
            if (idx !in songs.indices) return@filter false
            val path = songs[idx].folderPath.trimEnd('/').ifBlank { "__UNKNOWN__" }
            path !in hidden
        }.distinct()
        if (valid.isEmpty()) return

        // Starting playback from a navigation destination follows its visible order.
        // Shuffle is enabled only by the user's explicit shuffle control.
        player.shuffleModeEnabled = false
        activeScope.clear()
        activeScope.addAll(valid)
        queue.clear()
        queue.addAll(valid)
        playbackQueue.clear()
        playbackQueue.addAll(valid)

        val startPos = startSongIndex?.let { valid.indexOf(it) }?.takeIf { it >= 0 } ?: 0
        player.setMediaItems(
            mediaItemsFor(playbackQueue),
            startPos,
            0L
        )
        player.prepare()
        player.playWhenReady = true
        player.play()
        render()
    }

    /**
     * Shuffle within [scope], keeping [currentSongIndex] first when present.
     * Updates playbackQueue and enables ExoPlayer shuffle.
     */
    private fun applyShuffle(scope: List<Int>, currentSongIndex: Int?) {
        val valid = scope.filter { it in songs.indices }.distinct()
        if (valid.isEmpty()) return
        val start = when {
            currentSongIndex != null && currentSongIndex in valid -> currentSongIndex
            else -> valid.first()
        }
        val shuffledRest = valid.filter { it != start }.shuffled()
        playbackQueue.clear()
        playbackQueue.add(start)
        playbackQueue.addAll(shuffledRest)
        // Visible queue mirrors the scope order (not the shuffled order) for UI clarity.
        queue.clear()
        queue.addAll(valid)
        activeScope.clear()
        activeScope.addAll(valid)
        player.setMediaItems(mediaItemsFor(playbackQueue))
        player.shuffleModeEnabled = true
        player.prepare()
        player.seekToDefaultPosition(0)
    }

    private fun render() {
        if (!::player.isInitialized) return
        val playbackIndex = player.currentMediaItemIndex
        val index = if (playbackIndex in playbackQueue.indices) playbackQueue[playbackIndex] else -1
        setContent {
            PixelMusicApp(
                    songs = songs.toList(),
                    currentIndex = if (songs.isEmpty()) -1 else index,
                    playing = player.playWhenReady && player.playbackState != Player.STATE_ENDED,
                    onSongClick = { i ->
                        if (i in songs.indices) {
                            // Generic single-entry play: keep existing queue order if the track is
                            // already in it; otherwise start a one-track queue.
                            // Contextual lists (Folders/Albums/…) should call startPlayback with
                            // their own ordered index list instead of this path.
                            player.shuffleModeEnabled = false
                            val visibleQueue = queue.toList()
                            val selectedQueue = if (i in visibleQueue) {
                                // Rotate so tapped track is first, preserve relative order.
                                val at = visibleQueue.indexOf(i)
                                visibleQueue.drop(at) + visibleQueue.take(at)
                            } else {
                                listOf(i)
                            }
                            queue.clear()
                            queue.addAll(selectedQueue)
                            activeScope.clear()
                            activeScope.addAll(selectedQueue)
                            playbackQueue.clear()
                            playbackQueue.addAll(selectedQueue)
                            player.setMediaItems(mediaItemsFor(playbackQueue))
                            player.shuffleModeEnabled = false
                            player.prepare()
                            player.seekToDefaultPosition(0)
                            player.playWhenReady = true
                            player.play()
                            render()
                        }
                    },
                    onRecentSongClick = { i ->
                        if (i in songs.indices) {
                            val selected = songs[i]
                            val album = selected.album.trim()
                            val artist = selected.artist.trim()
                            val albumSongs = songs.indices.filter { idx ->
                                idx != i && songs[idx].album.trim().equals(album, ignoreCase = true)
                            }
                            val artistSongs = songs.indices.filter { idx ->
                                idx != i && !albumSongs.contains(idx) &&
                                    songs[idx].artist.trim().equals(artist, ignoreCase = true)
                            }
                            player.shuffleModeEnabled = false
                            val newQueue = mutableListOf<Int>()
                            newQueue += i
                            newQueue += albumSongs
                            newQueue += artistSongs
                            // Do not pad the queue with unrelated library tracks.
                            // The queue contains only the selected song and its album/artist tracks.

                            queue.clear()
                            queue.addAll(newQueue)
                            activeScope.clear()
                            activeScope.addAll(newQueue)
                            playbackQueue.clear()
                            playbackQueue.addAll(newQueue)
                            player.setMediaItems(mediaItemsFor(playbackQueue))
                            player.prepare()
                            player.seekToDefaultPosition(0)
                            player.play()
                            render()
                        }
                    },
                    onPlayFolder = { indices, startSongIndex -> startPlayback(indices, startSongIndex) },
                    onPlaySongList = { indices, startSongIndex -> startPlayback(indices, startSongIndex) },
                    onPlayPause = {
                        if (player.playWhenReady) player.pause() else if (player.mediaItemCount > 0) player.play()
                        render()
                    },
                    onNext = { if (player.mediaItemCount > 0) player.seekToNextMediaItem(); player.play(); render() },
                    onPrevious = {
                        if (player.mediaItemCount > 0) {
                            // 1st press: restart current track; 2nd press (near start): previous track.
                            if (player.currentPosition > 3_000L) {
                                player.seekTo(0)
                            } else {
                                player.seekToPreviousMediaItem()
                            }
                            player.play()
                        }
                        render()
                    },
                    positionProvider = { player.currentPosition },
                    durationProvider = { player.duration.takeIf { it != androidx.media3.common.C.TIME_UNSET } ?: 0L },
                    onSeekTo = { position -> player.seekTo(position) },
                    shuffleEnabled = player.shuffleModeEnabled,
                    repeatMode = player.repeatMode,
                    onToggleShuffle = {
                        val currentSongIndex = player.currentMediaItemIndex
                            .takeIf { it in playbackQueue.indices }
                            ?.let { playbackQueue[it] }
                        val wasPlaying = player.playWhenReady
                        if (!player.shuffleModeEnabled) {
                            // Shuffle within the current play scope (folder / artist / playlist…).
                            // Fall back to the full visible library (hidden folders excluded).
                            val scope = when {
                                activeScope.isNotEmpty() -> activeScope.toList()
                                queue.isNotEmpty() -> queue.toList()
                                else -> visibleLibraryIndices()
                            }
                            applyShuffle(scope, currentSongIndex)
                            if (wasPlaying) player.play()
                        } else {
                            // Turning shuffle off restores the scoped order.
                            player.shuffleModeEnabled = false
                            val restoredBase = when {
                                activeScope.isNotEmpty() -> activeScope.toList()
                                queue.isNotEmpty() -> queue.toList()
                                else -> visibleLibraryIndices()
                            }
                            if (restoredBase.isNotEmpty()) {
                                val restored = if (currentSongIndex != null && currentSongIndex !in restoredBase) {
                                    listOf(currentSongIndex) + restoredBase
                                } else restoredBase
                                queue.clear()
                                queue.addAll(restoredBase)
                                playbackQueue.clear()
                                playbackQueue.addAll(restored)
                                player.setMediaItems(mediaItemsFor(playbackQueue))
                                player.prepare()
                                player.shuffleModeEnabled = false
                                val target = currentSongIndex?.let { playbackQueue.indexOf(it) } ?: 0
                                player.seekToDefaultPosition(target.coerceAtLeast(0))
                                if (wasPlaying) player.play()
                            } else {
                                player.clearMediaItems()
                                playbackQueue.clear()
                            }
                        }
                        render()
                    },
                    onShuffleAll = {
                        // HOME FAB: shuffle the entire library, excluding hidden folders.
                        val currentSongIndex = player.currentMediaItemIndex
                            .takeIf { it in playbackQueue.indices }
                            ?.let { playbackQueue[it] }
                        val wasPlaying = player.playWhenReady
                        if (player.shuffleModeEnabled && activeScope.toSet() == visibleLibraryIndices().toSet()) {
                            // Toggle off when already in full-library shuffle.
                            player.shuffleModeEnabled = false
                            val restored = visibleLibraryIndices()
                            if (restored.isNotEmpty()) {
                                queue.clear()
                                queue.addAll(restored)
                                activeScope.clear()
                                activeScope.addAll(restored)
                                playbackQueue.clear()
                                playbackQueue.addAll(
                                    if (currentSongIndex != null && currentSongIndex in restored) {
                                        val i = restored.indexOf(currentSongIndex)
                                        restored.drop(i) + restored.take(i)
                                    } else restored
                                )
                                player.setMediaItems(mediaItemsFor(playbackQueue))
                                player.prepare()
                                player.shuffleModeEnabled = false
                                val target = currentSongIndex?.let { playbackQueue.indexOf(it) } ?: 0
                                player.seekToDefaultPosition(target.coerceAtLeast(0))
                                if (wasPlaying) player.play()
                            }
                        } else {
                            ensurePlaybackService()
                            applyShuffle(visibleLibraryIndices(), currentSongIndex)
                            player.playWhenReady = true
                            player.play()
                        }
                        render()
                    },
                    onCycleRepeat = {
                        player.repeatMode = when (player.repeatMode) {
                            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                            else -> Player.REPEAT_MODE_OFF
                        }
                        render()
                    },
                    queueSongIndices = queue.toList(),
                    onQueueRemove = { queuePosition ->
                        if (queuePosition in queue.indices) {
                            val removedSong = queue.removeAt(queuePosition)
                            if (!player.shuffleModeEnabled) {
                                val playbackPosition = playbackQueue.indexOf(removedSong)
                                if (playbackPosition >= 0) {
                                    player.removeMediaItem(playbackPosition)
                                    playbackQueue.removeAt(playbackPosition)
                                }
                            }
                            render()
                        }
                    },
                    onQueueMove = { from, to ->
                        if (from in queue.indices && to in queue.indices && from != to) {
                            val moved = queue.removeAt(from)
                            queue.add(to, moved)
                            if (!player.shuffleModeEnabled) {
                                val playbackFrom = playbackQueue.indexOf(moved)
                                if (playbackFrom >= 0) {
                                    playbackQueue.removeAt(playbackFrom)
                                    val nextSong = queue.getOrNull(to)
                                    val playbackTo = nextSong?.let { playbackQueue.indexOf(it) } ?: playbackQueue.size
                                    playbackQueue.add(playbackTo.coerceIn(0, playbackQueue.size), moved)
                                    player.moveMediaItem(playbackFrom, playbackTo.coerceIn(0, playbackQueue.lastIndex.coerceAtLeast(0)))
                                }
                            }
                            render()
                        }
                    },
                    onQueueClear = {
                        queue.clear()
                        if (!player.shuffleModeEnabled) {
                            player.clearMediaItems()
                            playbackQueue.clear()
                        }
                        render()
                    },
                    onQueueAdd = { songIndex ->
                        if (songIndex in songs.indices) {
                            queue.add(songIndex)
                            if (!player.shuffleModeEnabled) {
                                playbackQueue.add(songIndex)
                                player.addMediaItem(mediaItemFor(songs[songIndex]))
                                if (player.playbackState == Player.STATE_IDLE) player.prepare()
                            }
                            render()
                        }
                    },
                    onUpdateSong = { updated ->
                        val index = songs.indexOfFirst { it.id == updated.id }
                        if (index >= 0) songs[index] = updated
                        getSharedPreferences("pixelmusic_metadata", MODE_PRIVATE).edit()
                            .putString("${updated.id}_title", updated.title)
                            .putString("${updated.id}_artist", updated.artist)
                            .putString("${updated.id}_album", updated.album)
                            .apply()
                        render()
                    },
                    equalizerEnabled = equalizerEnabled,
                    equalizerAvailable = equalizerAvailable,
                    equalizerGains = equalizerGains.toList(),
                    masterVolumePercent = masterVolumePercent,
                    onMasterVolumeChange = { percent ->
                        masterVolumePercent = percent.coerceIn(0f, 130f)
                        player.volume = masterVolumePercent / 100f
                        getSharedPreferences("pixelmusic_audio", MODE_PRIVATE).edit()
                            .putFloat("master_volume_percent", masterVolumePercent).apply()
                    },
                    onEqualizerEnabledChange = { enabled ->
                        equalizerEnabled = enabled
                        getSharedPreferences("pixelmusic_audio", MODE_PRIVATE).edit().putBoolean("eq_enabled", enabled).apply()
                        applyEqualizerGains()
                    },
                    onEqualizerBandChange = { index, gain ->
                        if (index in equalizerGains.indices) {
                            equalizerGains[index] = gain.coerceIn(-10f, 10f)
                            getSharedPreferences("pixelmusic_audio", MODE_PRIVATE).edit().putFloat("eq_band_$index", equalizerGains[index]).apply()
                            applyEqualizerGains()
                        }
                    },
                    onEqualizerPresetChange = { gains ->
                        for (i in equalizerGains.indices) equalizerGains[i] = (gains.getOrNull(i) ?: 0f).coerceIn(-10f, 10f)
                        val editor = getSharedPreferences("pixelmusic_audio", MODE_PRIVATE).edit()
                        equalizerGains.forEachIndexed { i, gain -> editor.putFloat("eq_band_$i", gain) }
                        editor.apply()
                        applyEqualizerGains()
                    },
                    enhancementEnabled = enhancementEnabled,
                    enhancementMode = enhancementMode,
                    enhancementStrength = enhancementStrength,
                    onEnhancementStrengthChange = { strength ->
                        enhancementStrength = when (strength) { "weak", "strong" -> strength; else -> "medium" }
                        getSharedPreferences("pixelmusic_audio", MODE_PRIVATE).edit().putString("enhancement_strength", enhancementStrength).apply()
                        applyEqualizerGains()
                    },
                    onEnhancementEnabledChange = { enabled ->
                        enhancementEnabled = enabled
                        getSharedPreferences("pixelmusic_audio", MODE_PRIVATE).edit().putBoolean("enhancement_enabled", enabled).apply()
                        applyEqualizerGains()
                    },
                    onEnhancementModeChange = { mode ->
                        enhancementMode = if (mode == "clarity") "clarity" else "natural"
                        getSharedPreferences("pixelmusic_audio", MODE_PRIVATE).edit().putString("enhancement_mode", enhancementMode).apply()
                        applyEqualizerGains()
                    }
                )
        }
    }

    private fun initializeEqualizer(sessionId: Int) {
        val config = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
            2,
            true, 10,
            false, 0,
            false, 0,
            false
        ).build()
        dynamicsProcessing?.release()
        val effect = DynamicsProcessing(0, sessionId, config)
        dynamicsProcessing = effect
        equalizerAvailable = true
        applyEqualizerGains()
        effect.enabled = equalizerEnabled || enhancementEnabled
    }

    private fun applyEqualizerGains() {
        val effect = dynamicsProcessing ?: return
        runCatching {
            val eq = DynamicsProcessing.Eq(true, true, equalizerFrequencies.size)
            equalizerFrequencies.forEachIndexed { index, frequency ->
                val band = eq.getBand(index)
                band.setCutoffFrequency(frequency)
                val enhancementGains = when (enhancementMode) {
                    "clarity" -> floatArrayOf(0f, 0f, 0f, -0.2f, -0.2f, 0.2f, 0.7f, 1.2f, 1.4f, 1.0f)
                    else -> floatArrayOf(0.2f, 0.35f, 0.3f, 0.1f, 0f, 0.1f, 0.2f, 0.35f, 0.4f, 0.25f)
                }
                val baseGain = if (equalizerEnabled) equalizerGains[index] else 0f
                val strengthMultiplier = when (enhancementStrength) { "weak" -> 0.5f; "strong" -> 1.5f; else -> 1f }
                val extraGain = if (enhancementEnabled) enhancementGains[index] * strengthMultiplier else 0f
                band.setGain((baseGain + extraGain).coerceIn(-10f, 10f))
                eq.setBand(index, band)
            }
            effect.setPreEqAllChannelsTo(eq)
            effect.enabled = equalizerEnabled || enhancementEnabled
        }.onFailure {
            equalizerAvailable = false
        }
    }

    override fun onDestroy() {
        dynamicsProcessing?.release()
        dynamicsProcessing = null
        // Keep the shared ExoPlayer alive for background playback / media notification.
        // The process may still hold PlaybackService; player is only released with the process.
        super.onDestroy()
    }
}
