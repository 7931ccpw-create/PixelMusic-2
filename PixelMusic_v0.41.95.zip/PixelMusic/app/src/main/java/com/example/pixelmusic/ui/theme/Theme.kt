package com.example.pixelmusic.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * Accent + dark surface palette. New entries lean on deep blacks / charcoals
 * so Home keeps its existing dark identity while offering more variety.
 */
enum class AppTheme(
    val label: String,
    val description: String,
    val accent: Color,
    val background: Color = Color(0xFF08090B),
    val surface: Color = Color(0xFF121417),
    val surfaceVariant: Color = Color(0xFF1A1D22)
) {
    Black(
        "Black",
        "従来の深いブラック",
        accent = Color(0xFFB8BDC3),
        background = Color(0xFF08090B),
        surface = Color(0xFF121417),
        surfaceVariant = Color(0xFF1A1D22)
    ),
    Charcoal(
        "Charcoal",
        "落ち着いたチャコールグレー",
        accent = Color(0xFFC5CAD0),
        background = Color(0xFF0B0C0E),
        surface = Color(0xFF16181C),
        surfaceVariant = Color(0xFF1F2328)
    ),
    Graphite(
        "Graphite",
        "硬質なグラファイト",
        accent = Color(0xFFA8B0B8),
        background = Color(0xFF0A0B0D),
        surface = Color(0xFF14171B),
        surfaceVariant = Color(0xFF1C2025)
    ),
    Midnight(
        "Midnight",
        "ミッドナイトネイビー",
        accent = Color(0xFF7EB0FF),
        background = Color(0xFF07090E),
        surface = Color(0xFF10141C),
        surfaceVariant = Color(0xFF171C26)
    ),
    Obsidian(
        "Obsidian",
        "黒曜石のクールトーン",
        accent = Color(0xFF9AA3AD),
        background = Color(0xFF050607),
        surface = Color(0xFF0E1013),
        surfaceVariant = Color(0xFF171A1F)
    ),
    Espresso(
        "Espresso",
        "ダークブラウンの黒",
        accent = Color(0xFFD2B48C),
        background = Color(0xFF0C0908),
        surface = Color(0xFF16110F),
        surfaceVariant = Color(0xFF211A17)
    ),
    Slate(
        "Slate",
        "スレートブルーグレー",
        accent = Color(0xFF8FA3B5),
        background = Color(0xFF090B0E),
        surface = Color(0xFF12161B),
        surfaceVariant = Color(0xFF1A2027)
    ),
    Blue(
        "Blue",
        "クラシックブルー",
        accent = Color(0xFF4DA3FF),
        background = Color(0xFF08090B),
        surface = Color(0xFF121417),
        surfaceVariant = Color(0xFF1A1D22)
    ),
    Red(
        "Red",
        "アクセントレッド",
        accent = Color(0xFFFF5A64),
        background = Color(0xFF0B0809),
        surface = Color(0xFF171213),
        surfaceVariant = Color(0xFF22181A)
    ),
    Purple(
        "Purple",
        "ディープパープル",
        accent = Color(0xFFB68CFF),
        background = Color(0xFF0A0810),
        surface = Color(0xFF15121C),
        surfaceVariant = Color(0xFF1E1A28)
    ),
    Green(
        "Green",
        "ナチュラルグリーン",
        accent = Color(0xFF63D391),
        background = Color(0xFF080B09),
        surface = Color(0xFF121815),
        surfaceVariant = Color(0xFF1A221C)
    ),
    Orange(
        "Orange",
        "ウォームオレンジ",
        accent = Color(0xFFFFA64D),
        background = Color(0xFF0C0A08),
        surface = Color(0xFF181410),
        surfaceVariant = Color(0xFF221C16)
    ),
    Cyan(
        "Cyan",
        "クールシアン",
        accent = Color(0xFF55D6E8),
        background = Color(0xFF080A0B),
        surface = Color(0xFF121718),
        surfaceVariant = Color(0xFF1A2122)
    ),
    Silver(
        "Silver",
        "シルバーグレー",
        accent = Color(0xFFD0D5DA),
        background = Color(0xFF0A0B0C),
        surface = Color(0xFF151719),
        surfaceVariant = Color(0xFF1E2124)
    )
}

val LocalAccentColor = staticCompositionLocalOf { Color(0xFF4DA3FF) }

@Composable
fun PixelMusicTheme(theme: AppTheme = AppTheme.Blue, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = theme.accent,
            secondary = theme.accent,
            tertiary = theme.accent,
            background = theme.background,
            surface = theme.surface,
            surfaceVariant = theme.surfaceVariant,
            onSurface = Color(0xFFF3F4F5),
            onSurfaceVariant = Color(0xFF9AA0A6),
            primaryContainer = theme.accent.copy(alpha = 0.20f),
            onPrimaryContainer = Color.White
        ),
        content = content
    )
}

/** Backward-compatible overload used by older call sites. */
@Composable
fun PixelMusicTheme(accent: Color, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = accent,
            secondary = accent,
            tertiary = accent,
            background = Color(0xFF08090B),
            surface = Color(0xFF121417),
            onSurface = Color(0xFFF3F4F5),
            onSurfaceVariant = Color(0xFF9AA0A6),
            primaryContainer = accent.copy(alpha = 0.20f),
            onPrimaryContainer = Color.White
        ),
        content = content
    )
}
