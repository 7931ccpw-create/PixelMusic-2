package com.example.pixelmusic.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/**
 * Accent + dark surface palette. New entries lean on deep blacks / charcoals
 * so Home keeps its existing dark identity while offering more variety.
 */
enum class AppTheme(
    val label: String,
    val description: String,
    val accent: Color,
    val background: Color = Color(0xFF08090B),
    val surface: Color = Color(0xFF121417),
    val surfaceVariant: Color = Color(0xFF1A1D22)
) {
    Black(
        "Black",
        "従来の深いブラック",
        accent = Color(0xFFB8BDC3),
        background = Color(0xFF08090B),
        surface = Color(0xFF121417),
        surfaceVariant = Color(0xFF1A1D22)
    ),
    Charcoal(
        "Charcoal",
        "落ち着いたチャコールグレー",
        accent = Color(0xFFC5CAD0),
        background = Color(0xFF0B0C0E),
        surface = Color(0xFF16181C),
        surfaceVariant = Color(0xFF1F2328)
    ),
    Graphite(
        "Graphite",
        "硬質なグラファイト",
        accent = Color(0xFFA8B0B8),
        background = Color(0xFF0A0B0D),
        surface = Color(0xFF14171B),
        surfaceVariant = Color(0xFF1C2025)
    ),
    Midnight(
        "Midnight",
        "ミッドナイトネイビー",
        accent = Color(0xFF7EB0FF),
        background = Color(0xFF07090E),
        surface = Color(0xFF10141C),
        surfaceVariant = Color(0xFF171C26)
    ),
    Obsidian(
        "Obsidian",
        "黒曜石のクールトーン",
        accent = Color(0xFF9AA3AD),
        background = Color(0xFF050607),
        surface = Color(0xFF0E1013),
        surfaceVariant = Color(0xFF171A1F)
    ),
    Espresso(
        "Espresso",
        "ダークブラウンの黒",
        accent = Color(0xFFD2B48C),
        background = Color(0xFF0C0908),
        surface = Color(0xFF16110F),
        surfaceVariant = Color(0xFF211A17)
    ),
    Slate(
        "Slate",
        "スレートブルーグレー",
        accent = Color(0xFF8FA3B5),
        background = Color(0xFF090B0E),
        surface = Color(0xFF12161B),
        surfaceVariant = Color(0xFF1A2027)
    ),
    Blue(
        "Blue",
        "クラシックブルー",
        accent = Color(0xFF4DA3FF),
        background = Color(0xFF08090B),
        surface = Color(0xFF121417),
        surfaceVariant = Color(0xFF1A1D22)
    ),
    Red(
        "Red",
        "アクセントレッド",
        accent = Color(0xFFFF5A64),
        background = Color(0xFF0B0809),
        surface = Color(0xFF171213),
        surfaceVariant = Color(0xFF22181A)
    ),
    Purple(
        "Purple",
        "ディープパープル",
        accent = Color(0xFFB68CFF),
        background = Color(0xFF0A0810),
        surface = Color(0xFF15121C),
        surfaceVariant = Color(0xFF1E1A28)
    ),
    Green(
        "Green",
        "ナチュラルグリーン",
        accent = Color(0xFF63D391),
        background = Color(0xFF080B09),
        surface = Color(0xFF121815),
        surfaceVariant = Color(0xFF1A221C)
    ),
    Orange(
        "Orange",
        "ウォームオレンジ",
        accent = Color(0xFFFFA64D),
        background = Color(0xFF0C0A08),
        surface = Color(0xFF181410),
        surfaceVariant = Color(0xFF221C16)
    ),
    Cyan(
        "Cyan",
        "クールシアン",
        accent = Color(0xFF55D6E8),
        background = Color(0xFF080A0B),
        surface = Color(0xFF121718),
        surfaceVariant = Color(0xFF1A2122)
    ),
    Silver(
        "Silver",
        "シルバーグレー",
        accent = Color(0xFFD0D5DA),
        background = Color(0xFF0A0B0C),
        surface = Color(0xFF151719),
        surfaceVariant = Color(0xFF1E2124)
    ),

    Rose(
        "Rose",
        "ソフトローズ",
        accent = Color(0xFFFF8FAB),
        background = Color(0xFF0C090B),
        surface = Color(0xFF181214),
        surfaceVariant = Color(0xFF231A1E)
    ),
    Magenta(
        "Magenta",
        "ビビッドマゼンタ",
        accent = Color(0xFFE879F9),
        background = Color(0xFF0B0810),
        surface = Color(0xFF16121C),
        surfaceVariant = Color(0xFF211A28)
    ),
    Indigo(
        "Indigo",
        "ディープインディゴ",
        accent = Color(0xFF818CF8),
        background = Color(0xFF08090F),
        surface = Color(0xFF12141C),
        surfaceVariant = Color(0xFF1A1D28)
    ),
    Teal(
        "Teal",
        "落ち着いたティール",
        accent = Color(0xFF2DD4BF),
        background = Color(0xFF070B0B),
        surface = Color(0xFF101817),
        surfaceVariant = Color(0xFF182220)
    ),
    Lime(
        "Lime",
        "フレッシュライム",
        accent = Color(0xFFA3E635),
        background = Color(0xFF090B07),
        surface = Color(0xFF141810),
        surfaceVariant = Color(0xFF1C2216)
    ),
    Amber(
        "Amber",
        "ウォームアンバー",
        accent = Color(0xFFFBBF24),
        background = Color(0xFF0C0A07),
        surface = Color(0xFF18140F),
        surfaceVariant = Color(0xFF221C14)
    ),
    Coral(
        "Coral",
        "コーラルピンク",
        accent = Color(0xFFFF7F6B),
        background = Color(0xFF0C0908),
        surface = Color(0xFF181312),
        surfaceVariant = Color(0xFF231A18)
    ),
    Sky(
        "Sky",
        "クリアスカイ",
        accent = Color(0xFF38BDF8),
        background = Color(0xFF070A0D),
        surface = Color(0xFF10151A),
        surfaceVariant = Color(0xFF171E24)
    ),
    Emerald(
        "Emerald",
        "エメラルドグリーン",
        accent = Color(0xFF34D399),
        background = Color(0xFF070B09),
        surface = Color(0xFF101814),
        surfaceVariant = Color(0xFF17221B)
    ),
    Violet(
        "Violet",
        "エレガントバイオレット",
        accent = Color(0xFFA78BFA),
        background = Color(0xFF0A0810),
        surface = Color(0xFF15121C),
        surfaceVariant = Color(0xFF1F1A2A)
    ),

    Crimson(
        "Crimson",
        "ディープクリムゾン",
        accent = Color(0xFFDC2626),
        background = Color(0xFF0C0708),
        surface = Color(0xFF181012),
        surfaceVariant = Color(0xFF24161A)
    ),
    Burgundy(
        "Burgundy",
        "ボルドー",
        accent = Color(0xFFBE123C),
        background = Color(0xFF0B0709),
        surface = Color(0xFF171013),
        surfaceVariant = Color(0xFF22161B)
    ),
    Peach(
        "Peach",
        "ソフトピーチ",
        accent = Color(0xFFFB923C),
        background = Color(0xFF0C0A08),
        surface = Color(0xFF181410),
        surfaceVariant = Color(0xFF221C16)
    ),
    Gold(
        "Gold",
        "リッチゴールド",
        accent = Color(0xFFEAB308),
        background = Color(0xFF0C0B07),
        surface = Color(0xFF18160F),
        surfaceVariant = Color(0xFF221F14)
    ),
    Olive(
        "Olive",
        "オリーブグリーン",
        accent = Color(0xFFA3B18A),
        background = Color(0xFF090B08),
        surface = Color(0xFF141712),
        surfaceVariant = Color(0xFF1C2118)
    ),
    Forest(
        "Forest",
        "フォレストグリーン",
        accent = Color(0xFF16A34A),
        background = Color(0xFF070B08),
        surface = Color(0xFF101612),
        surfaceVariant = Color(0xFF17201A)
    ),
    Mint(
        "Mint",
        "ミントグリーン",
        accent = Color(0xFF6EE7B7),
        background = Color(0xFF080B0A),
        surface = Color(0xFF121816),
        surfaceVariant = Color(0xFF1A221F)
    ),
    Aqua(
        "Aqua",
        "アクアブルー",
        accent = Color(0xFF22D3EE),
        background = Color(0xFF070A0C),
        surface = Color(0xFF10161A),
        surfaceVariant = Color(0xFF172028)
    ),
    Ocean(
        "Ocean",
        "オーシャンブルー",
        accent = Color(0xFF0284C7),
        background = Color(0xFF070A0E),
        surface = Color(0xFF10151C),
        surfaceVariant = Color(0xFF171E28)
    ),
    Navy(
        "Navy",
        "ネイビー",
        accent = Color(0xFF3B82F6),
        background = Color(0xFF07090E),
        surface = Color(0xFF10141C),
        surfaceVariant = Color(0xFF171C26)
    ),
    Lavender(
        "Lavender",
        "ラベンダー",
        accent = Color(0xFFC4B5FD),
        background = Color(0xFF0A0910),
        surface = Color(0xFF15141C),
        surfaceVariant = Color(0xFF1F1D28)
    ),
    Plum(
        "Plum",
        "プラムパープル",
        accent = Color(0xFFC026D3),
        background = Color(0xFF0B0810),
        surface = Color(0xFF17121C),
        surfaceVariant = Color(0xFF221A28)
    ),
    Grape(
        "Grape",
        "グレープ",
        accent = Color(0xFF7C3AED),
        background = Color(0xFF0A0810),
        surface = Color(0xFF15121C),
        surfaceVariant = Color(0xFF1F1A2A)
    ),
    HotPink(
        "Hot Pink",
        "ホットピンク",
        accent = Color(0xFFEC4899),
        background = Color(0xFF0C090B),
        surface = Color(0xFF181214),
        surfaceVariant = Color(0xFF231A1E)
    ),
    Salmon(
        "Salmon",
        "サーモンピンク",
        accent = Color(0xFFFB7185),
        background = Color(0xFF0C090A),
        surface = Color(0xFF181313),
        surfaceVariant = Color(0xFF231A1A)
    ),
    Sand(
        "Sand",
        "サンドベージュ",
        accent = Color(0xFFD6C7A1),
        background = Color(0xFF0C0B09),
        surface = Color(0xFF181612),
        surfaceVariant = Color(0xFF221F18)
    ),
    Steel(
        "Steel",
        "スチールブルー",
        accent = Color(0xFF94A3B8),
        background = Color(0xFF090A0C),
        surface = Color(0xFF14161A),
        surfaceVariant = Color(0xFF1C2026)
    ),
    Copper(
        "Copper",
        "カッパー",
        accent = Color(0xFFEA580C),
        background = Color(0xFF0C0907),
        surface = Color(0xFF18140F),
        surfaceVariant = Color(0xFF221C14)
    ),
    Neon(
        "Neon",
        "ネオングリーン",
        accent = Color(0xFF39FF14),
        background = Color(0xFF080B07),
        surface = Color(0xFF121810),
        surfaceVariant = Color(0xFF1A2216)
    ),
    Random(
        "Random",
        "曲ごとにランダム",
        accent = Color(0xFFCCCCCC),
        background = Color(0xFF08090B),
        surface = Color(0xFF121417),
        surfaceVariant = Color(0xFF1A1D22)
    ),

}



/** Background tone: 0=現状, 1=半分, 2=フル (lighter surfaces). */
fun AppTheme.withBackgroundTone(tone: Int): AppThemeColors {
    val t = tone.coerceIn(0, 2)
    fun lift(c: Color, amount: Float): Color {
        return Color(
            red = (c.red + (0.22f - c.red) * amount).coerceIn(0f, 1f),
            green = (c.green + (0.24f - c.green) * amount).coerceIn(0f, 1f),
            blue = (c.blue + (0.28f - c.blue) * amount).coerceIn(0f, 1f),
            alpha = 1f
        )
    }
    val amount = when (t) {
        0 -> 0f
        1 -> 0.45f
        else -> 0.9f
    }
    return AppThemeColors(
        accent = accent,
        background = lift(background, amount),
        surface = lift(surface, amount),
        surfaceVariant = lift(surfaceVariant, amount)
    )
}

data class AppThemeColors(
    val accent: Color,
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color
)

val LocalAccentColor = staticCompositionLocalOf { Color(0xFF4DA3FF) }

@Composable
fun PixelMusicTheme(theme: AppTheme = AppTheme.Blue, backgroundTone: Int = 0, content: @Composable () -> Unit) {
    val colors = theme.withBackgroundTone(backgroundTone)
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = colors.accent,
            secondary = colors.accent,
            tertiary = colors.accent,
            background = colors.background,
            surface = colors.surface,
            surfaceVariant = colors.surfaceVariant,
            onSurface = Color(0xFFF3F4F5),
            onSurfaceVariant = Color(0xFF9AA0A6),
            primaryContainer = colors.accent.copy(alpha = 0.20f),
            onPrimaryContainer = Color.White
        ),
        content = content
    )
}

/** Backward-compatible overload used by older call sites. */
@Composable
fun PixelMusicTheme(accent: Color, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = accent,
            secondary = accent,
            tertiary = accent,
            background = Color(0xFF08090B),
            surface = Color(0xFF121417),
            onSurface = Color(0xFFF3F4F5),
            onSurfaceVariant = Color(0xFF9AA0A6),
            primaryContainer = accent.copy(alpha = 0.20f),
            onPrimaryContainer = Color.White
        ),
        content = content
    )
}
