package com.example.pixelmusic

import android.content.ContentResolver
import android.provider.MediaStore

 data class MusicSong(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val uriString: String,
    val artworkUriString: String?,
    val dateAdded: Long,
    val folderPath: String
)

object MusicRepository {
    fun querySongs(resolver: ContentResolver): List<MusicSong> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATA
        )
        val result = mutableListOf<MusicSong>()
        resolver.query(
            collection,
            projection,
            "${MediaStore.Audio.Media.IS_MUSIC} != 0",
            null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val dateAddedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val dataCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol).orEmpty().ifBlank { "Unknown Title" }
                val artist = cursor.getString(artistCol).orEmpty().ifBlank { "Unknown Artist" }
                val album = cursor.getString(albumCol).orEmpty().ifBlank { "Unknown Album" }
                val duration = cursor.getLong(durationCol)
                val albumId = cursor.getLong(albumIdCol)
                val dateAdded = cursor.getLong(dateAddedCol)
                val dataPath = if (dataCol >= 0) cursor.getString(dataCol).orEmpty() else ""
                val folderPath = dataPath.substringBeforeLast('/', "").ifBlank { "" }
                val uri = android.content.ContentUris.withAppendedId(collection, id)
                val artworkUri = if (albumId > 0) {
                    android.content.ContentUris.withAppendedId(MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI, albumId)
                        .toString()
                } else null
                result += MusicSong(id, title, artist, album, duration, uri.toString(), artworkUri, dateAdded, folderPath)
            }
        }
        return result
    }
}
