package com.example.pixelmusic

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer

/**
 * Single shared ExoPlayer used by [MainActivity] and [PlaybackService]
 * so playback continues when the UI is in the background.
 */
@OptIn(UnstableApi::class)
object PlayerHolder {
    @Volatile
    private var player: ExoPlayer? = null

    fun getOrCreate(context: Context): ExoPlayer {
        player?.let { return it }
        synchronized(this) {
            player?.let { return it }
            val appContext = context.applicationContext
            val created = ExoPlayer.Builder(appContext)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                        .build(),
                    /* handleAudioFocus = */ true
                )
                .setHandleAudioBecomingNoisy(true)
                // LOCAL keeps a partial wake lock while the player is buffering / ready
                // with playWhenReady=true. Combined with PlaybackService's own wake lock.
                .setWakeMode(C.WAKE_MODE_LOCAL)
                .build()
            // Prefer continuous playback over pausing on short focus losses (nav prompts etc.)
            created.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true
            )
            player = created
            return created
        }
    }

    fun get(): ExoPlayer? = player

    fun release() {
        synchronized(this) {
            player?.release()
            player = null
        }
    }
}
