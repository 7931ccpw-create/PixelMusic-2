package com.example.pixelmusic

import android.content.ContentResolver
import android.os.Build
import android.provider.MediaStore

data class MusicSong(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val uriString: String,
    val artworkUriString: String?,
    val dateAdded: Long,
    val folderPath: String,
    /** File name (e.g. 01_track.m4a) for natural folder ordering */
    val displayName: String = "",
    /** Track number from MediaStore when available (0 if unknown) */
    val trackNumber: Int = 0
)

object MusicRepository {
    fun querySongs(resolver: ContentResolver): List<MusicSong> {
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = mutableListOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.TRACK
        )
        // DATA is deprecated but still the most reliable folder path source when present.
        if (Build.VERSION.SDK_INT < 29) {
            projection += MediaStore.Audio.Media.DATA
        } else {
            projection += MediaStore.Audio.Media.DATA
            projection += MediaStore.Audio.Media.RELATIVE_PATH
        }
        val result = mutableListOf<MusicSong>()
        resolver.query(
            collection,
            projection.toTypedArray(),
            "${MediaStore.Audio.Media.IS_MUSIC} != 0",
            null,
            "${MediaStore.Audio.Media.DISPLAY_NAME} COLLATE NOCASE ASC"
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val albumCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val albumIdCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val dateAddedCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val dataCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)
            val relativeCol = cursor.getColumnIndex(MediaStore.Audio.Media.RELATIVE_PATH)
            val displayNameCol = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
            val trackCol = cursor.getColumnIndex(MediaStore.Audio.Media.TRACK)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val title = cursor.getString(titleCol).orEmpty().ifBlank { "Unknown Title" }
                val artist = cursor.getString(artistCol).orEmpty().ifBlank { "Unknown Artist" }
                val album = cursor.getString(albumCol).orEmpty().ifBlank { "Unknown Album" }
                val duration = cursor.getLong(durationCol)
                val albumId = cursor.getLong(albumIdCol)
                val dateAdded = cursor.getLong(dateAddedCol)
                val displayName = if (displayNameCol >= 0) {
                    cursor.getString(displayNameCol).orEmpty()
                } else {
                    ""
                }
                // TRACK can be like 1003 (disc*1000+track) or plain track number
                val trackRaw = if (trackCol >= 0) cursor.getInt(trackCol) else 0
                val trackNumber = when {
                    trackRaw <= 0 -> 0
                    trackRaw >= 1000 -> trackRaw % 1000
                    else -> trackRaw
                }

                val dataPath = if (dataCol >= 0) cursor.getString(dataCol).orEmpty() else ""
                val relativePath = if (relativeCol >= 0) cursor.getString(relativeCol).orEmpty() else ""
                val folderPath = when {
                    dataPath.isNotBlank() -> dataPath.substringBeforeLast('/', "").trimEnd('/')
                    relativePath.isNotBlank() -> relativePath.trimEnd('/')
                    else -> ""
                }

                val uri = android.content.ContentUris.withAppendedId(collection, id)
                val artworkUri = if (albumId > 0) {
                    android.content.ContentUris.withAppendedId(
                        MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI,
                        albumId
                    ).toString()
                } else null

                result += MusicSong(
                    id = id,
                    title = title,
                    artist = artist,
                    album = album,
                    duration = duration,
                    uriString = uri.toString(),
                    artworkUriString = artworkUri,
                    dateAdded = dateAdded,
                    folderPath = folderPath,
                    displayName = displayName.ifBlank {
                        dataPath.substringAfterLast('/').ifBlank { title }
                    },
                    trackNumber = trackNumber
                )
            }
        }
        return result
    }

    /**
     * Natural sort for file names: "2.m4a" before "10.m4a", case-insensitive.
     */
    fun naturalCompare(a: String, b: String): Int {
        val al = a.lowercase()
        val bl = b.lowercase()
        var i = 0
        var j = 0
        while (i < al.length && j < bl.length) {
            val ca = al[i]
            val cb = bl[j]
            if (ca.isDigit() && cb.isDigit()) {
                var ia = i
                while (ia < al.length && al[ia].isDigit()) ia++
                var ib = j
                while (ib < bl.length && bl[ib].isDigit()) ib++
                val na = al.substring(i, ia).trimStart('0').let { if (it.isEmpty()) "0" else it }
                val nb = bl.substring(j, ib).trimStart('0').let { if (it.isEmpty()) "0" else it }
                val lenCmp = na.length.compareTo(nb.length)
                if (lenCmp != 0) return lenCmp
                val numCmp = na.compareTo(nb)
                if (numCmp != 0) return numCmp
                i = ia
                j = ib
            } else {
                val cmp = ca.compareTo(cb)
                if (cmp != 0) return cmp
                i++
                j++
            }
        }
        return (al.length - i).compareTo(bl.length - j)
    }

    fun compareSongsInFolder(a: MusicSong, b: MusicSong): Int {
        // Prefer track number when both known
        if (a.trackNumber > 0 && b.trackNumber > 0) {
            val t = a.trackNumber.compareTo(b.trackNumber)
            if (t != 0) return t
        } else if (a.trackNumber > 0 && b.trackNumber <= 0) {
            return -1
        } else if (a.trackNumber <= 0 && b.trackNumber > 0) {
            return 1
        }
        val byName = naturalCompare(a.displayName, b.displayName)
        if (byName != 0) return byName
        return naturalCompare(a.title, b.title)
    }
}
