package com.example.pixelmusic.ui

import com.example.pixelmusic.MusicSong
import com.example.pixelmusic.ui.theme.AppTheme
import com.example.pixelmusic.ui.theme.LocalAccentColor
import com.example.pixelmusic.ui.theme.PixelMusicTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.Velocity
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.util.LruCache
import android.media.MediaMetadataRetriever
import java.io.File
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlin.math.absoluteValue
import kotlin.math.roundToInt

@Composable
fun PixelMusicApp(
    songs: List<MusicSong>,
    currentIndex: Int,
    playing: Boolean,
    onSongClick: (Int) -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long,
    onSeekTo: (Long) -> Unit,
    shuffleEnabled: Boolean = false,
    repeatMode: Int = 0,
    onToggleShuffle: () -> Unit = {},
    onCycleRepeat: () -> Unit = {},
    queueSongIndices: List<Int>,
    onQueueRemove: (Int) -> Unit,
    onQueueMove: (Int, Int) -> Unit,
    onQueueClear: () -> Unit,
    onQueueAdd: (Int) -> Unit,
    onUpdateSong: (MusicSong) -> Unit,
    onNavigate: (String) -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("pixelmusic_settings", android.content.Context.MODE_PRIVATE) }
    var favoriteIds by remember {
        mutableStateOf(prefs.getStringSet("favorite_ids", emptySet())?.toSet() ?: emptySet())
    }
    var recentIds by remember {
        mutableStateOf(prefs.getString("recent_ids", "").orEmpty().split(",").filter { it.isNotBlank() })
    }
    var playlistNames by remember {
        mutableStateOf(prefs.getString("playlist_names", "").orEmpty().split("\u001f").filter { it.isNotBlank() })
    }
    var playlists by remember {
        mutableStateOf(playlistNames.associateWith { name ->
            prefs.getString("playlist_$name", "").orEmpty().split(",").filter { it.isNotBlank() }.toSet()
        })
    }
    fun persistPlaylists(updated: Map<String, Set<String>>) {
        val names = updated.keys.toList()
        playlistNames = names
        playlists = updated
        val editor = prefs.edit().putString("playlist_names", names.joinToString("\u001f"))
        names.forEach { name -> editor.putString("playlist_$name", updated[name].orEmpty().joinToString(",")) }
        editor.apply()
    }
    fun addToPlaylist(name: String, song: MusicSong) {
        val updated = playlists.toMutableMap()
        updated[name] = (updated[name].orEmpty() + song.id.toString()).toSet()
        persistPlaylists(updated)
    }
    fun removeFromPlaylist(name: String, song: MusicSong) {
        val updated = playlists.toMutableMap()
        updated[name] = updated[name].orEmpty() - song.id.toString()
        persistPlaylists(updated)
    }
    fun createPlaylist(name: String) {
        val clean = name.trim()
        if (clean.isBlank() || playlists.containsKey(clean)) return
        val updated = playlists.toMutableMap()
        updated[clean] = emptySet()
        persistPlaylists(updated)
    }
    fun toggleFavorite(song: MusicSong) {
        val key = song.id.toString()
        val updated = favoriteIds.toMutableSet().apply { if (!add(key)) remove(key) }
        favoriteIds = updated
        prefs.edit().putStringSet("favorite_ids", updated).apply()
    }
    fun recordRecent(song: MusicSong) {
        val key = song.id.toString()
        val updated = (listOf(key) + recentIds.filterNot { it == key }).take(30)
        recentIds = updated
        prefs.edit().putString("recent_ids", updated.joinToString(",")).apply()
    }
    var selectedTheme by remember {
        mutableStateOf(
            runCatching {
                AppTheme.valueOf(prefs.getString("theme", AppTheme.Blue.name) ?: AppTheme.Blue.name)
            }.getOrDefault(AppTheme.Blue)
        )
    }
    val accent = selectedTheme.accent
    CompositionLocalProvider(LocalAccentColor provides accent) {
        PixelMusicTheme(accent = accent) {
        PixelMusicContent(
            songs = songs, currentIndex = currentIndex, playing = playing,
            onSongClick = onSongClick, onPlayPause = onPlayPause, onNext = onNext,
            onPrevious = onPrevious, positionProvider = positionProvider,
            durationProvider = durationProvider, onSeekTo = onSeekTo,
            favoriteIds = favoriteIds, recentIds = recentIds,
            onToggleFavorite = ::toggleFavorite, onRecordRecent = ::recordRecent,
            selectedTheme = selectedTheme, onThemeChange = {
                selectedTheme = it
                prefs.edit().putString("theme", it.name).apply()
            },
            queueSongIndices = queueSongIndices,
            onQueueRemove = onQueueRemove,
            onQueueMove = onQueueMove,
            onQueueClear = onQueueClear,
            onQueueAdd = onQueueAdd,
            onUpdateSong = onUpdateSong,
            onNavigate = onNavigate,
            playlistNames = playlistNames,
            playlists = playlists,
            onCreatePlaylist = { createPlaylist(it) },
            onAddToPlaylist = { name, song -> addToPlaylist(name, song) },
            onRemoveFromPlaylist = { name, song -> removeFromPlaylist(name, song) }
        )
        }
    }

}

@Composable
fun PixelMusicContent(
    songs: List<MusicSong>,
    currentIndex: Int,
    playing: Boolean,
    onSongClick: (Int) -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long,
    onSeekTo: (Long) -> Unit,
    favoriteIds: Set<String>,
    recentIds: List<String>,
    onToggleFavorite: (MusicSong) -> Unit,
    onRecordRecent: (MusicSong) -> Unit,
    selectedTheme: AppTheme,
    onThemeChange: (AppTheme) -> Unit,
    queueSongIndices: List<Int>,
    onQueueRemove: (Int) -> Unit,
    onQueueMove: (Int, Int) -> Unit,
    onQueueClear: () -> Unit,
    onQueueAdd: (Int) -> Unit,
    onUpdateSong: (MusicSong) -> Unit,
    onNavigate: (String) -> Unit,
    playlistNames: List<String>,
    playlists: Map<String, Set<String>>,
    onCreatePlaylist: (String) -> Unit,
    onAddToPlaylist: (String, MusicSong) -> Unit,
    onRemoveFromPlaylist: (String, MusicSong) -> Unit
) {
    var drawer by remember { mutableStateOf(false) }
    var fullPlayer by remember { mutableStateOf(false) }
    var editInfo by remember { mutableStateOf(false) }
    var screen by remember { mutableStateOf("Home") }
    val current = songs.getOrNull(currentIndex)
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var heroPull by remember { mutableFloatStateOf(0f) }
    val pullConnection = remember(listState) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: androidx.compose.ui.geometry.Offset, source: NestedScrollSource): androidx.compose.ui.geometry.Offset {
                if (source == NestedScrollSource.UserInput && available.y > 0f && listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset == 0) {
                    val consumed = available.y.coerceAtMost(available.y * 0.72f)
                    heroPull = (heroPull + consumed).coerceIn(0f, 220f)
                    return androidx.compose.ui.geometry.Offset(0f, consumed)
                }
                return androidx.compose.ui.geometry.Offset.Zero
            }
            override suspend fun onPreFling(available: Velocity): Velocity {
                if (heroPull > 0f) {
                    scope.launch {
                        androidx.compose.animation.core.Animatable(heroPull).animateTo(0f) { heroPull = value }
                    }
                }
                return Velocity.Zero
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF08090B))
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            TopBar(
                title = screen,
                onMenu = { drawer = true },
                onSearch = { screen = "Search" }
            )
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (screen) {
                    "Home" -> HomeScreen(
                        songs = songs,
                        currentIndex = currentIndex,
                        current = current,
                        listState = listState,
                        pullConnection = pullConnection,
                        heroPull = heroPull,
                        onHeroOpen = { if (current != null) fullPlayer = true },
                        onQueueAdd = onQueueAdd,
                        playlistNames = playlistNames,
                        onAddToPlaylist = onAddToPlaylist,
                        onSongClick = { index ->
                            songs.getOrNull(index)?.let(onRecordRecent)
                            onSongClick(index)
                        }
                    )
                    "Settings" -> SettingsScreen(
                        selectedTheme = selectedTheme,
                        onThemeChange = onThemeChange
                    )
                    "Search" -> SearchScreen(
                        songs = songs,
                        currentIndex = currentIndex,
                        onSongClick = { index ->
                            songs.getOrNull(index)?.let(onRecordRecent)
                            onSongClick(index)
                        },
                        onQueueAdd = onQueueAdd,
                        playlistNames = playlistNames,
                        onAddToPlaylist = onAddToPlaylist
                    )
                    else -> LibraryScreen(
                        title = screen,
                        songs = songs,
                        currentIndex = currentIndex,
                        favoriteIds = favoriteIds,
                        recentIds = recentIds,
                        onSongClick = { index ->
                            songs.getOrNull(index)?.let(onRecordRecent)
                            onSongClick(index)
                        },
                        onNavigate = { screen = it },
                        queueSongIndices = queueSongIndices,
                        onQueueRemove = onQueueRemove,
                        onQueueMove = onQueueMove,
                        onQueueClear = onQueueClear,
                        onQueueAdd = onQueueAdd,
                        playlistNames = playlistNames,
                        playlists = playlists,
                        onCreatePlaylist = onCreatePlaylist,
                        onAddToPlaylist = onAddToPlaylist,
                        onRemoveFromPlaylist = onRemoveFromPlaylist
                    )
                }
            }
            if (current != null) {
                MiniPlayer(current, playing, onPlayPause, { fullPlayer = true }, onNext, positionProvider, durationProvider)
            }
        }

        if (drawer) {
            NavigationDrawer(
                selected = screen,
                onClose = { drawer = false },
                onSelect = { selected ->
                    screen = selected
                    drawer = false
                }
            )
        }
        if (editInfo && current != null) {
            EditMusicInfoScreen(
                song = current,
                onBack = { editInfo = false },
                onSave = { updated ->
                    onUpdateSong(updated)
                    editInfo = false
                }
            )
        } else if (fullPlayer && current != null) {
            Box(
                Modifier
                    .fillMaxSize()
                    .zIndex(100f)
                    .background(Color(0xFF050607))
            ) {
                FullPlayer(
                    song = current,
                    playing = playing,
                    onBack = { fullPlayer = false },
                    onPlay = onPlayPause,
                    onPrevious = onPrevious,
                    onNext = onNext,
                    positionProvider = positionProvider,
                    durationProvider = durationProvider,
                    onSeekTo = onSeekTo,
                    shuffleEnabled = shuffleEnabled,
                    repeatMode = repeatMode,
                    onToggleShuffle = onToggleShuffle,
                    onCycleRepeat = onCycleRepeat,
                    isFavorite = current.id.toString() in favoriteIds,
                    onToggleFavorite = { onToggleFavorite(current) },
                    onEditInfo = { editInfo = true },
                    onNavigate = { target -> screen = target }
                )
            }
        }
    }
}


@Composable
private fun HomeHero(song: MusicSong?, pull: Float, onOpenPlayer: () -> Unit) {
    val scale = 1f + (pull / 520f).coerceIn(0f, 0.42f)
    Box(
        Modifier
            .fillMaxWidth()
            .height(300.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                translationY = pull * 0.18f
            }
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(
                Brush.verticalGradient(
                    listOf(LocalAccentColor.current.copy(alpha = .34f), Color(0xFF27333D), Color(0xFF101419))
                )
            )
            .clickable(enabled = song != null, onClick = onOpenPlayer)
    ) {
        ArtworkImage(song, Modifier.fillMaxSize(), ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.38f)))
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Bottom
        ) {
            Text(
                "NOW PLAYING",
                color = Color.White.copy(alpha = 0.72f),
                fontSize = 11.sp,
                letterSpacing = 1.5.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                song?.artist?.takeIf { it.isNotBlank() } ?: "Your Music",
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Light,
                maxLines = 1
            )
            Text(
                song?.album?.takeIf { it.isNotBlank() } ?: "Music Library",
                color = Color.White.copy(alpha = 0.78f),
                fontSize = 14.sp,
                maxLines = 1
            )
        }
        if (pull > 8f) {
            Text(
                "Release to return",
                color = Color.White.copy(alpha = (pull / 100f).coerceIn(0f, 0.8f)),
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 18.dp)
            )
        }
    }
}

@Composable
private fun TopBar(title: String, onMenu: () -> Unit, onSearch: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(64.dp).background(
            Brush.horizontalGradient(
                listOf(LocalAccentColor.current.copy(alpha = .28f), Color(0xFF0A0B0D), Color(0xFF0A0B0D))
            )
        ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onMenu) { Icon(Icons.Default.Menu, null, tint = Color.White) }
        Text(title, color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.weight(1f))
        IconButton(onSearch) { Icon(Icons.Default.Search, null, tint = Color.White) }
        IconButton({}) { Icon(Icons.Default.MoreVert, null, tint = Color.White) }
    }
}

@Composable
private fun SearchScreen(
    songs: List<MusicSong>,
    currentIndex: Int,
    onSongClick: (Int) -> Unit,
    onQueueAdd: (Int) -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val results = remember(query, songs) {
        val q = query.trim()
        if (q.isBlank()) emptyList() else songs.filter { song ->
            song.title.contains(q, ignoreCase = true) ||
            song.artist.contains(q, ignoreCase = true) ||
            song.album.contains(q, ignoreCase = true)
        }
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 12.dp),
            placeholder = { Text("曲名・アーティスト・アルバムを検索") },
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Default.Clear, "Clear")
                    }
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = LocalAccentColor.current,
                unfocusedBorderColor = Color(0xFF3B4147),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedPlaceholderColor = Color(0xFF777D83),
                unfocusedPlaceholderColor = Color(0xFF777D83),
                focusedLeadingIconColor = LocalAccentColor.current,
                unfocusedLeadingIconColor = Color(0xFF777D83),
                focusedTrailingIconColor = Color(0xFFB0B5BA),
                unfocusedTrailingIconColor = Color(0xFFB0B5BA)
            )
        )

        if (query.isBlank()) {
            EmptyMessage("曲名・アーティスト・アルバムを入力してください")
        } else if (results.isEmpty()) {
            EmptyMessage("「$query」に一致する曲がありません")
        } else {
            Text(
                "${results.size} results",
                color = Color(0xFF777D83),
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 2.dp)
            )
            LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                itemsIndexed(results) { _, song ->
                    val actualIndex = songs.indexOf(song)
                    SongRow(
                        song = song,
                        selected = actualIndex == currentIndex,
                        onAddToQueue = { if (actualIndex >= 0) onQueueAdd(actualIndex) },
                        playlistNames = playlistNames,
                        onAddToPlaylist = onAddToPlaylist
                    ) { if (actualIndex >= 0) onSongClick(actualIndex) }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    songs: List<MusicSong>,
    currentIndex: Int,
    current: MusicSong?,
    listState: androidx.compose.foundation.lazy.LazyListState,
    pullConnection: NestedScrollConnection,
    heroPull: Float,
    onHeroOpen: () -> Unit,
    onQueueAdd: (Int) -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit,
    onSongClick: (Int) -> Unit
) {
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize().nestedScroll(pullConnection),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        item {
            HomeHero(song = current, pull = heroPull, onOpenPlayer = onHeroOpen)
        }
        item {
            Text(
                "Songs",
                color = LocalAccentColor.current,
                fontSize = 24.sp,
                fontWeight = FontWeight.Light,
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 18.dp)
            )
        }
        if (songs.isEmpty()) {
            item {
                EmptyMessage("音楽ファイルが見つかりません")
            }
        } else {
            itemsIndexed(songs) { index, song ->
                SongRow(song, index == currentIndex, onAddToQueue = { onQueueAdd(index) }, playlistNames = playlistNames, onAddToPlaylist = onAddToPlaylist) { onSongClick(index) }
            }
        }
    }
}

@Composable
private fun LibraryScreen(
    title: String,
    songs: List<MusicSong>,
    currentIndex: Int,
    favoriteIds: Set<String>,
    recentIds: List<String>,
    onSongClick: (Int) -> Unit,
    onNavigate: (String) -> Unit,
    queueSongIndices: List<Int>,
    onQueueRemove: (Int) -> Unit,
    onQueueMove: (Int, Int) -> Unit,
    onQueueClear: () -> Unit,
    onQueueAdd: (Int) -> Unit,
    playlistNames: List<String>,
    playlists: Map<String, Set<String>>,
    onCreatePlaylist: (String) -> Unit,
    onAddToPlaylist: (String, MusicSong) -> Unit,
    onRemoveFromPlaylist: (String, MusicSong) -> Unit
) {
    val visibleSongs = remember(title, songs, favoriteIds, recentIds, playlists) {
        when {
            title == "Favorites" -> songs.filter { it.id.toString() in favoriteIds }
            title == "Recently Played" -> recentIds.mapNotNull { id -> songs.firstOrNull { it.id.toString() == id } }
            title.startsWith("Playlist::") -> {
                val name = title.removePrefix("Playlist::")
                playlists[name].orEmpty().mapNotNull { id -> songs.firstOrNull { it.id.toString() == id } }
            }
            title.startsWith("Artist::") -> {
                val name = title.removePrefix("Artist::")
                songs.filter { it.artist.ifBlank { "Unknown Artist" } == name }
            }
            title.startsWith("Album::") -> {
                val name = title.removePrefix("Album::")
                songs.filter { it.album.ifBlank { "Unknown Album" } == name }
            }
            else -> songs
        }
    }
    var showCreateDialog by remember { mutableStateOf(false) }
    var playlistNameInput by remember { mutableStateOf("") }

    val groups = remember(title, songs) {
        when (title) {
            "Artists" -> songs.groupBy { it.artist.ifBlank { "Unknown Artist" } }
            "Albums" -> songs.groupBy { it.album.ifBlank { "Unknown Album" } }
            else -> emptyMap()
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Text(
                when {
                    title.startsWith("Playlist::") -> title.removePrefix("Playlist::")
                    title.startsWith("Artist::") -> title.removePrefix("Artist::")
                    title.startsWith("Album::") -> title.removePrefix("Album::")
                    else -> title
                },
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Light
            )
            Spacer(Modifier.width(10.dp))
            Text(
                if (title == "Artists" || title == "Albums") "${groups.size}" else "${visibleSongs.size}",
                color = Color(0xFF777D83),
                fontSize = 13.sp,
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }

        if (visibleSongs.isEmpty() && title != "Play Queue" && title != "Playlists") {
            EmptyMessage(
                when {
                    title == "Favorites" -> "お気に入りはまだありません"
                    title == "Recently Played" -> "最近再生した曲はありません"
                    title.startsWith("Playlist::") -> "このプレイリストには曲がありません"
                    title.startsWith("Artist::") -> "このアーティストには曲がありません"
                    title.startsWith("Album::") -> "このアルバムには曲がありません"
                    else -> "音楽ファイルが見つかりません"
                }
            )
        } else {
            when {
                title.startsWith("Artist::") || title.startsWith("Album::") -> {
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        itemsIndexed(visibleSongs) { _, song ->
                            val actualIndex = songs.indexOf(song)
                            SongRow(
                                song = song,
                                selected = actualIndex == currentIndex,
                                onAddToQueue = { if (actualIndex >= 0) onQueueAdd(actualIndex) },
                                playlistNames = playlistNames,
                                onAddToPlaylist = onAddToPlaylist
                            ) { if (actualIndex >= 0) onSongClick(actualIndex) }
                        }
                    }
                }
                title.startsWith("Playlist::") -> {
                    val playlistName = title.removePrefix("Playlist::")
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        itemsIndexed(visibleSongs) { _, song ->
                            val actualIndex = songs.indexOf(song)
                            SongRow(
                                song = song,
                                selected = actualIndex == currentIndex,
                                onAddToQueue = { if (actualIndex >= 0) onQueueAdd(actualIndex) },
                                playlistNames = emptyList(),
                                onAddToPlaylist = { _, _ -> },
                                onRemoveFromPlaylist = { onRemoveFromPlaylist(playlistName, song) },
                                showRemoveFromPlaylist = true
                            ) { if (actualIndex >= 0) onSongClick(actualIndex) }
                        }
                    }
                }
                title == "Favorites" || title == "Recently Played" -> {
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        itemsIndexed(visibleSongs) { _, song ->
                            val actualIndex = songs.indexOf(song)
                            SongRow(
                                song = song,
                                selected = actualIndex == currentIndex,
                                onAddToQueue = { if (actualIndex >= 0) onQueueAdd(actualIndex) },
                                playlistNames = playlistNames,
                                onAddToPlaylist = onAddToPlaylist
                            ) { if (actualIndex >= 0) onSongClick(actualIndex) }
                        }
                    }
                }
                title == "Play Queue" -> {
                    val queueSongs = queueSongIndices.mapNotNull { songs.getOrNull(it) }
                    Column(Modifier.fillMaxSize()) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${queueSongs.size} songs", color = Color(0xFF858C93), fontSize = 13.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = onQueueClear, enabled = queueSongs.isNotEmpty()) {
                                Text("Clear", color = if (queueSongs.isNotEmpty()) LocalAccentColor.current else Color(0xFF555A60))
                            }
                        }
                        LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                            itemsIndexed(queueSongs) { index, song ->
                                val actualIndex = queueSongIndices.getOrNull(index) ?: -1
                                QueueSongRow(
                                    song = song,
                                    position = index + 1,
                                    selected = actualIndex == currentIndex,
                                    onClick = { if (actualIndex >= 0) onSongClick(actualIndex) },
                                    onRemove = { onQueueRemove(index) },
                                    onMoveUp = { if (index > 0) onQueueMove(index, index - 1) },
                                    onMoveDown = { if (index < queueSongs.lastIndex) onQueueMove(index, index + 1) }
                                )
                            }
                        }
                    }
                }
                title == "Playlists" -> {
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        item {
                            PlaylistRow("Favorites", "Your favorite songs", favoriteIds.size, Icons.Default.Favorite) { onNavigate("Favorites") }
                        }
                        item {
                            PlaylistRow("Recently Played", "Songs played on this device", recentIds.size, Icons.Default.History) { onNavigate("Recently Played") }
                        }
                        playlistNames.forEach { playlistName ->
                            item(key = "playlist_$playlistName") {
                                PlaylistRow(
                                    playlistName,
                                    "Custom playlist",
                                    playlists[playlistName].orEmpty().size,
                                    Icons.Default.QueueMusic
                                ) { onNavigate("Playlist::$playlistName") }
                            }
                        }
                        item {
                            PlaylistRow("New Playlist", "Create a playlist", null, Icons.Default.Add) { showCreateDialog = true }
                        }
                    }
                }
                title == "Artists" || title == "Albums" -> {
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        groups.entries.forEach { (name, groupedSongs) ->
                            item(key = name) {
                                LibraryGroupRow(
                                    title = name,
                                    subtitle = "${groupedSongs.size} ${if (title == "Artists") "songs" else "tracks"}",
                                    isArtist = title == "Artists",
                                    seed = groupedSongs.firstOrNull()?.title?.hashCode()?.let { kotlin.math.abs(it) } ?: 0
                                ) {
                                    onNavigate("${if (title == "Artists") "Artist::" else "Album::"}$name")
                                }
                            }
                        }
                    }
                }
                title == "Songs" -> {
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        itemsIndexed(songs) { index, song ->
                            SongRow(
                                song = song,
                                selected = index == currentIndex,
                                onAddToQueue = { onQueueAdd(index) },
                                playlistNames = playlistNames,
                                onAddToPlaylist = onAddToPlaylist
                            ) { onSongClick(index) }
                        }
                    }
                }
                else -> SectionPlaceholder(title)
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false; playlistNameInput = "" },
            title = { Text("New Playlist") },
            text = {
                OutlinedTextField(
                    value = playlistNameInput,
                    onValueChange = { playlistNameInput = it },
                    label = { Text("Playlist name") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onCreatePlaylist(playlistNameInput)
                        showCreateDialog = false
                        playlistNameInput = ""
                    },
                    enabled = playlistNameInput.trim().isNotBlank() && !playlistNames.contains(playlistNameInput.trim())
                ) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false; playlistNameInput = "" }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun QueueSongRow(
    song: MusicSong,
    position: Int,
    selected: Boolean,
    onClick: () -> Unit,
    onRemove: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            position.toString(),
            color = if (selected) LocalAccentColor.current else Color(0xFF70767C),
            fontSize = 12.sp,
            modifier = Modifier.width(28.dp)
        )
        AlbumArt(song = song, size = 50.dp)
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(song.title, color = if (selected) LocalAccentColor.current else Color.White, maxLines = 1, fontSize = 15.sp)
            Text(song.artist, color = Color(0xFF9AA0A6), fontSize = 12.sp, maxLines = 1)
        }
        if (selected) {
            Icon(Icons.Default.GraphicEq, null, tint = LocalAccentColor.current)
        } else {
            Row {
                IconButton(onClick = onMoveUp, enabled = true) { Icon(Icons.Default.KeyboardArrowUp, null, tint = Color(0xFF777D83)) }
                IconButton(onClick = onMoveDown, enabled = true) { Icon(Icons.Default.KeyboardArrowDown, null, tint = Color(0xFF777D83)) }
                IconButton(onClick = onRemove) { Icon(Icons.Default.Close, null, tint = Color(0xFF999FA5)) }
            }
        }
    }
    HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
}

@Composable
private fun PlaylistRow(
    title: String,
    subtitle: String,
    count: Int?,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(58.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF20262C)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = LocalAccentColor.current, modifier = Modifier.size(28.dp))
        }
        Column(Modifier.weight(1f).padding(start = 16.dp)) {
            Text(title, color = Color.White, fontSize = 17.sp)
            Text(
                if (count == null) subtitle else "$subtitle • $count songs",
                color = Color(0xFF8F969D),
                fontSize = 13.sp,
                maxLines = 1
            )
        }
        Icon(Icons.Default.ChevronRight, null, tint = Color(0xFF777D83))
    }
    HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
}

@Composable
private fun LibraryGroupRow(title: String, subtitle: String, isArtist: Boolean, seed: Int, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (isArtist) ArtistArt(62.dp, seed) else AlbumArt(size = 62.dp)
        Column(Modifier.weight(1f).padding(start = 16.dp)) {
            Text(title, color = Color.White, fontSize = 17.sp, maxLines = 1)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, color = Color(0xFF8F969D), fontSize = 13.sp, maxLines = 1)
        }
        Icon(if (isArtist) Icons.Default.ChevronRight else Icons.Default.MoreVert, null, tint = Color(0xFF777D83))
    }
    HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
}

@Composable
private fun ArtistArt(size: Dp, seed: Int) {
    val palettes = listOf(
        listOf(Color(0xFF536778), Color(0xFF17212A)),
        listOf(Color(0xFF744C5C), Color(0xFF20151C)),
        listOf(Color(0xFF5B704E), Color(0xFF182017)),
        listOf(Color(0xFF6B5A82), Color(0xFF211B2B))
    )
    val palette = palettes[seed % palettes.size]
    Box(Modifier.size(size).clip(RoundedCornerShape(50)).background(Brush.linearGradient(palette)), contentAlignment = Alignment.Center) {
        Icon(Icons.Default.Person, null, tint = Color.White.copy(alpha = .82f), modifier = Modifier.size(size * .48f))
    }
}

@Composable
private fun SettingsScreen(
    selectedTheme: AppTheme,
    onThemeChange: (AppTheme) -> Unit
) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        item {
            Spacer(Modifier.height(18.dp))
            Text("Theme", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            Text("テーマカラー", color = Color(0xFF8F969D), fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
        }
        itemsIndexed(AppTheme.values().toList()) { _, theme ->
            val selected = theme == selectedTheme
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                    .background(if (selected) theme.accent.copy(alpha = .16f) else Color.Transparent)
                    .clickable { onThemeChange(theme) }
                    .padding(horizontal = 14.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(30.dp).clip(RoundedCornerShape(50)).background(theme.accent))
                Column(Modifier.weight(1f).padding(start = 14.dp)) {
                    Text(theme.label, color = Color.White, fontSize = 16.sp)
                    Text(theme.description, color = Color(0xFF8F969D), fontSize = 12.sp)
                }
                if (selected) Icon(Icons.Default.Check, null, tint = theme.accent)
            }
            Spacer(Modifier.height(5.dp))
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
}

@Composable
private fun SectionPlaceholder(title: String) {
    Column(Modifier.fillMaxWidth().padding(22.dp)) {
        Text(
            when (title) {
                "Play Queue" -> "再生キュー"
                "Playlists" -> "プレイリスト"
                "Folders" -> "フォルダ"
                "Google Drive" -> "Google Drive"
                "New Releases" -> "新着リリース"
                "Charts" -> "チャート"
                "Settings" -> "設定"
                else -> title
            },
            color = Color.White,
            fontSize = 18.sp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "この画面の詳細UIは次の段階で実装します。",
            color = Color(0xFF858C93),
            fontSize = 13.sp
        )
    }
}

@Composable
private fun EmptyMessage(message: String) {
    Text(
        message,
        color = Color(0xFF9AA0A6),
        modifier = Modifier.padding(horizontal = 22.dp)
    )
}

@Composable
private fun SongRow(
    song: MusicSong,
    selected: Boolean,
    onAddToQueue: () -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit,
    onRemoveFromPlaylist: () -> Unit = {},
    showRemoveFromPlaylist: Boolean = false,
    onClick: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AlbumArt(song = song, size = 56.dp)
            Column(Modifier.weight(1f).padding(start = 16.dp)) {
                Text(song.title.ifBlank { "Unknown title" }, color = if (selected) LocalAccentColor.current else Color.White, maxLines = 1, fontSize = 16.sp)
                Text(listOf(song.artist, song.album).filter { it.isNotBlank() }.joinToString(" • "), color = Color(0xFF9AA0A6), fontSize = 13.sp, maxLines = 1)
            }
            if (selected && song.title.isNotBlank()) {
                Icon(Icons.Default.GraphicEq, null, tint = LocalAccentColor.current)
            } else {
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.MoreVert, "More", tint = Color(0xFF777B80))
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Add to Play Queue") },
                            leadingIcon = { Icon(Icons.Default.QueueMusic, null) },
                            onClick = {
                                menuOpen = false
                                onAddToQueue()
                            }
                        )
                        playlistNames.forEach { playlistName ->
                            DropdownMenuItem(
                                text = { Text("Add to $playlistName") },
                                leadingIcon = { Icon(Icons.Default.PlaylistAdd, null) },
                                onClick = {
                                    menuOpen = false
                                    onAddToPlaylist(playlistName, song)
                                }
                            )
                        }
                        if (playlistNames.isEmpty()) {
                            DropdownMenuItem(
                                text = { Text("No custom playlists yet") },
                                enabled = false,
                                onClick = { }
                            )
                        }
                        if (showRemoveFromPlaylist) {
                            DropdownMenuItem(
                                text = { Text("Remove from Playlist") },
                                leadingIcon = { Icon(Icons.Default.RemoveCircleOutline, null) },
                                onClick = {
                                    menuOpen = false
                                    onRemoveFromPlaylist()
                                }
                            )
                        }
                    }
                }
            }
        }
        HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
    }
}

private object ArtworkBitmapCache {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    @Synchronized
    fun get(key: String): Bitmap? = cache.get(key)

    @Synchronized
    fun put(key: String, bitmap: Bitmap): Bitmap {
        cache.put(key, bitmap)
        return bitmap
    }
}

private val artworkLoadSemaphore = Semaphore(2)

private fun artworkCacheKey(song: MusicSong, overridePath: String?, targetPx: Int): String {
    val source = overridePath?.takeIf { it.isNotBlank() } ?: song.artworkUriString ?: song.uriString
    return "$source|${targetPx.coerceAtLeast(64)}"
}

private fun calculateSampleSize(width: Int, height: Int, targetPx: Int): Int {
    val target = targetPx.coerceAtLeast(64)
    var sample = 1
    while (width / sample > target * 2 || height / sample > target * 2) {
        sample *= 2
    }
    return sample
}

private fun decodeSampledFile(path: String, targetPx: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    val options = BitmapFactory.Options().apply {
        inSampleSize = calculateSampleSize(bounds.outWidth, bounds.outHeight, targetPx)
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    return BitmapFactory.decodeFile(path, options)
}

private fun decodeSampledBytes(bytes: ByteArray, targetPx: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    val options = BitmapFactory.Options().apply {
        inSampleSize = calculateSampleSize(bounds.outWidth, bounds.outHeight, targetPx)
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
}

private suspend fun loadArtworkBitmap(
    context: android.content.Context,
    song: MusicSong,
    overridePath: String?,
    targetPx: Int
): Bitmap? = withContext(Dispatchers.IO) {
    val key = artworkCacheKey(song, overridePath, targetPx)
    ArtworkBitmapCache.get(key)?.let { return@withContext it }

    artworkLoadSemaphore.withPermit {
        ArtworkBitmapCache.get(key)?.let { return@withPermit it }
        val bitmap = runCatching {
            // 1) User-selected artwork saved by the edit screen.
            if (!overridePath.isNullOrBlank() && File(overridePath).exists()) {
                decodeSampledFile(overridePath, targetPx)
            } else {
                // 2) MediaStore album artwork URI.
                var result: Bitmap? = null
                song.artworkUriString?.let { artworkUriString ->
                    result = runCatching {
                        context.contentResolver.openInputStream(Uri.parse(artworkUriString))?.use { input ->
                            input.readBytes().let { bytes -> decodeSampledBytes(bytes, targetPx) }
                        }
                    }.getOrNull()
                }

                // 3) Embedded artwork inside the audio file as a fallback.
                if (result == null) {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(context, Uri.parse(song.uriString))
                        retriever.embeddedPicture?.let { bytes ->
                            result = decodeSampledBytes(bytes, targetPx)
                        }
                    } finally {
                        retriever.release()
                    }
                }
                result
            }
        }.getOrNull()

        bitmap?.let { ArtworkBitmapCache.put(key, it) }
        bitmap
    }
}

@Composable
private fun rememberArtworkBitmap(song: MusicSong?, overridePath: String?, targetPx: Int): Bitmap? {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(song?.uriString, song?.artworkUriString, overridePath, targetPx) {
        mutableStateOf<Bitmap?>(null)
    }
    LaunchedEffect(song?.uriString, song?.artworkUriString, overridePath, targetPx) {
        bitmap = null
        if (song != null) {
            bitmap = loadArtworkBitmap(
                context = context,
                song = song,
                overridePath = overridePath,
                targetPx = targetPx
            )
        }
    }
    return bitmap
}

@Composable
private fun ArtworkImage(song: MusicSong?, modifier: Modifier, contentScale: ContentScale) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("pixelmusic_artwork", android.content.Context.MODE_PRIVATE) }
    val overridePath = song?.id?.let { prefs.getString("art_$it", null) }
    val density = androidx.compose.ui.platform.LocalDensity.current.density
    val targetPx = (420f * density).roundToInt().coerceAtMost(1024)
    val bitmap = rememberArtworkBitmap(song, overridePath, targetPx)

    Box(modifier.background(Brush.verticalGradient(listOf(LocalAccentColor.current.copy(alpha=.55f), Color(0xFF101419))))) {
        bitmap?.let {
            Image(bitmap = it.asImageBitmap(), contentDescription = song?.album ?: "Album artwork", modifier = Modifier.fillMaxSize(), contentScale = contentScale)
        }
    }
}

@Composable
private fun AlbumArt(
    song: MusicSong? = null,
    size: Dp,
    modifier: Modifier = Modifier,
    showFallback: Boolean = true
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("pixelmusic_artwork", android.content.Context.MODE_PRIVATE) }
    val overridePath = song?.id?.let { prefs.getString("art_$it", null) }
    val density = androidx.compose.ui.platform.LocalDensity.current.density
    val targetPx = (size.value * density).roundToInt().coerceAtLeast(96).coerceAtMost(1024)
    val bitmap = rememberArtworkBitmap(song, overridePath, targetPx)

    Box(
        modifier
            .then(Modifier.size(size))
            .clip(RoundedCornerShape(7.dp))
            .background(
                Brush.linearGradient(
                    listOf(LocalAccentColor.current.copy(alpha = .88f), Color(0xFF11151A), Color(0xFF20252B))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = song?.album ?: "Album artwork",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .08f)))
        } else if (showFallback) {
            Icon(Icons.Default.MusicNote, null, tint = Color.White.copy(alpha = .82f), modifier = Modifier.size(size * .43f))
        }
    }
}

@Composable
private fun MiniPlayer(
    song: MusicSong,
    playing: Boolean,
    onPlay: () -> Unit,
    onOpen: () -> Unit,
    onNext: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long
) {
    var positionMs by remember(song.uriString) { mutableLongStateOf(positionProvider().coerceAtLeast(0L)) }
    var durationMs by remember(song.uriString) { mutableLongStateOf(durationProvider().coerceAtLeast(song.duration)) }

    LaunchedEffect(playing, song.uriString) {
        while (true) {
            positionMs = positionProvider().coerceAtLeast(0L)
            val latestDuration = durationProvider().coerceAtLeast(0L)
            if (latestDuration > 0L) durationMs = latestDuration
            if (!playing) break
            delay(500L)
        }
    }

    val progress = if (durationMs > 0L) (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f

    Column(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFF15181C))
            .clickable(onClick = onOpen)
    ) {
        Box(Modifier.fillMaxWidth().height(2.dp).background(Color.White.copy(alpha = .14f))) {
            Box(Modifier.fillMaxWidth(progress).fillMaxHeight().background(LocalAccentColor.current))
        }
        Row(
            Modifier.fillMaxWidth().height(70.dp).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AlbumArt(song = song, size = 48.dp)
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(song.title, color = Color.White, maxLines = 1, fontSize = 15.sp)
                Text(song.artist, color = Color(0xFF9AA0A6), fontSize = 12.sp, maxLines = 1)
            }
            IconButton(onPlay) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White)
            }
            IconButton(onNext) {
                Icon(Icons.Default.SkipNext, null, tint = Color.White)
            }
        }
    }
}

@Composable
private fun NavigationDrawer(
    selected: String,
    onClose: () -> Unit,
    onSelect: (String) -> Unit
) {
    Row(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .width(300.dp)
                .fillMaxHeight()
                .background(Color(0xFF121417))
                .padding(top = 32.dp)
        ) {
            Text(
                "PIXEL MUSIC",
                color = LocalAccentColor.current,
                fontSize = 22.sp,
                fontWeight = FontWeight.Light,
                modifier = Modifier.padding(24.dp)
            )
            listOf(
                "Home", "Play Queue", "Playlists", "Artists", "Albums", "Songs",
                "Genres", "Folders", "Google Drive", "New Releases", "Charts", "Settings"
            ).forEach { item ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(item) }
                        .background(
                            if (item == selected) LocalAccentColor.current.copy(alpha = .16f) else Color.Transparent
                        )
                        .padding(horizontal = 24.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        item,
                        color = if (item == selected) LocalAccentColor.current else Color(0xFFE2E5E8),
                        fontSize = 15.sp
                    )
                }
            }
        }
        Spacer(
            Modifier
                .fillMaxSize()
                .weight(1f)
                .background(Color.Black.copy(alpha = .55f))
                .clickable(onClick = onClose)
        )
    }
}

@Composable
private fun FullPlayer(
    song: MusicSong,
    playing: Boolean,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long,
    onSeekTo: (Long) -> Unit,
    shuffleEnabled: Boolean,
    repeatMode: Int,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onEditInfo: () -> Unit,
    onNavigate: (String) -> Unit = {}
) {
    // Xperia-inspired player: artwork-focused layout, compact metadata, and clear transport controls.
    var positionMs by remember(song.uriString) { mutableLongStateOf(positionProvider().coerceAtLeast(0L)) }
    var durationMs by remember(song.uriString) { mutableLongStateOf(durationProvider().coerceAtLeast(0L)) }

    LaunchedEffect(playing, song.uriString) {
        while (true) {
            positionMs = positionProvider().coerceAtLeast(0L)
            val latestDuration = durationProvider().coerceAtLeast(0L)
            if (latestDuration > 0L) durationMs = latestDuration
            if (!playing) break
            delay(500L)
        }
    }

    val safeDuration = durationMs.coerceAtLeast(1L)
    val sliderValue = (positionMs.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        LocalAccentColor.current.copy(alpha = .82f),
                        Color(0xFF20262C),
                        Color(0xFF08090B),
                        Color(0xFF050607)
                    )
                )
            )
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 20.dp)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(58.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onBack) {
                    Icon(Icons.Default.KeyboardArrowDown, "Close player", tint = Color.White)
                }
                Spacer(Modifier.weight(1f))
                Text(
                    "NOW PLAYING",
                    color = Color.White.copy(alpha = .72f),
                    fontSize = 11.sp,
                    letterSpacing = 1.4.sp
                )
                Spacer(Modifier.weight(1f))
                var moreOpen by remember { mutableStateOf(false) }
                Box {
                    IconButton({ moreOpen = true }) {
                        Icon(Icons.Default.MoreVert, "More", tint = Color.White)
                    }
                    DropdownMenu(
                        expanded = moreOpen,
                        onDismissRequest = { moreOpen = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("ミュージック情報を編集") },
                            onClick = {
                                moreOpen = false
                                onEditInfo()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("アーティスト") },
                            onClick = {
                                moreOpen = false
                                onBack()
                                onNavigate("Artist::${song.artist.ifBlank { "Unknown Artist" }}")
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("アルバム") },
                            onClick = {
                                moreOpen = false
                                onBack()
                                onNavigate("Album::${song.album.ifBlank { "Unknown Album" }}")
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            Box(
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                AlbumArt(song = song, size = 320.dp)
            }

            Spacer(Modifier.height(20.dp))

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        song.title,
                        color = LocalAccentColor.current,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Normal,
                        maxLines = 1
                    )
                    Text(
                        song.artist,
                        color = Color(0xFFD0D5DA),
                        fontSize = 15.sp,
                        maxLines = 1
                    )
                    Text(
                        song.album,
                        color = Color(0xFF9299A1),
                        fontSize = 13.sp,
                        maxLines = 1
                    )
                    Text(
                        "LOCAL MUSIC  •  ${song.duration / 1000}s",
                        color = Color(0xFF70777E),
                        fontSize = 10.sp,
                        letterSpacing = 0.8.sp,
                        maxLines = 1
                    )
                }
                IconButton(onToggleFavorite) {
                    Icon(
                        if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        "Favorite",
                        tint = LocalAccentColor.current,
                        modifier = Modifier.size(27.dp)
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            Slider(
                value = sliderValue,
                onValueChange = { fraction ->
                    positionMs = (safeDuration * fraction).toLong().coerceIn(0L, safeDuration)
                },
                onValueChangeFinished = {
                    onSeekTo(positionMs.coerceIn(0L, safeDuration))
                },
                modifier = Modifier.fillMaxWidth(),
                colors = SliderDefaults.colors(
                    thumbColor = LocalAccentColor.current,
                    activeTrackColor = LocalAccentColor.current,
                    inactiveTrackColor = LocalAccentColor.current.copy(alpha = .28f)
                )
            )

            Row(Modifier.fillMaxWidth()) {
                Text(formatDuration(positionMs), color = Color(0xFF9DA4AA), fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Text(formatDuration(durationMs), color = Color(0xFF9DA4AA), fontSize = 11.sp)
            }

            Spacer(Modifier.height(8.dp))

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                IconButton(onToggleShuffle) {
                    Icon(Icons.Default.Shuffle, "Shuffle", tint = if (shuffleEnabled) LocalAccentColor.current else Color.White.copy(alpha = .9f))
                }
                IconButton(onPrevious, modifier = Modifier.size(52.dp)) {
                    Icon(Icons.Default.SkipPrevious, "Previous", tint = LocalAccentColor.current, modifier = Modifier.size(31.dp))
                }
                FilledIconButton(
                    onClick = onPlay,
                    modifier = Modifier.size(70.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = LocalAccentColor.current,
                        contentColor = Color(0xFF111316)
                    )
                ) {
                    Icon(
                        if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                        "Play or pause",
                        modifier = Modifier.size(36.dp)
                    )
                }
                IconButton(onNext, modifier = Modifier.size(52.dp)) {
                    Icon(Icons.Default.SkipNext, "Next", tint = LocalAccentColor.current, modifier = Modifier.size(31.dp))
                }
                IconButton(onCycleRepeat) {
                    Icon(Icons.Default.Repeat, "Repeat", tint = if (repeatMode != 0) LocalAccentColor.current else Color.White.copy(alpha = .9f))
                }
            }

            Spacer(Modifier.height(14.dp))

            Row(
                Modifier
                    .fillMaxWidth()
                    .height(36.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${song.artist}  •  ${song.album}",
                    color = Color(0xFF858C93),
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}


@Composable
private fun EditMusicInfoScreen(
    song: MusicSong,
    onBack: () -> Unit,
    onSave: (MusicSong) -> Unit
) {
    var title by remember(song.uriString) { mutableStateOf(song.title) }
    var artist by remember(song.uriString) { mutableStateOf(song.artist) }
    var album by remember(song.uriString) { mutableStateOf(song.album) }
    var disc by remember(song.uriString) { mutableStateOf("1") }
    var track by remember(song.uriString) { mutableStateOf("") }
    var year by remember(song.uriString) { mutableStateOf("") }
    var genre by remember(song.uriString) { mutableStateOf("") }
    var artworkSet by remember(song.uriString) { mutableStateOf(false) }
    var selectedImageUri by remember(song.uriString) { mutableStateOf<Uri?>(null) }
    var cropScreen by remember(song.uriString) { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("pixelmusic_artwork", android.content.Context.MODE_PRIVATE) }
    var customArtworkPath by remember(song.uriString) { mutableStateOf(prefs.getString("art_${song.id}", null)) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedImageUri = uri
            artworkSet = true
            cropScreen = true
        }
    }

    if (cropScreen && selectedImageUri != null) {
        CropArtworkScreen(
            uri = selectedImageUri!!,
            onBack = { cropScreen = false },
            onDone = { cropped ->
                customArtworkPath = cropped
                prefs.edit().putString("art_${song.id}", cropped).apply()
                cropScreen = false
                artworkSet = true
            }
        )
        return
    }

    Box(
        Modifier.fillMaxSize().background(Color(0xFF08090B))
    ) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(
                Modifier.fillMaxWidth().height(64.dp).background(Color(0xFF0A0B0D)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onBack) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
                }
                Text("ミュージック情報を編集", color = Color.White, fontSize = 19.sp)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = {
                    onSave(song.copy(title = title, artist = artist, album = album))
                }) {
                    Text("保存", color = LocalAccentColor.current)
                }
            }

            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(20.dp)
            ) {
                item {
                    Row(
                        Modifier.fillMaxWidth().padding(bottom = 22.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AlbumArt(song = song, size = 108.dp)
                        Column(Modifier.padding(start = 18.dp)) {
                            Text("アートワーク", color = Color.White, fontSize = 17.sp)
                            Spacer(Modifier.height(10.dp))
                            Row {
                                OutlinedButton(onClick = { imagePicker.launch("image/*") }) {
                                    Text("画像を設定")
                                }
                                Spacer(Modifier.width(8.dp))
                                OutlinedButton(onClick = {
                                    artworkSet = false
                                    customArtworkPath = null
                                    prefs.edit().remove("art_${song.id}").apply()
                                }) {
                                    Text("画像を削除")
                                }
                            }
                            if (artworkSet) {
                                Text(
                                    if (selectedImageUri != null) "選択した画像を使用します。" else "画像が設定されています。",
                                    color = Color(0xFF858C93),
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(top = 7.dp)
                                )
                            }
                        }
                    }
                }
                item { EditField("タイトル", title) { title = it } }
                item { EditField("アーティスト", artist) { artist = it } }
                item { EditField("アルバム", album) { album = it } }
                item { EditField("ディスク", disc) { disc = it } }
                item { EditField("トラック", track) { track = it } }
                item { EditField("年", year) { year = it } }
                item { EditField("ジャンル", genre) { genre = it } }
                item {
                    Text(
                        "※ v0.14では編集画面の骨格を実装しています。保存処理と画像トリミングは次の段階で接続します。",
                        color = Color(0xFF777D83),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 18.dp, bottom = 20.dp)
                    )
                }
            }
        }
    }
}


@Composable
private fun CropArtworkScreen(
    uri: Uri,
    onBack: () -> Unit,
    onDone: (String) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(uri) { mutableStateOf<android.graphics.Bitmap?>(null) }
    var zoom by remember(uri) { mutableFloatStateOf(1f) }
    LaunchedEffect(uri) {
        bitmap = withContext(Dispatchers.IO) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }.getOrNull()
        }
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF08090B))) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(Modifier.fillMaxWidth().height(64.dp).background(Color(0xFF0A0B0D)), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
                Text("トリミング（フレーミング）", color = Color.White, fontSize = 18.sp)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = {
                    val source = bitmap
                    if (source != null) {
                        val side = minOf(source.width, source.height)
                        val left = (source.width - side) / 2
                        val top = (source.height - side) / 2
                        val square = Bitmap.createBitmap(source, left, top, side, side)
                        val file = File(context.filesDir, "artwork_${uri.toString().hashCode().absoluteValue}.jpg")
                        file.outputStream().use { out -> square.compress(Bitmap.CompressFormat.JPEG, 94, out) }
                        onDone(file.absolutePath)
                    }
                }) { Text("完了", color = LocalAccentColor.current) }
            }
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(Modifier.size(310.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF15181C)), contentAlignment = Alignment.Center) {
                    bitmap?.let {
                        Image(
                            bitmap = it.asImageBitmap(),
                            contentDescription = "Selected artwork",
                            modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = zoom; scaleY = zoom },
                            contentScale = ContentScale.Crop
                        )
                    } ?: Text("画像を読み込み中…", color = Color(0xFF858C93))
                    Box(Modifier.size(310.dp).border(2.dp, Color.White.copy(alpha = .85f), RoundedCornerShape(8.dp)))
                }
            }
            Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 18.dp)) {
                Text("フレーミング", color = Color.White, fontSize = 15.sp)
                Slider(value = zoom, onValueChange = { zoom = it }, valueRange = 1f..2.2f, colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White, inactiveTrackColor = Color.White.copy(alpha = .25f)))
                Text("画像を拡大してジャケットの見え方を調整できます。", color = Color(0xFF858C93), fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun EditField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedBorderColor = LocalAccentColor.current,
            unfocusedBorderColor = Color(0xFF4B5157),
            focusedLabelColor = LocalAccentColor.current,
            unfocusedLabelColor = Color(0xFF858C93),
            cursorColor = LocalAccentColor.current
        )
    )
}

private fun formatDuration(milliseconds: Long): String {
    val totalSeconds = (milliseconds / 1000L).coerceAtLeast(0L)
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return "%d:%02d".format(minutes, seconds)
}
