package com.example.pixelmusic.ui

import com.example.pixelmusic.MusicSong
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.Velocity
import kotlinx.coroutines.launch
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.absoluteValue

@Composable
fun PixelMusicApp(
    songs: List<MusicSong>,
    currentIndex: Int,
    playing: Boolean,
    onSongClick: (Int) -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long,
    onSeekTo: (Long) -> Unit
) {
    var drawer by remember { mutableStateOf(false) }
    var fullPlayer by remember { mutableStateOf(false) }
    var editInfo by remember { mutableStateOf(false) }
    var screen by remember { mutableStateOf("Home") }
    val current = songs.getOrNull(currentIndex)
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var heroPull by remember { mutableFloatStateOf(0f) }
    val pullConnection = remember(listState) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: androidx.compose.ui.geometry.Offset, source: NestedScrollSource): androidx.compose.ui.geometry.Offset {
                if (source == NestedScrollSource.UserInput && available.y > 0f && listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset == 0) {
                    val consumed = available.y.coerceAtMost(available.y * 0.72f)
                    heroPull = (heroPull + consumed).coerceIn(0f, 220f)
                    return androidx.compose.ui.geometry.Offset(0f, consumed)
                }
                return androidx.compose.ui.geometry.Offset.Zero
            }
            override suspend fun onPreFling(available: Velocity): Velocity {
                if (heroPull > 0f) {
                    scope.launch {
                        androidx.compose.animation.core.Animatable(heroPull).animateTo(0f) { heroPull = value }
                    }
                }
                return Velocity.Zero
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .background(Color(0xFF08090B))
    ) {
        Column(Modifier.fillMaxSize()) {
            TopBar(
                title = screen,
                onMenu = { drawer = true }
            )
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (screen) {
                    "Home" -> HomeScreen(
                        songs = songs,
                        currentIndex = currentIndex,
                        current = current,
                        listState = listState,
                        pullConnection = pullConnection,
                        heroPull = heroPull,
                        onHeroOpen = { if (current != null) fullPlayer = true },
                        onSongClick = onSongClick
                    )
                    else -> LibraryScreen(
                        title = screen,
                        songs = songs,
                        currentIndex = currentIndex,
                        onSongClick = onSongClick
                    )
                }
            }
            if (current != null) {
                MiniPlayer(current, playing, onPlayPause, { fullPlayer = true }, onNext, positionProvider, durationProvider)
            }
        }

        if (drawer) {
            NavigationDrawer(
                selected = screen,
                onClose = { drawer = false },
                onSelect = { selected ->
                    screen = selected
                    drawer = false
                }
            )
        }
        if (fullPlayer && current != null) {
            FullPlayer(
                song = current,
                playing = playing,
                onBack = { fullPlayer = false },
                onPlay = onPlayPause,
                onPrevious = onPrevious,
                onNext = onNext,
                positionProvider = positionProvider,
                durationProvider = durationProvider,
                onSeekTo = onSeekTo,
                onEditInfo = { editInfo = true }
            )
        }
        if (editInfo && current != null) {
            EditMusicInfoScreen(
                song = current,
                onBack = { editInfo = false },
                onSave = { editInfo = false }
            )
        }
    }
}


@Composable
private fun HomeHero(song: MusicSong?, pull: Float, onOpenPlayer: () -> Unit) {
    val scale = 1f + (pull / 520f).coerceIn(0f, 0.42f)
    Box(
        Modifier
            .fillMaxWidth()
            .height(300.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                translationY = pull * 0.18f
            }
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF536778), Color(0xFF27333D), Color(0xFF101419))
                )
            )
            .clickable(enabled = song != null, onClick = onOpenPlayer)
    ) {
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.16f)))
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Bottom
        ) {
            Text(
                "NOW PLAYING",
                color = Color.White.copy(alpha = 0.72f),
                fontSize = 11.sp,
                letterSpacing = 1.5.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                song?.artist?.takeIf { it.isNotBlank() } ?: "Your Music",
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Light,
                maxLines = 1
            )
            Text(
                song?.album?.takeIf { it.isNotBlank() } ?: "Music Library",
                color = Color.White.copy(alpha = 0.78f),
                fontSize = 14.sp,
                maxLines = 1
            )
        }
        if (pull > 8f) {
            Text(
                "Release to return",
                color = Color.White.copy(alpha = (pull / 100f).coerceIn(0f, 0.8f)),
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 18.dp)
            )
        }
    }
}

@Composable
private fun TopBar(title: String, onMenu: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(64.dp).background(Color(0xFF0A0B0D)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onMenu) { Icon(Icons.Default.Menu, null, tint = Color.White) }
        Text(title, color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.weight(1f))
        IconButton({}) { Icon(Icons.Default.Search, null, tint = Color.White) }
        IconButton({}) { Icon(Icons.Default.MoreVert, null, tint = Color.White) }
    }
}

@Composable
private fun HomeScreen(
    songs: List<MusicSong>,
    currentIndex: Int,
    current: MusicSong?,
    listState: androidx.compose.foundation.lazy.LazyListState,
    pullConnection: NestedScrollConnection,
    heroPull: Float,
    onHeroOpen: () -> Unit,
    onSongClick: (Int) -> Unit
) {
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize().nestedScroll(pullConnection),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        item {
            HomeHero(song = current, pull = heroPull, onOpenPlayer = onHeroOpen)
        }
        item {
            Text(
                "Songs",
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Light,
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 18.dp)
            )
        }
        if (songs.isEmpty()) {
            item {
                EmptyMessage("音楽ファイルが見つかりません")
            }
        } else {
            itemsIndexed(songs) { index, song ->
                SongRow(song, index == currentIndex) { onSongClick(index) }
            }
        }
    }
}

@Composable
private fun LibraryScreen(
    title: String,
    songs: List<MusicSong>,
    currentIndex: Int,
    onSongClick: (Int) -> Unit
) {
    val groups = remember(title, songs) {
        when (title) {
            "Artists" -> songs.groupBy { it.artist.ifBlank { "Unknown Artist" } }
            "Albums" -> songs.groupBy { it.album.ifBlank { "Unknown Album" } }
            else -> emptyMap()
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp), verticalAlignment = Alignment.Bottom) {
            Text(title, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Light)
            Spacer(Modifier.width(10.dp))
            Text(if (title == "Artists" || title == "Albums") "${groups.size}" else "${songs.size}", color = Color(0xFF777D83), fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp))
        }

        if (songs.isEmpty()) {
            EmptyMessage("音楽ファイルが見つかりません")
        } else {
            when (title) {
                "Play Queue" -> {
                    val queueSongs = if (currentIndex in songs.indices) {
                        songs.drop(currentIndex) + songs.take(currentIndex)
                    } else songs
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        item {
                            Text(
                                "${queueSongs.size} songs",
                                color = Color(0xFF858C93),
                                fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 22.dp, vertical = 4.dp)
                            )
                        }
                        itemsIndexed(queueSongs) { index, song ->
                            val actualIndex = songs.indexOf(song)
                            QueueSongRow(
                                song = song,
                                position = index + 1,
                                selected = actualIndex == currentIndex,
                                onClick = { if (actualIndex >= 0) onSongClick(actualIndex) }
                            )
                        }
                    }
                }
                "Playlists" -> {
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        item {
                            PlaylistRow(
                                title = "Favorites",
                                subtitle = "Your favorite songs",
                                count = 0,
                                icon = Icons.Default.Favorite
                            )
                        }
                        item {
                            PlaylistRow(
                                title = "Recently Played",
                                subtitle = "Songs played on this device",
                                count = songs.size,
                                icon = Icons.Default.History
                            )
                        }
                        item {
                            PlaylistRow(
                                title = "New Playlist",
                                subtitle = "Create a playlist",
                                count = null,
                                icon = Icons.Default.Add
                            )
                        }
                    }
                }
                "Artists", "Albums" -> LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                    groups.entries.forEach { (name, groupedSongs) ->
                        item(key = name) {
                            LibraryGroupRow(
                                title = name,
                                subtitle = "${groupedSongs.size} ${if (title == "Artists") "songs" else "tracks"}",
                                isArtist = title == "Artists",
                                seed = groupedSongs.firstOrNull()?.title?.hashCode()?.let { kotlin.math.abs(it) } ?: 0
                            ) {
                                val index = songs.indexOf(groupedSongs.first())
                                if (index >= 0) onSongClick(index)
                            }
                        }
                    }
                }
                "Songs" -> LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                    itemsIndexed(songs) { index, song -> SongRow(song, index == currentIndex) { onSongClick(index) } }
                }
                else -> LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                    item { SectionPlaceholder(title) }
                }
            }
        }
    }
}

@Composable
private fun QueueSongRow(
    song: MusicSong,
    position: Int,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            position.toString(),
            color = if (selected) Color(0xFF69B3FF) else Color(0xFF70767C),
            fontSize = 12.sp,
            modifier = Modifier.width(28.dp)
        )
        AlbumArt(50.dp)
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(song.title, color = if (selected) Color(0xFF69B3FF) else Color.White, maxLines = 1, fontSize = 15.sp)
            Text(song.artist, color = Color(0xFF9AA0A6), fontSize = 12.sp, maxLines = 1)
        }
        if (selected) {
            Icon(Icons.Default.GraphicEq, null, tint = Color(0xFF69B3FF))
        } else {
            Icon(Icons.Default.DragHandle, null, tint = Color(0xFF666B70))
        }
    }
    HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
}

@Composable
private fun PlaylistRow(
    title: String,
    subtitle: String,
    count: Int?,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(58.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF20262C)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = Color(0xFF69B3FF), modifier = Modifier.size(28.dp))
        }
        Column(Modifier.weight(1f).padding(start = 16.dp)) {
            Text(title, color = Color.White, fontSize = 17.sp)
            Text(
                if (count == null) subtitle else "$subtitle • $count songs",
                color = Color(0xFF8F969D),
                fontSize = 13.sp,
                maxLines = 1
            )
        }
        Icon(Icons.Default.ChevronRight, null, tint = Color(0xFF777D83))
    }
    HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
}

@Composable
private fun LibraryGroupRow(title: String, subtitle: String, isArtist: Boolean, seed: Int, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (isArtist) ArtistArt(62.dp, seed) else AlbumArt(62.dp)
        Column(Modifier.weight(1f).padding(start = 16.dp)) {
            Text(title, color = Color.White, fontSize = 17.sp, maxLines = 1)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, color = Color(0xFF8F969D), fontSize = 13.sp, maxLines = 1)
        }
        Icon(if (isArtist) Icons.Default.ChevronRight else Icons.Default.MoreVert, null, tint = Color(0xFF777D83))
    }
    HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
}

@Composable
private fun ArtistArt(size: Dp, seed: Int) {
    val palettes = listOf(
        listOf(Color(0xFF536778), Color(0xFF17212A)),
        listOf(Color(0xFF744C5C), Color(0xFF20151C)),
        listOf(Color(0xFF5B704E), Color(0xFF182017)),
        listOf(Color(0xFF6B5A82), Color(0xFF211B2B))
    )
    val palette = palettes[seed % palettes.size]
    Box(Modifier.size(size).clip(RoundedCornerShape(50)).background(Brush.linearGradient(palette)), contentAlignment = Alignment.Center) {
        Icon(Icons.Default.Person, null, tint = Color.White.copy(alpha = .82f), modifier = Modifier.size(size * .48f))
    }
}

@Composable
private fun SectionPlaceholder(title: String) {
    Column(Modifier.fillMaxWidth().padding(22.dp)) {
        Text(
            when (title) {
                "Play Queue" -> "再生キュー"
                "Playlists" -> "プレイリスト"
                "Folders" -> "フォルダ"
                "Google Drive" -> "Google Drive"
                "New Releases" -> "新着リリース"
                "Charts" -> "チャート"
                "Settings" -> "設定"
                else -> title
            },
            color = Color.White,
            fontSize = 18.sp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "この画面の詳細UIは次の段階で実装します。",
            color = Color(0xFF858C93),
            fontSize = 13.sp
        )
    }
}

@Composable
private fun EmptyMessage(message: String) {
    Text(
        message,
        color = Color(0xFF9AA0A6),
        modifier = Modifier.padding(horizontal = 22.dp)
    )
}

@Composable
private fun SongRow(song: MusicSong, selected: Boolean, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            AlbumArt(56.dp)
            Column(Modifier.weight(1f).padding(start = 16.dp)) {
                Text(song.title.ifBlank { "Unknown title" }, color = if (selected) Color(0xFF69B3FF) else Color.White, maxLines = 1, fontSize = 16.sp)
                Text(listOf(song.artist, song.album).filter { it.isNotBlank() }.joinToString(" • "), color = Color(0xFF9AA0A6), fontSize = 13.sp, maxLines = 1)
            }
            Icon(if (selected && song.title.isNotBlank()) Icons.Default.GraphicEq else Icons.Default.MoreVert, null, tint = if (selected) Color(0xFF69B3FF) else Color(0xFF777B80))
        }
        HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
    }
}

@Composable
private fun AlbumArt(size: Dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(5.dp)).background(Brush.linearGradient(listOf(Color(0xFF31485A), Color(0xFF11151A), Color(0xFF5A2525)))), contentAlignment = Alignment.Center) {
        Icon(Icons.Default.MusicNote, null, tint = Color.White.copy(alpha = .82f), modifier = Modifier.size(size * .43f))
    }
}

@Composable
private fun MiniPlayer(
    song: MusicSong,
    playing: Boolean,
    onPlay: () -> Unit,
    onOpen: () -> Unit,
    onNext: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long
) {
    var positionMs by remember(song.uriString) { mutableLongStateOf(positionProvider().coerceAtLeast(0L)) }
    var durationMs by remember(song.uriString) { mutableLongStateOf(durationProvider().coerceAtLeast(song.duration)) }

    LaunchedEffect(playing, song.uriString) {
        while (true) {
            positionMs = positionProvider().coerceAtLeast(0L)
            val latestDuration = durationProvider().coerceAtLeast(0L)
            if (latestDuration > 0L) durationMs = latestDuration
            if (!playing) break
            delay(500L)
        }
    }

    val progress = if (durationMs > 0L) (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f

    Column(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFF15181C))
            .clickable(onClick = onOpen)
    ) {
        Box(Modifier.fillMaxWidth().height(2.dp).background(Color.White.copy(alpha = .14f))) {
            Box(Modifier.fillMaxWidth(progress).fillMaxHeight().background(Color(0xFF69B3FF)))
        }
        Row(
            Modifier.fillMaxWidth().height(70.dp).padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AlbumArt(48.dp)
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(song.title, color = Color.White, maxLines = 1, fontSize = 15.sp)
                Text(song.artist, color = Color(0xFF9AA0A6), fontSize = 12.sp, maxLines = 1)
            }
            IconButton(onPlay) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White)
            }
            IconButton(onNext) {
                Icon(Icons.Default.SkipNext, null, tint = Color.White)
            }
        }
    }
}

@Composable
private fun NavigationDrawer(
    selected: String,
    onClose: () -> Unit,
    onSelect: (String) -> Unit
) {
    Row(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .width(300.dp)
                .fillMaxHeight()
                .background(Color(0xFF121417))
                .padding(top = 32.dp)
        ) {
            Text(
                "PIXEL MUSIC",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Light,
                modifier = Modifier.padding(24.dp)
            )
            listOf(
                "Home", "Play Queue", "Playlists", "Artists", "Albums", "Songs",
                "Genres", "Folders", "Google Drive", "New Releases", "Charts", "Settings"
            ).forEach { item ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(item) }
                        .background(
                            if (item == selected) Color(0xFF26384A) else Color.Transparent
                        )
                        .padding(horizontal = 24.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        item,
                        color = if (item == selected) Color(0xFF69B3FF) else Color(0xFFE2E5E8),
                        fontSize = 15.sp
                    )
                }
            }
        }
        Spacer(
            Modifier
                .fillMaxSize()
                .weight(1f)
                .background(Color.Black.copy(alpha = .55f))
                .clickable(onClick = onClose)
        )
    }
}

@Composable
private fun FullPlayer(
    song: MusicSong,
    playing: Boolean,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long,
    onSeekTo: (Long) -> Unit,
    onEditInfo: () -> Unit
) {
    // Xperia-inspired player: artwork-focused layout, compact metadata, and clear transport controls.
    var positionMs by remember(song.uriString) { mutableLongStateOf(positionProvider().coerceAtLeast(0L)) }
    var durationMs by remember(song.uriString) { mutableLongStateOf(durationProvider().coerceAtLeast(0L)) }

    LaunchedEffect(playing, song.uriString) {
        while (true) {
            positionMs = positionProvider().coerceAtLeast(0L)
            val latestDuration = durationProvider().coerceAtLeast(0L)
            if (latestDuration > 0L) durationMs = latestDuration
            if (!playing) break
            delay(500L)
        }
    }

    val safeDuration = durationMs.coerceAtLeast(1L)
    val sliderValue = (positionMs.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF303943),
                        Color(0xFF15191D),
                        Color(0xFF08090B)
                    )
                )
            )
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(58.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onBack) {
                    Icon(Icons.Default.KeyboardArrowDown, "Close player", tint = Color.White)
                }
                Spacer(Modifier.weight(1f))
                Text(
                    "NOW PLAYING",
                    color = Color.White.copy(alpha = .72f),
                    fontSize = 11.sp,
                    letterSpacing = 1.4.sp
                )
                Spacer(Modifier.weight(1f))
                var moreOpen by remember { mutableStateOf(false) }
                Box {
                    IconButton({ moreOpen = true }) {
                        Icon(Icons.Default.MoreVert, "More", tint = Color.White)
                    }
                    DropdownMenu(
                        expanded = moreOpen,
                        onDismissRequest = { moreOpen = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("ミュージック情報を編集") },
                            onClick = {
                                moreOpen = false
                                onEditInfo()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("アーティスト") },
                            onClick = { moreOpen = false }
                        )
                        DropdownMenuItem(
                            text = { Text("アルバム") },
                            onClick = { moreOpen = false }
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            Box(
                Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                AlbumArt(300.dp)
            }

            Spacer(Modifier.height(20.dp))

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        song.title,
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Normal,
                        maxLines = 1
                    )
                    Text(
                        song.artist,
                        color = Color(0xFFD0D5DA),
                        fontSize = 15.sp,
                        maxLines = 1
                    )
                    Text(
                        song.album,
                        color = Color(0xFF9299A1),
                        fontSize = 13.sp,
                        maxLines = 1
                    )
                }
                IconButton({}) {
                    Icon(
                        Icons.Default.FavoriteBorder,
                        "Favorite",
                        tint = Color.White,
                        modifier = Modifier.size(27.dp)
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            Slider(
                value = sliderValue,
                onValueChange = { fraction ->
                    positionMs = (safeDuration * fraction).toLong().coerceIn(0L, safeDuration)
                },
                onValueChangeFinished = {
                    onSeekTo(positionMs.coerceIn(0L, safeDuration))
                },
                modifier = Modifier.fillMaxWidth(),
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = Color.White,
                    inactiveTrackColor = Color.White.copy(alpha = .28f)
                )
            )

            Row(Modifier.fillMaxWidth()) {
                Text(formatDuration(positionMs), color = Color(0xFF9DA4AA), fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Text(formatDuration(durationMs), color = Color(0xFF9DA4AA), fontSize = 11.sp)
            }

            Spacer(Modifier.height(8.dp))

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                IconButton({}) {
                    Icon(Icons.Default.Shuffle, "Shuffle", tint = Color.White.copy(alpha = .9f))
                }
                IconButton(onPrevious, modifier = Modifier.size(52.dp)) {
                    Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(31.dp))
                }
                FilledIconButton(
                    onClick = onPlay,
                    modifier = Modifier.size(70.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = Color.White,
                        contentColor = Color(0xFF111316)
                    )
                ) {
                    Icon(
                        if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                        "Play or pause",
                        modifier = Modifier.size(36.dp)
                    )
                }
                IconButton(onNext, modifier = Modifier.size(52.dp)) {
                    Icon(Icons.Default.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(31.dp))
                }
                IconButton({}) {
                    Icon(Icons.Default.Repeat, "Repeat", tint = Color.White.copy(alpha = .9f))
                }
            }

            Spacer(Modifier.height(18.dp))

            Row(
                Modifier
                    .fillMaxWidth()
                    .height(42.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${song.artist}  •  ${song.album}",
                    color = Color(0xFF858C93),
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}


@Composable
private fun EditMusicInfoScreen(
    song: MusicSong,
    onBack: () -> Unit,
    onSave: () -> Unit
) {
    var title by remember(song.uriString) { mutableStateOf(song.title) }
    var artist by remember(song.uriString) { mutableStateOf(song.artist) }
    var album by remember(song.uriString) { mutableStateOf(song.album) }
    var disc by remember(song.uriString) { mutableStateOf("1") }
    var track by remember(song.uriString) { mutableStateOf("") }
    var year by remember(song.uriString) { mutableStateOf("") }
    var genre by remember(song.uriString) { mutableStateOf("") }
    var artworkSet by remember(song.uriString) { mutableStateOf(false) }
    var selectedImageUri by remember(song.uriString) { mutableStateOf<Uri?>(null) }
    var cropScreen by remember(song.uriString) { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedImageUri = uri
            artworkSet = true
            cropScreen = true
        }
    }

    if (cropScreen && selectedImageUri != null) {
        CropArtworkScreen(
            uri = selectedImageUri!!,
            onBack = { cropScreen = false },
            onDone = { cropScreen = false; artworkSet = true }
        )
        return
    }

    Box(
        Modifier.fillMaxSize().background(Color(0xFF08090B))
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().height(64.dp).background(Color(0xFF0A0B0D)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onBack) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
                }
                Text("ミュージック情報を編集", color = Color.White, fontSize = 19.sp)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onSave) {
                    Text("保存", color = Color(0xFF69B3FF))
                }
            }

            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(20.dp)
            ) {
                item {
                    Row(
                        Modifier.fillMaxWidth().padding(bottom = 22.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AlbumArt(108.dp)
                        Column(Modifier.padding(start = 18.dp)) {
                            Text("アートワーク", color = Color.White, fontSize = 17.sp)
                            Spacer(Modifier.height(10.dp))
                            Row {
                                OutlinedButton(onClick = { imagePicker.launch("image/*") }) {
                                    Text("画像を設定")
                                }
                                Spacer(Modifier.width(8.dp))
                                OutlinedButton(onClick = { artworkSet = false }) {
                                    Text("画像を削除")
                                }
                            }
                            if (artworkSet) {
                                Text(
                                    if (selectedImageUri != null) "選択した画像を使用します。" else "画像が設定されています。",
                                    color = Color(0xFF858C93),
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(top = 7.dp)
                                )
                            }
                        }
                    }
                }
                item { EditField("タイトル", title) { title = it } }
                item { EditField("アーティスト", artist) { artist = it } }
                item { EditField("アルバム", album) { album = it } }
                item { EditField("ディスク", disc) { disc = it } }
                item { EditField("トラック", track) { track = it } }
                item { EditField("年", year) { year = it } }
                item { EditField("ジャンル", genre) { genre = it } }
                item {
                    Text(
                        "※ v0.14では編集画面の骨格を実装しています。保存処理と画像トリミングは次の段階で接続します。",
                        color = Color(0xFF777D83),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 18.dp, bottom = 20.dp)
                    )
                }
            }
        }
    }
}


@Composable
private fun CropArtworkScreen(
    uri: Uri,
    onBack: () -> Unit,
    onDone: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(uri) { mutableStateOf<android.graphics.Bitmap?>(null) }
    var zoom by remember(uri) { mutableFloatStateOf(1f) }
    LaunchedEffect(uri) {
        bitmap = runCatching {
            context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        }.getOrNull()
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF08090B))) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().height(64.dp).background(Color(0xFF0A0B0D)), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
                Text("トリミング（フレーミング）", color = Color.White, fontSize = 18.sp)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onDone) { Text("完了", color = Color(0xFF69B3FF)) }
            }
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(Modifier.size(310.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF15181C)), contentAlignment = Alignment.Center) {
                    bitmap?.let {
                        Image(
                            bitmap = it.asImageBitmap(),
                            contentDescription = "Selected artwork",
                            modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = zoom; scaleY = zoom },
                            contentScale = ContentScale.Crop
                        )
                    } ?: Text("画像を読み込み中…", color = Color(0xFF858C93))
                    Box(Modifier.size(310.dp).border(2.dp, Color.White.copy(alpha = .85f), RoundedCornerShape(8.dp)))
                }
            }
            Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 18.dp)) {
                Text("フレーミング", color = Color.White, fontSize = 15.sp)
                Slider(value = zoom, onValueChange = { zoom = it }, valueRange = 1f..2.2f, colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White, inactiveTrackColor = Color.White.copy(alpha = .25f)))
                Text("画像を拡大してジャケットの見え方を調整できます。", color = Color(0xFF858C93), fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun EditField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedBorderColor = Color(0xFF69B3FF),
            unfocusedBorderColor = Color(0xFF4B5157),
            focusedLabelColor = Color(0xFF69B3FF),
            unfocusedLabelColor = Color(0xFF858C93),
            cursorColor = Color(0xFF69B3FF)
        )
    )
}

private fun formatDuration(milliseconds: Long): String {
    val totalSeconds = (milliseconds / 1000L).coerceAtLeast(0L)
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return "%d:%02d".format(minutes, seconds)
}
