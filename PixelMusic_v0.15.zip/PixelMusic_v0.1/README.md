# Pixel Music v0.1

Pixel 10a向けのXperia Music風プレーヤー試作。

現段階ではUI/操作感の土台を先に作り、曲一覧はデモデータです。

次段階:
1. MediaStoreから実曲を取得
2. Media3/ExoPlayerで再生
3. Album Art取得
4. Queue / Playlist / Favorite
5. 8色テーマ + Album Art連動
6. 通知/ロック画面/Bluetooth
7. 音量ブースト + リミッター


## v0.5
System UI safe-area handling added with Compose WindowInsets.safeDrawing so important UI stays clear of display cutouts and navigation bars.


## v0.6
- Redesigned full player with Xperia-inspired artwork-first layout.
- Added clearer metadata hierarchy, favorite affordance, playback controls, seek presentation, and duration display.
- Preserved v0.5 safe-area handling so the app content stays clear of the camera cutout and navigation area.


### v0.7
- Full player seek bar now tracks actual ExoPlayer playback position.
- Dragging the seek bar seeks the real playback position when released.
- Elapsed and remaining duration update during playback.


## v0.8
Xperia-inspired home screen with an artist hero area, pull-down expansion effect, and safe-area layout. Playback and v0.7 seek behavior are preserved.

## v0.8.1
Fixed the Compose graphicsLayer import used by the home hero zoom effect.
