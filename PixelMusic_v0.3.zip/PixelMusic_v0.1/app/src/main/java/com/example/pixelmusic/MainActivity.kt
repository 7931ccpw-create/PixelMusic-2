package com.example.pixelmusic

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import com.example.pixelmusic.ui.PixelMusicApp
import com.example.pixelmusic.ui.theme.PixelMusicTheme

class MainActivity : ComponentActivity() {
    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        permissionLauncher.launch(Manifest.permission.READ_MEDIA_AUDIO)
        setContent {
            PixelMusicTheme { PixelMusicApp() }
        }
    }
}
