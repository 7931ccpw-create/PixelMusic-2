package com.example.pixelmusic.ui

import com.example.pixelmusic.MusicSong
import com.example.pixelmusic.ui.theme.AppTheme
import com.example.pixelmusic.ui.theme.LocalAccentColor
import com.example.pixelmusic.ui.theme.PixelMusicTheme
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.togetherWith
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.MarqueeAnimationMode
import androidx.compose.foundation.MarqueeSpacing
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.Velocity
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.util.LruCache
import android.media.MediaMetadataRetriever
import java.io.File
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlin.math.absoluteValue
import kotlin.math.roundToInt
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import java.io.FileInputStream
import java.io.FileOutputStream

@Composable
fun PixelMusicApp(
    songs: List<MusicSong>,
    currentIndex: Int,
    playing: Boolean,
    onSongClick: (Int) -> Unit,
    onRecentSongClick: (Int) -> Unit,
    onPlayFolder: (List<Int>, Int?) -> Unit,
    onPlaySongList: (List<Int>, Int?) -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long,
    onSeekTo: (Long) -> Unit,
    shuffleEnabled: Boolean = false,
    repeatMode: Int = 0,
    onToggleShuffle: () -> Unit = {},
    onCycleRepeat: () -> Unit = {},
    queueSongIndices: List<Int>,
    onQueueRemove: (Int) -> Unit,
    onQueueMove: (Int, Int) -> Unit,
    onQueueClear: () -> Unit,
    onQueueAdd: (Int) -> Unit,
    onUpdateSong: (MusicSong) -> Unit,
    onNavigate: (String) -> Unit = {},
    equalizerEnabled: Boolean = false,
    equalizerAvailable: Boolean = false,
    equalizerGains: List<Float> = List(10) { 0f },
    onEqualizerEnabledChange: (Boolean) -> Unit = {},
    onEqualizerBandChange: (Int, Float) -> Unit = { _, _ -> },
    onEqualizerPresetChange: (List<Float>) -> Unit = {},
    masterVolumePercent: Float = 100f,
    onMasterVolumeChange: (Float) -> Unit = {},
    enhancementEnabled: Boolean = false,
    enhancementMode: String = "natural",
    enhancementStrength: String = "medium",
    onEnhancementEnabledChange: (Boolean) -> Unit = {},
    onEnhancementModeChange: (String) -> Unit = {},
    onEnhancementStrengthChange: (String) -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("pixelmusic_settings", android.content.Context.MODE_PRIVATE) }
    var favoriteIds by remember {
        mutableStateOf(prefs.getStringSet("favorite_ids", emptySet())?.toSet() ?: emptySet())
    }
    var recentIds by remember {
        mutableStateOf(prefs.getString("recent_ids", "").orEmpty().split(",").filter { it.isNotBlank() })
    }
    var playlistNames by remember {
        mutableStateOf(prefs.getString("playlist_names", "").orEmpty().split("\u001f").filter { it.isNotBlank() })
    }
    var playlists by remember {
        mutableStateOf(playlistNames.associateWith { name ->
            // Preserve insertion order (List, not Set) so Next advances predictably.
            prefs.getString("playlist_$name", "").orEmpty().split(",").filter { it.isNotBlank() }.distinct()
        })
    }
    fun persistPlaylists(updated: Map<String, List<String>>) {
        val names = updated.keys.toList()
        playlistNames = names
        playlists = updated
        val editor = prefs.edit().putString("playlist_names", names.joinToString("\u001f"))
        names.forEach { name -> editor.putString("playlist_$name", updated[name].orEmpty().joinToString(",")) }
        editor.apply()
    }
    fun addToPlaylist(name: String, song: MusicSong) {
        val updated = playlists.toMutableMap()
        val id = song.id.toString()
        val current = updated[name].orEmpty()
        if (id !in current) {
            updated[name] = current + id
            persistPlaylists(updated)
        }
    }
    fun removeFromPlaylist(name: String, song: MusicSong) {
        val updated = playlists.toMutableMap()
        updated[name] = updated[name].orEmpty().filter { it != song.id.toString() }
        persistPlaylists(updated)
    }
    fun createPlaylist(name: String) {
        val clean = name.trim()
        if (clean.isBlank() || playlists.containsKey(clean)) return
        val updated = playlists.toMutableMap()
        updated[clean] = emptyList()
        persistPlaylists(updated)
    }
    fun toggleFavorite(song: MusicSong) {
        val key = song.id.toString()
        val updated = favoriteIds.toMutableSet().apply { if (!add(key)) remove(key) }
        favoriteIds = updated
        prefs.edit().putStringSet("favorite_ids", updated).apply()
    }
    fun recordRecent(song: MusicSong) {
        val key = song.id.toString()
        val updated = (listOf(key) + recentIds.filterNot { it == key }).take(30)
        recentIds = updated
        prefs.edit().putString("recent_ids", updated.joinToString(",")).apply()
    }
    // Record the actual currently playing song as recent. This also captures
    // next/previous/queue playback, not only taps on a song card.
    val currentSongForRecent = songs.getOrNull(currentIndex)
    LaunchedEffect(currentSongForRecent?.id, playing) {
        if (playing) {
            currentSongForRecent?.let { recordRecent(it) }
        }
    }
    var selectedTheme by remember {
        mutableStateOf(
            runCatching {
                AppTheme.valueOf(prefs.getString("theme", AppTheme.Blue.name) ?: AppTheme.Blue.name)
            }.getOrDefault(AppTheme.Blue)
        )
    }
    val accent = selectedTheme.accent
    CompositionLocalProvider(LocalAccentColor provides accent) {
        PixelMusicTheme(accent = accent) {
        PixelMusicContent(
            songs = songs, currentIndex = currentIndex, playing = playing,
            onSongClick = onSongClick, onRecentSongClick = onRecentSongClick, onPlayFolder = onPlayFolder, onPlaySongList = onPlaySongList, onPlayPause = onPlayPause, onNext = onNext,
            onPrevious = onPrevious, positionProvider = positionProvider,
            durationProvider = durationProvider, onSeekTo = onSeekTo,
            shuffleEnabled = shuffleEnabled, repeatMode = repeatMode,
            onToggleShuffle = onToggleShuffle, onCycleRepeat = onCycleRepeat,
            favoriteIds = favoriteIds, recentIds = recentIds,
            onToggleFavorite = ::toggleFavorite, onRecordRecent = ::recordRecent,
            selectedTheme = selectedTheme, onThemeChange = {
                selectedTheme = it
                prefs.edit().putString("theme", it.name).apply()
            },
            queueSongIndices = queueSongIndices,
            onQueueRemove = onQueueRemove,
            onQueueMove = onQueueMove,
            onQueueClear = onQueueClear,
            onQueueAdd = onQueueAdd,
            onUpdateSong = onUpdateSong,
            onNavigate = onNavigate,
            equalizerEnabled = equalizerEnabled,
            equalizerAvailable = equalizerAvailable,
            equalizerGains = equalizerGains,
            onEqualizerEnabledChange = onEqualizerEnabledChange,
            onEqualizerBandChange = onEqualizerBandChange,
            onEqualizerPresetChange = onEqualizerPresetChange,
            masterVolumePercent = masterVolumePercent,
            onMasterVolumeChange = onMasterVolumeChange,
            enhancementEnabled = enhancementEnabled,
            enhancementMode = enhancementMode,
            enhancementStrength = enhancementStrength,
            onEnhancementEnabledChange = onEnhancementEnabledChange,
            onEnhancementModeChange = onEnhancementModeChange,
            onEnhancementStrengthChange = onEnhancementStrengthChange,
            playlistNames = playlistNames,
            playlists = playlists,
            onCreatePlaylist = { createPlaylist(it) },
            onAddToPlaylist = { name, song -> addToPlaylist(name, song) },
            onRemoveFromPlaylist = { name, song -> removeFromPlaylist(name, song) }
        )
        }
    }

}

@Composable
fun PixelMusicContent(
    songs: List<MusicSong>,
    currentIndex: Int,
    playing: Boolean,
    onSongClick: (Int) -> Unit,
    onRecentSongClick: (Int) -> Unit,
    onPlayFolder: (List<Int>, Int?) -> Unit,
    onPlaySongList: (List<Int>, Int?) -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long,
    onSeekTo: (Long) -> Unit,
    shuffleEnabled: Boolean,
    repeatMode: Int,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    favoriteIds: Set<String>,
    recentIds: List<String>,
    onToggleFavorite: (MusicSong) -> Unit,
    onRecordRecent: (MusicSong) -> Unit,
    selectedTheme: AppTheme,
    onThemeChange: (AppTheme) -> Unit,
    queueSongIndices: List<Int>,
    onQueueRemove: (Int) -> Unit,
    onQueueMove: (Int, Int) -> Unit,
    onQueueClear: () -> Unit,
    onQueueAdd: (Int) -> Unit,
    onUpdateSong: (MusicSong) -> Unit,
    onNavigate: (String) -> Unit,
    equalizerEnabled: Boolean,
    equalizerAvailable: Boolean,
    equalizerGains: List<Float>,
    onEqualizerEnabledChange: (Boolean) -> Unit,
    onEqualizerBandChange: (Int, Float) -> Unit,
    onEqualizerPresetChange: (List<Float>) -> Unit,
    masterVolumePercent: Float,
    onMasterVolumeChange: (Float) -> Unit,
    enhancementEnabled: Boolean,
    enhancementMode: String,
    enhancementStrength: String,
    onEnhancementEnabledChange: (Boolean) -> Unit,
    onEnhancementModeChange: (String) -> Unit,
    onEnhancementStrengthChange: (String) -> Unit,
    playlistNames: List<String>,
    playlists: Map<String, List<String>>,
    onCreatePlaylist: (String) -> Unit,
    onAddToPlaylist: (String, MusicSong) -> Unit,
    onRemoveFromPlaylist: (String, MusicSong) -> Unit
) {
    var drawer by remember { mutableStateOf(false) }
    var drawerDragging by remember { mutableStateOf(false) }
    var drawerDragProgress by remember { mutableFloatStateOf(0f) }
    // One progress value drives both finger tracking and the settling spring.
    // This prevents the drawer from jumping back to its old animated value
    // and replaying the opening animation after a drag ends.
    val drawerProgressAnim = remember { Animatable(0f) }
    val drawerProgress = drawerProgressAnim.value
    var sleepTimerMinutes by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(sleepTimerMinutes) {
        val minutes = sleepTimerMinutes ?: return@LaunchedEffect
        if (minutes <= 0) return@LaunchedEffect
        delay(minutes * 60_000L)
        if (playing) onPlayPause()
        sleepTimerMinutes = null
    }
    var fullPlayer by remember { mutableStateOf(false) }
    var playerOriginScreen by remember { mutableStateOf("Home") }
    var editInfo by remember { mutableStateOf(false) }
    var artistImageRevision by remember { mutableIntStateOf(0) }
    var screen by remember { mutableStateOf("Home") }

    // The translucent player always reveals the Home screen, regardless of
    // which library page launched it. Restore the launching page when closing.
    fun openFullPlayer() {
        if (fullPlayer) return
        playerOriginScreen = screen
        if (screen != "Home") screen = "Home"
        fullPlayer = true
    }
    fun closeFullPlayer() {
        fullPlayer = false
        if (screen != playerOriginScreen) screen = playerOriginScreen
    }
    val context = androidx.compose.ui.platform.LocalContext.current
    val optionPrefs = remember { context.getSharedPreferences("pixelmusic_settings", android.content.Context.MODE_PRIVATE) }
    var folderRevealEnabled by remember { mutableStateOf(optionPrefs.getBoolean("home_folder_reveal_enabled", true)) }
    fun setFolderRevealEnabled(enabled: Boolean) {
        folderRevealEnabled = enabled
        optionPrefs.edit().putBoolean("home_folder_reveal_enabled", enabled).apply()
    }
    val screenBackStack = remember { mutableStateListOf<String>() }
    val topLevelScreens = remember {
        setOf("Home", "Play Queue", "Playlists", "Artists", "Albums", "Songs", "Genres", "Folders", "Favorites", "Recently Played", "Equalizer", "Audio Enhancement", "Settings", "Option")
    }
    fun navigateTo(target: String) {
        if (target == screen) return
        if (target == "Home") {
            screenBackStack.clear()
            screen = "Home"
        } else if (target in topLevelScreens) {
            // Switching a main library section replaces the current section,
            // so Back from a detail page returns to the selected section then Home.
            screenBackStack.clear()
            screen = target
        } else {
            screenBackStack.add(screen)
            screen = target
        }
    }
    fun navigateBack() {
        if (screenBackStack.isNotEmpty()) {
            screen = screenBackStack.removeAt(screenBackStack.lastIndex)
        } else if (screen != "Home") {
            // From a top-level section: open the nav menu first instead of jumping to Home.
            // A second back (while the drawer is open) goes to Home — handled in BackHandler.
            drawer = true
        } else {
            val activity = context as? android.app.Activity
            activity?.finish()
        }
    }

    // Back closes overlays first, then returns through the screen history.
    // From a library section with the drawer open (opened via back or menu),
    // the next back closes the drawer and returns to Home.
    BackHandler(enabled = true) {
        when {
            editInfo -> editInfo = false
            fullPlayer -> closeFullPlayer()
            drawer && screen != "Home" && screenBackStack.isEmpty() -> {
                drawer = false
                drawerDragging = false
                screen = "Home"
            }
            drawer -> {
                drawer = false
                drawerDragging = false
            }
            else -> navigateBack()
        }
    }
    val current = songs.getOrNull(currentIndex)
    val listState = rememberLazyListState()
    // Keep library scroll positions outside the screens so they survive detail navigation.
    val artistsListState = rememberLazyListState()
    val albumsListState = rememberLazyListState()
    val folderRootListState = rememberLazyListState()
    val folderContentListState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    LaunchedEffect(drawer, drawerDragging) {
        if (!drawerDragging) {
            drawerProgressAnim.animateTo(
                targetValue = if (drawer) 1f else 0f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessMediumLow
                )
            )
        } else {
            drawerProgressAnim.stop()
        }
    }
    var heroPull by remember { mutableFloatStateOf(0f) }
    val pullConnection = remember(listState) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: androidx.compose.ui.geometry.Offset, source: NestedScrollSource): androidx.compose.ui.geometry.Offset {
                if (source == NestedScrollSource.UserInput && available.y > 0f && listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset == 0) {
                    val consumed = available.y.coerceAtMost(available.y * 0.48f)
                    heroPull = (heroPull + consumed).coerceIn(0f, 240f)
                    return androidx.compose.ui.geometry.Offset(0f, consumed)
                }
                return androidx.compose.ui.geometry.Offset.Zero
            }
            override suspend fun onPreFling(available: Velocity): Velocity {
                if (heroPull > 0f) {
                    scope.launch {
                        androidx.compose.animation.core.Animatable(heroPull).animateTo(
                            targetValue = 0f,
                            animationSpec = androidx.compose.animation.core.tween(
                                durationMillis = 650,
                                easing = androidx.compose.animation.core.FastOutSlowInEasing
                            )
                        ) { heroPull = value }
                    }
                }
                return Velocity.Zero
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF08090B))
            .pointerInput(screen, fullPlayer) {
                // Do not open the navigation drawer from the left edge while the full player is open.
                if (screen == "Home" && !fullPlayer) {
                    var startX = 0f
                    var startedFromEdge = false
                    var startProgress = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { offset ->
                            startX = offset.x
                            startedFromEdge = startX <= 36.dp.toPx()
                            startProgress = 0f
                            if (startedFromEdge) {
                                drawerDragging = true
                                drawerDragProgress = 0f
                                scope.launch {
                                    drawerProgressAnim.stop()
                                    drawerProgressAnim.snapTo(0f)
                                }
                            }
                        },
                        onHorizontalDrag = { change, dragAmount ->
                            if (startedFromEdge) {
                                drawerDragProgress = (drawerDragProgress + dragAmount / 300.dp.toPx()).coerceIn(0f, 1f)
                                val dragProgress = drawerDragProgress
                                scope.launch { drawerProgressAnim.snapTo(dragProgress) }
                                change.consume()
                            }
                        },
                        onDragEnd = {
                            if (startedFromEdge) {
                                drawer = drawerDragProgress >= 0.5f
                                drawerDragging = false
                            }
                        },
                        onDragCancel = {
                            if (startedFromEdge) {
                                drawer = drawerDragProgress >= 0.5f
                                drawerDragging = false
                            }
                        }
                    )
                }
            }
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            Column(Modifier.fillMaxSize()) {
                if (screen != "Home") {
                    TopBar(
                        title = screen,
                        onMenu = { drawer = true },
                        onSearch = { navigateTo("Search") }
                    )
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                AnimatedContent(
                    targetState = screen,
                    transitionSpec = {
                        val targetIsDetail = targetState.startsWith("Artist::") || targetState.startsWith("Album::")
                        val initialIsDetail = initialState.startsWith("Artist::") || initialState.startsWith("Album::")
                        val fromLibraryList = initialState == "Artists" || initialState == "Albums"
                        val toLibraryList = targetState == "Artists" || targetState == "Albums"
                        when {
                            targetState == "Home" && fullPlayer && initialState != "Home" ->
                                (slideInVertically(
                                    initialOffsetY = { height -> height },
                                    animationSpec = spring(
                                        dampingRatio = Spring.DampingRatioMediumBouncy,
                                        stiffness = Spring.StiffnessMediumLow
                                    )
                                ) + fadeIn(animationSpec = tween(300))) togetherWith
                                (fadeOut(animationSpec = tween(120)))
                            targetIsDetail && fromLibraryList ->
                                (slideInHorizontally(
                                    initialOffsetX = { width -> width },
                                    animationSpec = tween(260)
                                ) + fadeIn(animationSpec = tween(220))) togetherWith
                                (slideOutHorizontally(
                                    targetOffsetX = { width -> -width / 4 },
                                    animationSpec = tween(220)
                                ) + fadeOut(animationSpec = tween(180)))
                            initialIsDetail && toLibraryList ->
                                (slideInHorizontally(
                                    initialOffsetX = { width -> -width / 4 },
                                    animationSpec = tween(260)
                                ) + fadeIn(animationSpec = tween(220))) togetherWith
                                (slideOutHorizontally(
                                    targetOffsetX = { width -> width },
                                    animationSpec = tween(220)
                                ) + fadeOut(animationSpec = tween(180)))
                            else ->
                                fadeIn(animationSpec = tween(120)) togetherWith
                                    fadeOut(animationSpec = tween(100))
                        }
                    },
                    label = "libraryDetailTransition"
                ) { targetScreen ->
                when (targetScreen) {
                    "Home" -> HomeScreen(
                        songs = songs,
                        currentIndex = currentIndex,
                        current = current,
                        playing = playing,
                        listState = listState,
                        pullConnection = pullConnection,
                        heroPull = heroPull,
                        onHeroOpen = { if (current != null) openFullPlayer() },
                        queueSongIndices = queueSongIndices,
                        recentIds = recentIds,
                        onNavigate = { navigateTo(it) },
                        onCycleRepeat = onCycleRepeat,
                        onQueueAdd = onQueueAdd,
                        playlistNames = playlistNames,
                        onAddToPlaylist = onAddToPlaylist,
                        folderRevealEnabled = folderRevealEnabled,
                        artistImageRevision = artistImageRevision,
                        onRecentSongClick = { index -> onRecentSongClick(index) },
                        onSongClick = { index ->
                            songs.getOrNull(index)?.let(onRecordRecent)
                            onSongClick(index)
                        }
                    )
                    "Settings" -> SettingsScreen(
                        selectedTheme = selectedTheme,
                        onThemeChange = onThemeChange
                    )
                    "Option" -> OptionsScreen(
                        folderRevealEnabled = folderRevealEnabled,
                        onFolderRevealEnabledChange = ::setFolderRevealEnabled
                    )
                    "Equalizer" -> EqualizerScreen(
                        enabled = equalizerEnabled,
                        available = equalizerAvailable,
                        initialGains = equalizerGains,
                        onEnabledChange = onEqualizerEnabledChange,
                        onBandChange = onEqualizerBandChange,
                        onPresetChange = onEqualizerPresetChange,
                        masterVolumePercent = masterVolumePercent,
                        onMasterVolumeChange = onMasterVolumeChange
                    )
                    "Audio Enhancement" -> AudioEnhancementScreen(
                        enabled = enhancementEnabled,
                        mode = enhancementMode,
                        strength = enhancementStrength,
                        onEnabledChange = onEnhancementEnabledChange,
                        onModeChange = onEnhancementModeChange,
                        onStrengthChange = onEnhancementStrengthChange
                    )
                    "Folders" -> FolderBrowserScreen(
                        songs = songs,
                        rootListState = folderRootListState,
                        contentListState = folderContentListState,
                        onSongClick = { index ->
                            songs.getOrNull(index)?.let(onRecordRecent)
                            onSongClick(index)
                        },
                        onPlayFolder = { indices, startSongIndex ->
                            val start = startSongIndex ?: indices.firstOrNull()
                            start?.let { songs.getOrNull(it)?.let(onRecordRecent) }
                            onPlayFolder(indices, startSongIndex)
                        },
                        onExit = { navigateBack() },
                        onQueueAdd = onQueueAdd,
                        playlistNames = playlistNames,
                        onAddToPlaylist = onAddToPlaylist
                    )
                    "Search" -> SearchScreen(
                        songs = songs,
                        currentIndex = currentIndex,
                        onSongClick = { index ->
                            songs.getOrNull(index)?.let(onRecordRecent)
                            onSongClick(index)
                        },
                        onQueueAdd = onQueueAdd,
                        playlistNames = playlistNames,
                        onAddToPlaylist = onAddToPlaylist
                    )
                    else -> LibraryScreen(
                        title = screen,
                        listState = if (targetScreen == "Artists") artistsListState else albumsListState,
                        songs = songs,
                        currentIndex = currentIndex,
                        favoriteIds = favoriteIds,
                        recentIds = recentIds,
                        onSongClick = { index ->
                            songs.getOrNull(index)?.let(onRecordRecent)
                            onSongClick(index)
                        },
                        onNavigate = { navigateTo(it) },
                        onPlaySongList = { indices, startSongIndex ->
                            val start = startSongIndex ?: indices.firstOrNull()
                            start?.let { songs.getOrNull(it)?.let(onRecordRecent) }
                            onPlaySongList(indices, startSongIndex)
                        },
                        queueSongIndices = queueSongIndices,
                        onQueueRemove = onQueueRemove,
                        onQueueMove = onQueueMove,
                        onQueueClear = onQueueClear,
                        onQueueAdd = onQueueAdd,
                        playlistNames = playlistNames,
                        playlists = playlists,
                        onCreatePlaylist = onCreatePlaylist,
                        onAddToPlaylist = onAddToPlaylist,
                        onRemoveFromPlaylist = onRemoveFromPlaylist
                    )
                }
                }
            }
                if (current != null) {
                    MiniPlayer(current, playing, onPlayPause, { openFullPlayer() }, onPrevious, onNext, positionProvider, durationProvider)
                }
            }

            // On Home, place the controls over the hero image so the artwork remains
            // visible behind the hamburger, title, search and overflow buttons.
            if (screen == "Home") {
                TopBar(
                    title = "",
                    onMenu = { drawer = true },
                    onSearch = { navigateTo("Search") },
                    showOverflow = false
                )
            }
        }

        if (drawer || drawerDragging || drawerProgress > 0f) {
            NavigationDrawer(
                selected = screen,
                progress = drawerProgress,
                onDragStart = {
                    drawerDragging = true
                    drawerDragProgress = drawerProgressAnim.value
                    scope.launch { drawerProgressAnim.stop() }
                },
                onDragProgress = { progress ->
                    drawerDragProgress = progress.coerceIn(0f, 1f)
                    val dragProgress = drawerDragProgress
                    scope.launch { drawerProgressAnim.snapTo(dragProgress) }
                },
                onDragEnd = {
                    drawer = drawerDragProgress >= 0.5f
                    drawerDragging = false
                },
                onClose = {
                    drawer = false
                    drawerDragging = false
                },
                onSelect = { selected ->
                    navigateTo(selected)
                    drawer = false
                    drawerDragging = false
                }
            )
        }
        if (editInfo && current != null) {
            EditMusicInfoScreen(
                song = current,
                onBack = { editInfo = false },
                onSave = { updated ->
                    onUpdateSong(updated)
                    editInfo = false
                },
                onArtistImageSaved = { artistImageRevision++ }
            )
        } else if (current != null) {
            // Let the mini-player remain visible beneath the full player while it
            // rises into place, and keep the reverse transition when closing it.
            AnimatedVisibility(
                visible = fullPlayer,
                modifier = Modifier
                    .fillMaxSize()
                    .zIndex(100f)
                    // Keep vertical gestures on the player from scrolling the Home
                    // content visible through its translucent background.
                    .pointerInput(fullPlayer) {
                        awaitPointerEventScope {
                            while (true) {
                                val event = awaitPointerEvent(PointerEventPass.Final)
                                event.changes.forEach { change ->
                                    if (change.pressed) change.consume()
                                }
                            }
                        }
                    },
                enter = slideInVertically(
                        initialOffsetY = { fullHeight -> fullHeight },
                        animationSpec = tween(
                            durationMillis = 420,
                            easing = androidx.compose.animation.core.FastOutSlowInEasing
                        )
                    ) + fadeIn(animationSpec = tween(220)),
                exit = slideOutVertically(
                        targetOffsetY = { fullHeight -> fullHeight },
                        animationSpec = tween(
                            durationMillis = 360,
                            easing = androidx.compose.animation.core.FastOutSlowInEasing
                        )
                    ) + fadeOut(animationSpec = tween(200))
            ) {
                FullPlayer(
                    song = current,
                    playing = playing,
                    onBack = { closeFullPlayer() },
                    onPlay = onPlayPause,
                    onPrevious = onPrevious,
                    onNext = onNext,
                    positionProvider = positionProvider,
                    durationProvider = durationProvider,
                    onSeekTo = onSeekTo,
                    shuffleEnabled = shuffleEnabled,
                    repeatMode = repeatMode,
                    onToggleShuffle = onToggleShuffle,
                    onCycleRepeat = onCycleRepeat,
                    isFavorite = current.id.toString() in favoriteIds,
                    onToggleFavorite = { onToggleFavorite(current) },
                    playlistNames = playlistNames,
                    onAddToPlaylist = { name, song -> onAddToPlaylist(name, song) },
                    onEditInfo = { editInfo = true },
                    sleepTimerMinutes = sleepTimerMinutes,
                    onSetSleepTimer = { sleepTimerMinutes = it },
                    onNavigate = { target -> navigateTo(target) }
                )
            }
        }
    }
}


@Composable
private fun HomeHero(song: MusicSong?, pull: Float, artistImageRevision: Int, onOpenPlayer: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("pixelmusic_artwork", android.content.Context.MODE_PRIVATE) }
    val artistImagePath = remember(song?.artist, artistImageRevision) {
        song?.artist?.let { prefs.getString("artist_art_${it.hashCode()}", null) }
    }
    val artistBitmap = remember(artistImagePath, artistImageRevision) {
        artistImagePath?.let { path -> runCatching { BitmapFactory.decodeFile(path)?.asImageBitmap() }.getOrNull() }
    }
    val scale = 1f + (pull / 720f).coerceIn(0f, 0.34f)
    Box(
        Modifier
            .fillMaxWidth()
            .height(300.dp)
            .graphicsLayer {
                // Keep the top edge of the artwork anchored while pulling down.
                // This prevents the upper part of the artist/album image from
                // being pushed behind the top edge as the image expands.
                transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 0f)
                scaleX = scale
                scaleY = scale
                translationY = pull * 0.08f
            }
            .clip(RectangleShape)
            .background(
                Brush.verticalGradient(
                    0f to Color.Black.copy(alpha = .10f),
                    0.48f to LocalAccentColor.current.copy(alpha = .18f),
                    0.78f to Color(0xFF101419).copy(alpha = .76f),
                    1f to Color(0xFF08090B)
                )
            )
            .clickable(enabled = song != null, onClick = onOpenPlayer)
    ) {
        if (artistBitmap != null) {
            Image(bitmap = artistBitmap, contentDescription = "アーティスト画像", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            ArtworkImage(song, Modifier.fillMaxSize(), ContentScale.Crop)
        }
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
            listOf(Color.Black.copy(alpha = .08f), Color.Black.copy(alpha = .18f), Color.Black.copy(alpha = .58f))
        )))
        Column(
            Modifier.fillMaxSize().padding(start = 24.dp, end = 24.dp, bottom = 22.dp, top = 18.dp),
            verticalArrangement = Arrangement.Bottom
        ) {
            Text(
                "NOW PLAYING",
                color = Color.White.copy(alpha = 0.72f),
                fontSize = 11.sp,
                letterSpacing = 1.5.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                song?.artist?.takeIf { it.isNotBlank() } ?: "Your Music",
                color = Color.White,
                fontSize = 29.sp,
                fontWeight = FontWeight.Light,
                maxLines = 1
            )
            Text(
                song?.album?.takeIf { it.isNotBlank() } ?: "Music Library",
                color = Color.White.copy(alpha = 0.78f),
                fontSize = 14.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun TopBar(title: String, onMenu: () -> Unit, onSearch: () -> Unit, showOverflow: Boolean = true) {
    Row(
        // Keep the top controls visually floating over the artist/album image.
        // The image remains visible behind the menu, title, search and overflow areas.
        Modifier.fillMaxWidth().height(64.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onMenu) { Icon(Icons.Default.Menu, null, tint = Color.White) }
        Text(title, color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.weight(1f))
        IconButton(onSearch) { Icon(Icons.Default.Search, null, tint = Color.White) }
        if (showOverflow) {
            IconButton({}) { Icon(Icons.Default.MoreVert, null, tint = Color.White) }
        }
    }
}

@Composable
private fun SearchScreen(
    songs: List<MusicSong>,
    currentIndex: Int,
    onSongClick: (Int) -> Unit,
    onQueueAdd: (Int) -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val normalizedQuery = query.trim()
    val results = remember(normalizedQuery, songs) {
        if (normalizedQuery.isBlank()) emptyList() else songs.filter { song ->
            song.title.contains(normalizedQuery, ignoreCase = true) ||
            song.artist.contains(normalizedQuery, ignoreCase = true) ||
            song.album.contains(normalizedQuery, ignoreCase = true)
        }
    }
    val artistCount = remember(results) {
        results.map { it.artist.trim() }.filter { it.isNotBlank() }.distinct().size
    }
    val albumCount = remember(results) {
        results.map { it.album.trim() }.filter { it.isNotBlank() }.distinct().size
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 12.dp),
            placeholder = { Text("曲名・アーティスト・アルバムを検索") },
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Default.Clear, "Clear")
                    }
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = LocalAccentColor.current,
                unfocusedBorderColor = Color(0xFF3B4147),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedPlaceholderColor = Color(0xFF777D83),
                unfocusedPlaceholderColor = Color(0xFF777D83),
                focusedLeadingIconColor = LocalAccentColor.current,
                unfocusedLeadingIconColor = Color(0xFF777D83),
                focusedTrailingIconColor = Color(0xFFB0B5BA),
                unfocusedTrailingIconColor = Color(0xFFB0B5BA)
            )
        )

        when {
            normalizedQuery.isBlank() -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 22.dp, vertical = 30.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = null,
                        tint = LocalAccentColor.current.copy(alpha = .75f),
                        modifier = Modifier.size(42.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text("音楽を検索", color = Color.White, fontSize = 18.sp)
                    Spacer(Modifier.height(5.dp))
                    Text(
                        "曲名・アーティスト・アルバムから検索できます",
                        color = Color(0xFF858C93),
                        fontSize = 13.sp
                    )
                }
            }
            results.isEmpty() -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 22.dp, vertical = 34.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.SearchOff,
                        contentDescription = null,
                        tint = Color(0xFF777D83),
                        modifier = Modifier.size(38.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("一致する曲がありません", color = Color.White, fontSize = 17.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("「$normalizedQuery」", color = Color(0xFF858C93), fontSize = 13.sp)
                }
            }
            else -> {
                Column(Modifier.fillMaxSize()) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 22.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "検索結果",
                            color = LocalAccentColor.current,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Light
                        )
                        Spacer(Modifier.weight(1f))
                        Text(
                            "${results.size}曲  •  ${artistCount}アーティスト  •  ${albumCount}アルバム",
                            color = Color(0xFF777D83),
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }
                    Text(
                        "${results.size} results",
                        color = Color(0xFF777D83),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 22.dp, vertical = 2.dp)
                    )
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        itemsIndexed(results) { _, song ->
                            val actualIndex = songs.indexOf(song)
                            SongRow(
                                song = song,
                                selected = actualIndex == currentIndex,
                                onAddToQueue = { if (actualIndex >= 0) onQueueAdd(actualIndex) },
                                playlistNames = playlistNames,
                                onAddToPlaylist = onAddToPlaylist
                            ) { if (actualIndex >= 0) onSongClick(actualIndex) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    songs: List<MusicSong>,
    currentIndex: Int,
    current: MusicSong?,
    playing: Boolean,
    listState: androidx.compose.foundation.lazy.LazyListState,
    pullConnection: NestedScrollConnection,
    heroPull: Float,
    onHeroOpen: () -> Unit,
    queueSongIndices: List<Int>,
    recentIds: List<String>,
    onNavigate: (String) -> Unit,
    onCycleRepeat: () -> Unit,
    onQueueAdd: (Int) -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit,
    folderRevealEnabled: Boolean,
    artistImageRevision: Int,
    onRecentSongClick: (Int) -> Unit,
    onSongClick: (Int) -> Unit
) {
    val recentSongs = remember(recentIds, songs) {
        recentIds.mapNotNull { id -> songs.firstOrNull { it.id.toString() == id } }
    }
    val newSongs = remember(songs) {
        songs.sortedByDescending { it.dateAdded }.take(9)
    }
    val queueEntries = remember(queueSongIndices, songs) {
        queueSongIndices.mapNotNull { index ->
            songs.getOrNull(index)?.let { index to it }
        }
    }

    // Reveal the currently playing song's folder on Home after 10 seconds of playback.
    // Restart the timer when the track changes, and cancel it if playback stops.
    var showPlayingFolder by remember { mutableStateOf(false) }
    LaunchedEffect(current?.id, playing, folderRevealEnabled) {
        showPlayingFolder = false
        if (folderRevealEnabled && playing && current != null) {
            delay(10_000L)
            showPlayingFolder = true
        }
    }
    val folderRevealProgress by animateFloatAsState(
        targetValue = if (showPlayingFolder) 1f else 0f,
        animationSpec = tween(durationMillis = 1100),
        label = "playingFolderDepthReveal"
    )
    val currentFolderPath = current?.folderPath?.trimEnd('/')?.takeIf { it.isNotBlank() }
    val currentFolderSongs = remember(currentFolderPath, current, songs) {
        if (currentFolderPath == null) listOfNotNull(current)
        else songs.filter { it.folderPath.trimEnd('/') == currentFolderPath }
    }
    val currentFolderName = currentFolderPath
        ?.substringAfterLast('/')
        ?.takeIf { it.isNotBlank() }
        ?: "再生中のフォルダ"

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .nestedScroll(pullConnection),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item {
                HomeHero(song = current, pull = heroPull, artistImageRevision = artistImageRevision, onOpenPlayer = onHeroOpen)
            }

            item {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(start = 24.dp, end = 18.dp, top = 10.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "再生待ちリスト",
                        color = Color.White,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Light,
                        modifier = Modifier.weight(1f)
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(LocalAccentColor.current)
                            .clickable { onNavigate("Play Queue") }
                            .padding(horizontal = 18.dp, vertical = 9.dp)
                    ) {
                        Text("開く", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }

            if (queueEntries.isEmpty()) {
                item {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 18.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF202225))
                            .padding(22.dp)
                    ) {
                        Text("再生待ちの曲はありません", color = Color(0xFF9AA0A6), fontSize = 14.sp)
                    }
                }
            } else {
                item {
                    androidx.compose.foundation.lazy.LazyRow(
                        contentPadding = PaddingValues(horizontal = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        itemsIndexed(queueEntries.take(12)) { _, entry ->
                            val (actualIndex, song) = entry
                            HomeQueueCard(
                                song = song,
                                selected = song.id == current?.id,
                                onClick = { onSongClick(actualIndex) },
                                onAddToQueue = { onQueueAdd(actualIndex) },
                                playlistNames = playlistNames,
                                onAddToPlaylist = onAddToPlaylist
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    "最近再生した曲",
                    color = Color.White,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Light,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 10.dp)
                )
            }

            if (recentSongs.isEmpty()) {
                item {
                    Text(
                        "最近再生した曲はありません",
                        color = Color(0xFF9AA0A6),
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                    )
                }
            } else {
                item {
                    Column(
                        Modifier.fillMaxWidth().padding(horizontal = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        recentSongs.take(30).chunked(3).forEach { rowSongs ->
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                rowSongs.forEach { song ->
                                    val songIndex = songs.indexOfFirst { it.id == song.id }
                                    HomeRecentCard(
                                        song = song,
                                        onClick = { if (songIndex >= 0) onRecentSongClick(songIndex) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                repeat(3 - rowSongs.size) {
                                    Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(start = 24.dp, end = 18.dp, top = 10.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "新規追加",
                        color = Color.White,
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Light,
                        modifier = Modifier.weight(1f)
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF2A2D31))
                            .clickable { onNavigate("Newly Added") }
                            .padding(horizontal = 18.dp, vertical = 9.dp)
                    ) {
                        Text("もっと見る", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }

            item {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    newSongs.chunked(3).forEach { rowSongs ->
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowSongs.forEach { song ->
                                val songIndex = songs.indexOfFirst { it.id == song.id }
                                HomeRecentCard(
                                    song = song,
                                    onClick = { if (songIndex >= 0) onRecentSongClick(songIndex) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            repeat(3 - rowSongs.size) {
                                Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }

        // A folder card rises out of the depth of the screen after 10 seconds.
        // Keep it over the hero artwork so it feels like a floating Home element.
        if (current != null && currentFolderSongs.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 112.dp)
                    .width(270.dp)
                    .graphicsLayer {
                        val progress = folderRevealProgress.coerceIn(0f, 1f)
                        alpha = progress
                        scaleX = 0.62f + 0.38f * progress
                        scaleY = 0.62f + 0.38f * progress
                        translationY = (1f - progress) * 105.dp.toPx()
                        rotationX = (1f - progress) * -22f
                        cameraDistance = 18f * density
                        shadowElevation = progress * 22.dp.toPx()
                    }
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0xE8202328))
                    .border(1.dp, Color.White.copy(alpha = 0.12f * folderRevealProgress), RoundedCornerShape(18.dp))
                    .clickable(
                        enabled = folderRevealProgress > 0.98f,
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { onNavigate("Folders") }
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    FolderArtworkCollage(
                        songs = currentFolderSongs.take(4),
                        modifier = Modifier.size(66.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "再生中のフォルダ",
                            color = LocalAccentColor.current,
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            currentFolderName,
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            maxLines = 1
                        )
                        Text(
                            "${currentFolderSongs.size}曲",
                            color = Color(0xFFB0B5BA),
                            fontSize = 12.sp
                        )
                    }
                    Icon(
                        Icons.Default.FolderOpen,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }

        // Small floating repeat control, matching the reference layout while
        // keeping the existing repeat functionality available from Home.
        FloatingActionButton(
            onClick = onCycleRepeat,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 18.dp, bottom = 94.dp),
            containerColor = LocalAccentColor.current,
            contentColor = Color.White,
            shape = androidx.compose.foundation.shape.CircleShape
        ) {
            Icon(Icons.Default.Repeat, contentDescription = "Repeat")
        }
    }
}

@Composable
private fun HomeQueueCard(
    song: MusicSong,
    selected: Boolean,
    onClick: () -> Unit,
    onAddToQueue: () -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit
) {
    var menuOpen by remember(song.id) { mutableStateOf(false) }
    Column(
        Modifier
            .width(112.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFF292A2C))
            .clickable(onClick = onClick)
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f)) {
            AlbumArt(song = song, size = 112.dp, modifier = Modifier.fillMaxSize())
            if (selected) {
                Box(
                    Modifier
                        .align(Alignment.BottomStart)
                        .padding(10.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Black.copy(alpha = .65f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Default.Pause, null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(start = 11.dp, top = 9.dp, bottom = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    song.title.ifBlank { "Unknown title" },
                    color = Color.White,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
                Text(
                    song.artist.ifBlank { "Unknown artist" },
                    color = Color(0xFF9AA0A6),
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
            }
            Box {
                IconButton(
                    onClick = { menuOpen = true },
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        Icons.Default.MoreVert,
                        "More",
                        tint = Color(0xFF858A90),
                        modifier = Modifier.size(21.dp)
                    )
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("Add to Play Queue") },
                        leadingIcon = { Icon(Icons.Default.QueueMusic, null) },
                        onClick = { menuOpen = false; onAddToQueue() }
                    )
                    playlistNames.forEach { name ->
                        DropdownMenuItem(
                            text = { Text("Add to $name") },
                            leadingIcon = { Icon(Icons.Default.PlaylistAdd, null) },
                            onClick = { menuOpen = false; onAddToPlaylist(name, song) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeRecentCard(
    song: MusicSong,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier
            .clip(RoundedCornerShape(3.dp))
            .background(Color(0xFF292A2C))
            .clickable(onClick = onClick)
    ) {
        ArtworkImage(
            song = song,
            modifier = Modifier.fillMaxWidth().aspectRatio(1f),
            contentScale = ContentScale.Crop
        )
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text(song.title.ifBlank { "Unknown title" }, color = Color.White, fontSize = 15.sp, maxLines = 1)
            Text(song.artist.ifBlank { "Unknown artist" }, color = Color(0xFF9AA0A6), fontSize = 12.sp, maxLines = 1)
        }
    }
}

@Composable
private fun FolderBrowserScreen(
    songs: List<MusicSong>,
    rootListState: LazyListState,
    contentListState: LazyListState,
    onSongClick: (Int) -> Unit,
    onPlayFolder: (List<Int>, Int?) -> Unit,
    onExit: () -> Unit,
    onQueueAdd: (Int) -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit
) {
    var currentPath by remember { mutableStateOf<String?>(null) }

    BackHandler {
        if (currentPath != null) currentPath = null else onExit()
    }

    fun folderKey(song: MusicSong): String {
        return song.folderPath.trimEnd('/').ifBlank { "__UNKNOWN__" }
    }

    fun folderName(path: String): String {
        if (path == "__UNKNOWN__") return "その他"
        return path.substringAfterLast('/').ifBlank { path }
    }

    val folders = remember(songs) {
        songs.groupBy { folderKey(it) }
            .mapValues { it.value.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { s -> s.title }) }
            .toList()
            .sortedBy { folderName(it.first).lowercase() }
    }

    val visibleSongs = remember(songs, currentPath) {
        currentPath?.let { path ->
            songs.filter { folderKey(it) == path }
                .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.title })
        } ?: emptyList()
    }

    val title = currentPath?.let { folderName(it) } ?: "フォルダ"
    val subtitle = if (currentPath == null) {
        "端末内の音楽フォルダ"
    } else {
        "${visibleSongs.size}曲"
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
            Text(title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Light, maxLines = 2)
            Text(subtitle, color = Color(0xFF777D83), fontSize = 12.sp, maxLines = 1)
            if (visibleSongs.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val indices = visibleSongs.mapNotNull { song ->
                            songs.indexOfFirst { it.id == song.id }.takeIf { it >= 0 }
                        }
                        onPlayFolder(indices, indices.firstOrNull())
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LocalAccentColor.current),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("このフォルダを再生")
                }
            }
        }

        LazyColumn(
            Modifier.fillMaxSize(),
            state = if (currentPath == null) rootListState else contentListState,
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            if (currentPath == null) {
                itemsIndexed(folders) { _, item ->
                    val (path, folderSongs) = item
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { currentPath = path }
                            .padding(horizontal = 18.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val folderArtworks = remember(folderSongs) {
                            folderSongs.distinctBy { it.artworkUriString ?: it.album.ifBlank { it.id.toString() } }.take(4)
                        }
                        FolderArtworkCollage(
                            songs = folderArtworks,
                            modifier = Modifier.size(58.dp)
                        )
                        Column(Modifier.weight(1f).padding(start = 15.dp)) {
                            Text(folderName(path), color = Color.White, fontSize = 16.sp, maxLines = 1)
                            Text("${folderSongs.size}曲", color = Color(0xFF8F969D), fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Color(0xFF777D83))
                    }
                    HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
                }
            } else {
                itemsIndexed(visibleSongs) { _, song ->
                    val index = songs.indexOfFirst { it.id == song.id }
                    if (index >= 0) {
                        SongRow(
                            song = song,
                            selected = false,
                            onAddToQueue = { onQueueAdd(index) },
                            playlistNames = playlistNames,
                            onAddToPlaylist = onAddToPlaylist,
                            onClick = {
                                // Load whole folder into queue in display order; start at tapped track
                                // so both Next and Previous stay within the folder.
                                val indices = visibleSongs.mapNotNull { s ->
                                    songs.indexOfFirst { it.id == s.id }.takeIf { it >= 0 }
                                }
                                if (indices.isNotEmpty()) {
                                    onPlayFolder(indices, index)
                                } else {
                                    onSongClick(index)
                                }
                            }
                        )
                    }
                }
            }

            if (folders.isEmpty() && currentPath == null) {
                item {
                    Text(
                        "音楽フォルダが見つかりません",
                        color = Color(0xFF8F969D),
                        modifier = Modifier.padding(22.dp)
                    )
                }
            }
            if (visibleSongs.isEmpty() && currentPath != null) {
                item {
                    Text(
                        "このフォルダに音楽ファイルはありません",
                        color = Color(0xFF8F969D),
                        modifier = Modifier.padding(22.dp)
                    )
                }
            }
        }
    }
}


@Composable
private fun FolderArtworkCollage(
    songs: List<MusicSong>,
    modifier: Modifier = Modifier
) {
    val gap = 1.dp
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(LocalAccentColor.current.copy(alpha = .18f))
    ) {
        when (songs.size) {
            0 -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Folder, null, tint = LocalAccentColor.current, modifier = Modifier.size(28.dp))
            }
            1 -> FolderArtworkTile(songs[0], Modifier.fillMaxSize())
            2 -> Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                FolderArtworkTile(songs[0], Modifier.weight(1f).fillMaxHeight())
                FolderArtworkTile(songs[1], Modifier.weight(1f).fillMaxHeight())
            }
            3 -> Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                FolderArtworkTile(songs[0], Modifier.weight(1f).fillMaxHeight())
                Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(gap)) {
                    FolderArtworkTile(songs[1], Modifier.weight(1f).fillMaxWidth())
                    FolderArtworkTile(songs[2], Modifier.weight(1f).fillMaxWidth())
                }
            }
            else -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(gap)) {
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                    FolderArtworkTile(songs[0], Modifier.weight(1f).fillMaxHeight())
                    FolderArtworkTile(songs[1], Modifier.weight(1f).fillMaxHeight())
                }
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                    FolderArtworkTile(songs[2], Modifier.weight(1f).fillMaxHeight())
                    FolderArtworkTile(songs[3], Modifier.weight(1f).fillMaxHeight())
                }
            }
        }
    }
}

@Composable
private fun FolderArtworkTile(song: MusicSong, modifier: Modifier = Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("pixelmusic_artwork", android.content.Context.MODE_PRIVATE) }
    val overridePath = remember(song.id) { prefs.getString("art_${song.id}", null) }
    val density = androidx.compose.ui.platform.LocalDensity.current.density
    val targetPx = (96f * density).roundToInt().coerceIn(96, 512)
    val bitmap = rememberArtworkBitmap(song, overridePath, targetPx)
    Box(
        modifier = modifier.background(Color(0xFF252A30)),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = song.album.ifBlank { song.title },
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Icon(Icons.Default.MusicNote, null, tint = Color.White.copy(alpha = .78f), modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun LibraryScreen(
    title: String,
    listState: LazyListState,
    songs: List<MusicSong>,
    currentIndex: Int,
    favoriteIds: Set<String>,
    recentIds: List<String>,
    onSongClick: (Int) -> Unit,
    onNavigate: (String) -> Unit,
    onPlaySongList: (List<Int>, Int?) -> Unit,
    queueSongIndices: List<Int>,
    onQueueRemove: (Int) -> Unit,
    onQueueMove: (Int, Int) -> Unit,
    onQueueClear: () -> Unit,
    onQueueAdd: (Int) -> Unit,
    playlistNames: List<String>,
    playlists: Map<String, List<String>>,
    onCreatePlaylist: (String) -> Unit,
    onAddToPlaylist: (String, MusicSong) -> Unit,
    onRemoveFromPlaylist: (String, MusicSong) -> Unit
) {
    val visibleSongs = remember(title, songs, favoriteIds, recentIds, playlists) {
        when {
            title == "Favorites" -> songs.filter { it.id.toString() in favoriteIds }
                .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.title })
            title == "Recently Played" -> recentIds.mapNotNull { id -> songs.firstOrNull { it.id.toString() == id } }
            title.startsWith("Playlist::") -> {
                val name = title.removePrefix("Playlist::")
                playlists[name].orEmpty().mapNotNull { id -> songs.firstOrNull { it.id.toString() == id } }
            }
            title.startsWith("Artist::") -> {
                val name = title.removePrefix("Artist::")
                songs.filter { it.artist.ifBlank { "Unknown Artist" } == name }
                    .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.title })
            }
            title.startsWith("Album::") -> {
                val name = title.removePrefix("Album::")
                songs.filter { it.album.ifBlank { "Unknown Album" } == name }
                    .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.title })
            }
            else -> songs
        }
    }
    var showCreateDialog by remember { mutableStateOf(false) }
    var playlistNameInput by remember { mutableStateOf("") }

    val groups = remember(title, songs) {
        when (title) {
            "Artists" -> songs.groupBy { it.artist.ifBlank { "Unknown Artist" } }
            "Albums" -> songs.groupBy { it.album.ifBlank { "Unknown Album" } }
            else -> emptyMap()
        }
    }

    Column(Modifier.fillMaxSize()) {
        if (title == "Newly Added") {
            Column(Modifier.fillMaxSize()) {
                Text(
                    "新規追加",
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Light,
                    modifier = Modifier.padding(horizontal = 22.dp, vertical = 18.dp)
                )
                Text(
                    "追加された順",
                    color = Color(0xFF777D83),
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 22.dp, vertical = 2.dp)
                )
                Spacer(Modifier.height(10.dp))
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    itemsIndexed(visibleSongs) { _, song ->
                        val index = songs.indexOfFirst { it.id == song.id }
                        SongRow(
                            song = song,
                            selected = song.id == songs.getOrNull(currentIndex)?.id,
                            onAddToQueue = { if (index >= 0) onQueueAdd(index) },
                            playlistNames = playlistNames,
                            onAddToPlaylist = onAddToPlaylist,
                            onClick = { if (index >= 0) onSongClick(index) }
                        )
                    }
                }
            }
        } else if (title.startsWith("Artist::") || title.startsWith("Album::")) {
            val detailTitle = when {
                title.startsWith("Artist::") -> title.removePrefix("Artist::")
                else -> title.removePrefix("Album::")
            }
            val headerSong = visibleSongs.firstOrNull()
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (headerSong != null) {
                    AlbumArt(
                        song = headerSong,
                        size = 168.dp,
                        modifier = Modifier.clickable {
                            val indices = visibleSongs.mapNotNull { song ->
                                songs.indexOfFirst { it.id == song.id }.takeIf { it >= 0 }
                            }
                            if (indices.isNotEmpty()) onPlaySongList(indices, indices.firstOrNull())
                        }
                    )
                    Spacer(Modifier.height(14.dp))
                }
                Text(
                    detailTitle,
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Light,
                    maxLines = 2
                )
                Text(
                    "${visibleSongs.size}曲",
                    color = Color(0xFF777D83),
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
                if (headerSong != null) {
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val indices = visibleSongs.mapNotNull { song ->
                                songs.indexOfFirst { it.id == song.id }.takeIf { it >= 0 }
                            }
                            if (indices.isNotEmpty()) onPlaySongList(indices, indices.firstOrNull())
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LocalAccentColor.current)
                    ) {
                        Icon(Icons.Default.PlayArrow, null)
                        Spacer(Modifier.width(6.dp))
                        Text("再生")
                    }
                }
            }
        } else if (title.startsWith("Playlist::")) {
            val playlistTitle = title.removePrefix("Playlist::")
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(64.dp).clip(RoundedCornerShape(10.dp))
                            .background(LocalAccentColor.current.copy(alpha = .18f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.QueueMusic,
                            contentDescription = null,
                            tint = LocalAccentColor.current,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Column(Modifier.padding(start = 16.dp).weight(1f)) {
                        Text(
                            playlistTitle,
                            color = Color.White,
                            fontSize = 27.sp,
                            fontWeight = FontWeight.Light,
                            maxLines = 2
                        )
                        Text(
                            "${visibleSongs.size}曲",
                            color = Color(0xFF777D83),
                            fontSize = 13.sp,
                            modifier = Modifier.padding(top = 3.dp)
                        )
                    }
                    IconButton(
                        onClick = {
                            val indices = visibleSongs.mapNotNull { song ->
                                val index = songs.indexOfFirst { it.id == song.id }
                                index.takeIf { it >= 0 }
                            }
                            if (indices.isNotEmpty()) onPlaySongList(indices, indices.firstOrNull())
                        },
                        enabled = visibleSongs.isNotEmpty()
                    ) {
                        Icon(
                            Icons.Default.PlayCircleFilled,
                            contentDescription = "再生",
                            tint = if (visibleSongs.isNotEmpty()) LocalAccentColor.current else Color(0xFF555A60),
                            modifier = Modifier.size(44.dp)
                        )
                    }
                }
            }
        } else {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    title,
                    color = Color.White,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Light
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    if (title == "Artists" || title == "Albums") "${groups.size}" else "${visibleSongs.size}",
                    color = Color(0xFF777D83),
                    fontSize = 13.sp,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }
        }

        if (visibleSongs.isEmpty() && title != "Play Queue" && title != "Playlists") {
            EmptyMessage(
                when {
                    title == "Favorites" -> "お気に入りはまだありません"
                    title == "Recently Played" -> "最近再生した曲はありません"
                    title.startsWith("Playlist::") -> "このプレイリストには曲がありません"
                    title.startsWith("Artist::") -> "このアーティストには曲がありません"
                    title.startsWith("Album::") -> "このアルバムには曲がありません"
                    else -> "音楽ファイルが見つかりません"
                }
            )
        } else {
            when {
                title.startsWith("Artist::") || title.startsWith("Album::") -> {
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        itemsIndexed(visibleSongs) { _, song ->
                            val actualIndex = songs.indexOf(song)
                            SongRow(
                                song = song,
                                selected = actualIndex == currentIndex,
                                onAddToQueue = { if (actualIndex >= 0) onQueueAdd(actualIndex) },
                                playlistNames = playlistNames,
                                onAddToPlaylist = onAddToPlaylist
                            ) {
                                if (actualIndex >= 0) {
                                    // Load whole list into queue in display order; start at tapped track
                                    // so both Next and Previous stay in context.
                                    val indices = visibleSongs.mapNotNull { s ->
                                        songs.indexOfFirst { it.id == s.id }.takeIf { it >= 0 }
                                    }
                                    onPlaySongList(indices, actualIndex)
                                }
                            }
                        }
                    }
                }
                title.startsWith("Playlist::") -> {
                    val playlistName = title.removePrefix("Playlist::")
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        itemsIndexed(visibleSongs) { _, song ->
                            val actualIndex = songs.indexOf(song)
                            SongRow(
                                song = song,
                                selected = actualIndex == currentIndex,
                                onAddToQueue = { if (actualIndex >= 0) onQueueAdd(actualIndex) },
                                playlistNames = emptyList(),
                                onAddToPlaylist = { _, _ -> },
                                onRemoveFromPlaylist = { onRemoveFromPlaylist(playlistName, song) },
                                showRemoveFromPlaylist = true
                            ) {
                                if (actualIndex >= 0) {
                                    val indices = visibleSongs.mapNotNull { s ->
                                        songs.indexOfFirst { it.id == s.id }.takeIf { it >= 0 }
                                    }
                                    onPlaySongList(indices, actualIndex)
                                }
                            }
                        }
                    }
                }
                title == "Favorites" || title == "Recently Played" -> {
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        itemsIndexed(visibleSongs) { _, song ->
                            val actualIndex = songs.indexOf(song)
                            SongRow(
                                song = song,
                                selected = actualIndex == currentIndex,
                                onAddToQueue = { if (actualIndex >= 0) onQueueAdd(actualIndex) },
                                playlistNames = playlistNames,
                                onAddToPlaylist = onAddToPlaylist
                            ) {
                                if (actualIndex >= 0) {
                                    val indices = visibleSongs.mapNotNull { s ->
                                        songs.indexOfFirst { it.id == s.id }.takeIf { it >= 0 }
                                    }
                                    onPlaySongList(indices, actualIndex)
                                }
                            }
                        }
                    }
                }
                title == "Play Queue" -> {
                    val queueSongs = queueSongIndices.mapNotNull { songs.getOrNull(it) }
                    Column(Modifier.fillMaxSize()) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${queueSongs.size} songs", color = Color(0xFF858C93), fontSize = 13.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = onQueueClear, enabled = queueSongs.isNotEmpty()) {
                                Text("Clear", color = if (queueSongs.isNotEmpty()) LocalAccentColor.current else Color(0xFF555A60))
                            }
                        }
                        LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                            itemsIndexed(queueSongs) { index, song ->
                                val actualIndex = queueSongIndices.getOrNull(index) ?: -1
                                QueueSongRow(
                                    song = song,
                                    position = index + 1,
                                    selected = actualIndex == currentIndex,
                                    onClick = { if (actualIndex >= 0) onSongClick(actualIndex) },
                                    onRemove = { onQueueRemove(index) },
                                    onMoveUp = { if (index > 0) onQueueMove(index, index - 1) },
                                    onMoveDown = { if (index < queueSongs.lastIndex) onQueueMove(index, index + 1) }
                                )
                            }
                        }
                    }
                }
                title == "Playlists" -> {
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        item {
                            PlaylistRow("Favorites", "Your favorite songs", favoriteIds.size, Icons.Default.Favorite) { onNavigate("Favorites") }
                        }
                        item {
                            PlaylistRow("Recently Played", "Songs played on this device", recentIds.size, Icons.Default.History) { onNavigate("Recently Played") }
                        }
                        playlistNames.forEach { playlistName ->
                            item(key = "playlist_$playlistName") {
                                PlaylistRow(
                                    playlistName,
                                    "Custom playlist",
                                    playlists[playlistName].orEmpty().size,
                                    Icons.Default.QueueMusic
                                ) { onNavigate("Playlist::$playlistName") }
                            }
                        }
                        item {
                            PlaylistRow("New Playlist", "Create a playlist", null, Icons.Default.Add) { showCreateDialog = true }
                        }
                    }
                }
                title == "Artists" || title == "Albums" -> {
                    LazyColumn(state = listState, contentPadding = PaddingValues(bottom = 16.dp)) {
                        groups.entries.forEach { (name, groupedSongs) ->
                            item(key = name) {
                                LibraryGroupRow(
                                    title = name,
                                    subtitle = "${groupedSongs.size} ${if (title == "Artists") "songs" else "tracks"}",
                                    isArtist = title == "Artists",
                                    seed = groupedSongs.firstOrNull()?.title?.hashCode()?.let { kotlin.math.abs(it) } ?: 0
                                ) {
                                    onNavigate("${if (title == "Artists") "Artist::" else "Album::"}$name")
                                }
                            }
                        }
                    }
                }
                title == "Songs" -> {
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        itemsIndexed(songs) { index, song ->
                            SongRow(
                                song = song,
                                selected = index == currentIndex,
                                onAddToQueue = { onQueueAdd(index) },
                                playlistNames = playlistNames,
                                onAddToPlaylist = onAddToPlaylist
                            ) { onSongClick(index) }
                        }
                    }
                }
                else -> SectionPlaceholder(title)
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false; playlistNameInput = "" },
            title = { Text("New Playlist") },
            text = {
                OutlinedTextField(
                    value = playlistNameInput,
                    onValueChange = { playlistNameInput = it },
                    label = { Text("Playlist name") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onCreatePlaylist(playlistNameInput)
                        showCreateDialog = false
                        playlistNameInput = ""
                    },
                    enabled = playlistNameInput.trim().isNotBlank() && !playlistNames.contains(playlistNameInput.trim())
                ) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false; playlistNameInput = "" }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun QueueSongRow(
    song: MusicSong,
    position: Int,
    selected: Boolean,
    onClick: () -> Unit,
    onRemove: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            position.toString(),
            color = if (selected) LocalAccentColor.current else Color(0xFF70767C),
            fontSize = 12.sp,
            modifier = Modifier.width(28.dp)
        )
        AlbumArt(song = song, size = 50.dp)
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(song.title, color = if (selected) LocalAccentColor.current else Color.White, maxLines = 1, fontSize = 15.sp)
            Text(song.artist, color = Color(0xFF9AA0A6), fontSize = 12.sp, maxLines = 1)
        }
        if (selected) {
            Icon(Icons.Default.GraphicEq, null, tint = LocalAccentColor.current)
        } else {
            Row {
                IconButton(onClick = onMoveUp, enabled = true) { Icon(Icons.Default.KeyboardArrowUp, null, tint = Color(0xFF777D83)) }
                IconButton(onClick = onMoveDown, enabled = true) { Icon(Icons.Default.KeyboardArrowDown, null, tint = Color(0xFF777D83)) }
                IconButton(onClick = onRemove) { Icon(Icons.Default.Close, null, tint = Color(0xFF999FA5)) }
            }
        }
    }
    HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
}

@Composable
private fun PlaylistRow(
    title: String,
    subtitle: String,
    count: Int?,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(58.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF20262C)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = LocalAccentColor.current, modifier = Modifier.size(28.dp))
        }
        Column(Modifier.weight(1f).padding(start = 16.dp)) {
            Text(title, color = Color.White, fontSize = 17.sp)
            Text(
                if (count == null) subtitle else "$subtitle • $count songs",
                color = Color(0xFF8F969D),
                fontSize = 13.sp,
                maxLines = 1
            )
        }
        Icon(Icons.Default.ChevronRight, null, tint = Color(0xFF777D83))
    }
    HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
}

@Composable
private fun LibraryGroupRow(title: String, subtitle: String, isArtist: Boolean, seed: Int, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (isArtist) ArtistArt(62.dp, seed) else AlbumArt(size = 62.dp)
        Column(Modifier.weight(1f).padding(start = 16.dp)) {
            Text(title, color = Color.White, fontSize = 17.sp, maxLines = 1)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, color = Color(0xFF8F969D), fontSize = 13.sp, maxLines = 1)
        }
        Icon(if (isArtist) Icons.Default.ChevronRight else Icons.Default.MoreVert, null, tint = Color(0xFF777D83))
    }
    HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
}

@Composable
private fun ArtistArt(size: Dp, seed: Int) {
    val palettes = listOf(
        listOf(Color(0xFF536778), Color(0xFF17212A)),
        listOf(Color(0xFF744C5C), Color(0xFF20151C)),
        listOf(Color(0xFF5B704E), Color(0xFF182017)),
        listOf(Color(0xFF6B5A82), Color(0xFF211B2B))
    )
    val palette = palettes[seed % palettes.size]
    Box(Modifier.size(size).clip(RoundedCornerShape(50)).background(Brush.linearGradient(palette)), contentAlignment = Alignment.Center) {
        Icon(Icons.Default.Person, null, tint = Color.White.copy(alpha = .82f), modifier = Modifier.size(size * .48f))
    }
}

@Composable
private fun AudioEnhancementScreen(
    enabled: Boolean,
    mode: String,
    strength: String,
    onEnabledChange: (Boolean) -> Unit,
    onModeChange: (String) -> Unit,
    onStrengthChange: (String) -> Unit
) {
    var localEnabled by remember { mutableStateOf(enabled) }
    var localMode by remember { mutableStateOf(mode) }
    var localStrength by remember { mutableStateOf(strength) }
    LaunchedEffect(enabled) { localEnabled = enabled }
    LaunchedEffect(mode) { localMode = mode }
    LaunchedEffect(strength) { localStrength = strength }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        item {
            Spacer(Modifier.height(20.dp))
            Text("音質補完", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Medium)
            Text("DSEE Ultimate風の軽量エンハンサー • 試験版", color = Color(0xFF9299A1), fontSize = 12.sp)
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("音質補完を有効にする", color = Color.White, fontSize = 16.sp)
                    Text("イコライザーとは独立して動作", color = Color(0xFF9299A1), fontSize = 12.sp)
                }
                Switch(checked = localEnabled, onCheckedChange = {
                    localEnabled = it
                    onEnabledChange(it)
                })
            }
            Spacer(Modifier.height(22.dp))
            Text("音質モード", color = Color(0xFFB8BEC5), fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("natural" to "ナチュラル", "clarity" to "明瞭感").forEach { (value, label) ->
                    FilterChip(
                        modifier = Modifier.weight(1f),
                        selected = localMode == value,
                        onClick = {
                            localMode = value
                            onModeChange(value)
                        },
                        label = { Text(label) }
                    )
                }
            }
            Spacer(Modifier.height(22.dp))
            Text("補正の強さ", color = Color(0xFFB8BEC5), fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("weak" to "弱", "medium" to "中", "strong" to "強").forEach { (value, label) ->
                    FilterChip(
                        modifier = Modifier.weight(1f),
                        selected = localStrength == value,
                        onClick = {
                            localStrength = value
                            onStrengthChange(value)
                        },
                        label = { Text(label) }
                    )
                }
            }
            Text(
                when (localStrength) {
                    "weak" -> "補正を控えめにします。高音が強く感じられる音源におすすめです。"
                    "strong" -> "補正を強めます。音源によっては高音や音の輪郭が強調されすぎることがあります。"
                    else -> "標準的な強さです。まずはこの設定から聴き比べてください。"
                },
                color = Color(0xFF9299A1), fontSize = 12.sp, lineHeight = 17.sp
            )
            Spacer(Modifier.height(18.dp))
            Surface(color = Color.White.copy(alpha = 0.05f), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text(if (localMode == "clarity") "明瞭感モード" else "ナチュラルモード", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (localMode == "clarity") "高域を控えめに持ち上げ、ボーカルやギターの輪郭・抜けを感じやすくします。音源によっては高音が強く感じられることがあります。"
                        else "音色の変化を小さく抑えながら、低域と高域にごく軽い補正を加えます。自然な聴き心地を目指すモードです。",
                        color = Color(0xFFB8BEC5), fontSize = 13.sp, lineHeight = 19.sp
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("これは音声信号に軽い周波数補正を加える試験機能です。AIによる音源復元や、ソニーのDSEE Ultimateそのものではありません。", color = Color(0xFF858D96), fontSize = 12.sp, lineHeight = 17.sp)
            Spacer(Modifier.height(28.dp))
        }
    }
}

@Composable
private fun EqualizerScreen(
    enabled: Boolean,
    available: Boolean,
    initialGains: List<Float>,
    onEnabledChange: (Boolean) -> Unit,
    onBandChange: (Int, Float) -> Unit,
    onPresetChange: (List<Float>) -> Unit,
    masterVolumePercent: Float,
    onMasterVolumeChange: (Float) -> Unit
) {
    val labels = listOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")
    val presets = linkedMapOf(
        "Flat" to List(10) { 0f },
        "Rock" to listOf(4f, 3f, -1f, -2f, 0f, 2f, 3f, 4f, 3f, 3f),
        "Metal" to listOf(3f, 3f, 1f, -1f, -2f, 1f, 3f, 4f, 2f, 1f),
        "Pop" to listOf(-1f, 0f, 1f, 2f, 3f, 2f, 1f, 0f, -1f, -1f),
        "Jazz" to listOf(2f, 1f, 0f, 1f, -1f, -1f, 0f, 1f, 2f, 2f),
        "Bass" to listOf(5f, 4f, 3f, 2f, 0f, 0f, 0f, 0f, 0f, 0f),
        "Vocal" to listOf(-2f, -1f, 0f, 1f, 2f, 3f, 3f, 2f, 1f, 0f)
    )
    var localEnabled by remember { mutableStateOf(enabled) }
    var localMasterVolumePercent by remember { mutableStateOf(masterVolumePercent.coerceIn(0f, 130f)) }
    var gains by remember { mutableStateOf(initialGains.map { it.coerceIn(-10f, 10f) }.take(10).let { if (it.size == 10) it else List(10) { 0f } }) }
    var selectedPreset by remember { mutableStateOf("Custom") }
    val equalizerAccent = LocalAccentColor.current
    LaunchedEffect(enabled) { localEnabled = enabled }
    LaunchedEffect(masterVolumePercent) { localMasterVolumePercent = masterVolumePercent.coerceIn(0f, 130f) }
    LaunchedEffect(initialGains) {
        if (initialGains.size == 10 && initialGains != gains) gains = initialGains.map { it.coerceIn(-10f, 10f) }
    }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        item {
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("イコライザー", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Medium)
                    Text("10バンド • Xperia Music風", color = Color(0xFF9299A1), fontSize = 12.sp)
                }
                Switch(checked = localEnabled, onCheckedChange = {
                    localEnabled = it
                    onEnabledChange(it)
                })
            }
            Spacer(Modifier.height(14.dp))
            if (!available) {
                Text("この端末では音声エフェクトを初期化できませんでした。再生を開始してから再度確認してください。", color = Color(0xFFFFC266), fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
            }
            Text("マスターボリューム", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.VolumeDown, contentDescription = "音量を下げる", tint = Color(0xFFB8BEC5))
                Slider(
                    value = localMasterVolumePercent,
                    onValueChange = { value ->
                        localMasterVolumePercent = value.coerceIn(0f, 130f)
                        onMasterVolumeChange(localMasterVolumePercent)
                    },
                    valueRange = 0f..130f,
                    steps = 129,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                Icon(Icons.Filled.VolumeUp, contentDescription = "音量を上げる", tint = Color(0xFFB8BEC5))
            }
            // Scale is 0–130%; 100% is the neutral/default mark (not center of the track).
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("0%", color = Color(0xFF777D83), fontSize = 11.sp)
                Text("100%", color = if (localMasterVolumePercent.roundToInt() == 100) equalizerAccent else Color(0xFF777D83), fontSize = 11.sp)
                Text("130%", color = Color(0xFF777D83), fontSize = 11.sp)
            }
            Text("${localMasterVolumePercent.roundToInt().coerceIn(0, 130)}%", color = equalizerAccent, fontSize = 13.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.End)
            Spacer(Modifier.height(18.dp))
            Text("プリセット", color = Color(0xFFB8BEC5), fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Flat", "Rock", "Metal", "Pop").forEach { preset ->
                    FilterChip(
                        selected = selectedPreset == preset,
                        onClick = {
                            selectedPreset = preset
                            gains = presets[preset] ?: List(10) { 0f }
                            onPresetChange(gains)
                        },
                        label = { Text(preset, fontSize = 11.sp) }
                    )
                }
            }
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Jazz", "Bass", "Vocal").forEach { preset ->
                    FilterChip(
                        selected = selectedPreset == preset,
                        onClick = {
                            selectedPreset = preset
                            gains = presets[preset] ?: List(10) { 0f }
                            onPresetChange(gains)
                        },
                        label = { Text(preset, fontSize = 11.sp) }
                    )
                }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = {
                    selectedPreset = "Flat"
                    gains = presets.getValue("Flat")
                    onPresetChange(gains)
                }) { Text("リセット") }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("+10 dB", color = Color(0xFF858D96), fontSize = 10.sp)
                Text("0 dB", color = Color(0xFF858D96), fontSize = 10.sp)
                Text("−10 dB", color = Color(0xFF858D96), fontSize = 10.sp)
            }
            Spacer(Modifier.height(8.dp))
        }
        item {
            Row(Modifier.fillMaxWidth().height(220.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                labels.forEachIndexed { index, label ->
                    Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (gains[index] > 0f) "+${gains[index].toInt()}" else gains[index].toInt().toString(), color = if (localEnabled) equalizerAccent else Color(0xFF858D96), fontSize = 9.sp, maxLines = 1)
                        Spacer(Modifier.height(5.dp))
                        Canvas(
                            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 5.dp).pointerInput(index, localEnabled) {
                                if (localEnabled) {
                                    detectDragGestures(
                                        onDragStart = { offset ->
                                            val value = (10f - (offset.y / size.height.coerceAtLeast(1) * 20f)).coerceIn(-10f, 10f)
                                            gains = gains.toMutableList().also { it[index] = value }
                                            selectedPreset = "Custom"
                                            onBandChange(index, value)
                                        },
                                        onDrag = { change, _ ->
                                                val value = (10f - (change.position.y / size.height.coerceAtLeast(1) * 20f)).coerceIn(-10f, 10f)
                                            gains = gains.toMutableList().also { it[index] = value }
                                            selectedPreset = "Custom"
                                            onBandChange(index, value)
                                        }
                                    )
                                }
                            }
                        ) {
                            val x = size.width / 2f
                            val top = 5.dp.toPx()
                            val bottom = size.height - top
                            val zeroY = top + (bottom - top) / 2f
                            val valueY = top + (bottom - top) * ((10f - gains[index]) / 20f)
                            drawLine(Color.White.copy(alpha = .18f), Offset(x, top), Offset(x, bottom), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(if (localEnabled) equalizerAccent else Color(0xFF6D747B), Offset(x, zeroY), Offset(x, valueY), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
                            drawLine(Color.White.copy(alpha = .35f), Offset(x - 5.dp.toPx(), zeroY), Offset(x + 5.dp.toPx(), zeroY), strokeWidth = 1.dp.toPx())
                            drawCircle(if (localEnabled) Color.White else Color(0xFF777D84), radius = 5.dp.toPx(), center = Offset(x, valueY))
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(label, color = Color(0xFFB6BDC4), fontSize = 9.sp, maxLines = 1)
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("各バンドは −10 dB 〜 +10 dB。変更は再生中の音声に反映され、設定は保存されます。", color = Color(0xFF858D96), fontSize = 12.sp)
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun SettingsScreen(
    selectedTheme: AppTheme,
    onThemeChange: (AppTheme) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var backupMessage by remember { mutableStateOf("") }
    val createBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri == null) {
            backupMessage = "バックアップをキャンセルしました"
        } else {
            backupMessage = runCatching {
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    ZipOutputStream(output).use { zip ->
                        fun addFile(file: File, base: File, prefix: String) {
                            if (file.isDirectory) {
                                file.listFiles()?.forEach { addFile(it, base, prefix) }
                            } else if (file.isFile) {
                                val relative = file.relativeTo(base).invariantSeparatorsPath
                                zip.putNextEntry(ZipEntry("$prefix$relative"))
                                FileInputStream(file).use { it.copyTo(zip) }
                                zip.closeEntry()
                            }
                        }
                        val filesDir = context.filesDir
                        addFile(filesDir, filesDir, "files/")
                        val prefsDir = File(context.applicationInfo.dataDir, "shared_prefs")
                        listOf("pixelmusic_settings.xml", "pixelmusic_artwork.xml").forEach { prefsName ->
                            val prefsFile = File(prefsDir, prefsName)
                            if (prefsFile.isFile) addFile(prefsFile, prefsDir, "prefs/")
                        }
                    } 
                } ?: error("保存先を開けませんでした")
                "バックアップを保存しました"
            }.getOrElse { "保存に失敗しました: ${it.message ?: "不明なエラー"}" }
        }
    }
    val restoreBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) {
            backupMessage = "復元をキャンセルしました"
        } else {
            backupMessage = runCatching {
                var restoredFiles = 0
                var restoredPrefs = 0
                var seenEntries = 0
                context.contentResolver.openInputStream(uri)?.use { input ->
                    ZipInputStream(input).use { zip ->
                        var entry = zip.nextEntry
                        while (entry != null) {
                            seenEntries++
                            val name = entry.name.replace('\\', '/')
                            if (!name.startsWith("/") && !name.split("/").contains("..")) {
                                val target: File? = when {
                                    name.startsWith("files/") && name.length > 6 ->
                                        File(context.filesDir, name.removePrefix("files/"))
                                    name == "prefs/pixelmusic_settings.xml" || name == "prefs/pixelmusic_artwork.xml" -> {
                                        val prefsDir = File(context.applicationInfo.dataDir, "shared_prefs")
                                        prefsDir.mkdirs()
                                        File(prefsDir, name.removePrefix("prefs/"))
                                    }
                                    // Also accept archives that contain the shared_prefs folder directly.
                                    name == "pixelmusic_settings.xml" || name == "pixelmusic_artwork.xml" -> {
                                        val prefsDir = File(context.applicationInfo.dataDir, "shared_prefs")
                                        prefsDir.mkdirs()
                                        File(prefsDir, name)
                                    }
                                    else -> null
                                }
                                if (target != null) {
                                    if (entry.isDirectory) {
                                        target.mkdirs()
                                    } else {
                                        target.parentFile?.mkdirs()
                                        FileOutputStream(target).use { output ->
                                            val buffer = ByteArray(8192)
                                            while (true) {
                                                val count = zip.read(buffer)
                                                if (count < 0) break
                                                output.write(buffer, 0, count)
                                            }
                                        }
                                        if (target.name.endsWith(".xml") && target.parentFile?.name == "shared_prefs") restoredPrefs++ else restoredFiles++
                                    }
                                }
                            }
                            zip.closeEntry()
                            entry = zip.nextEntry
                        }
                    }
                } ?: error("ファイルを開けませんでした")
                if (seenEntries == 0) error("ZIP内にファイルがありません。正しいバックアップを選択してください")
                if (restoredFiles == 0 && restoredPrefs == 0) {
                    error("ZIP内に復元対象が見つかりません（項目数: $seenEntries）。バックアップ形式を確認してください")
                }
                "復元処理完了：画像・データ ${restoredFiles}件、設定 ${restoredPrefs}件。アプリを完全終了して再起動してください。"
            }.getOrElse { "復元に失敗しました: ${it.message ?: "不明なエラー"}" }
        }
    }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        item {
            Spacer(Modifier.height(18.dp))
            Text("Theme", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            Text("テーマカラー", color = Color(0xFF8F969D), fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
        }
        item {
            Spacer(Modifier.height(12.dp))
            Text("データのバックアップ", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            Text(
                "アーティスト画像・画像位置・アプリ設定をZIPファイルに保存します。再インストール前に保存してください。",
                color = Color(0xFF8F969D), fontSize = 13.sp
            )
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { createBackupLauncher.launch("PixelMusic_Backup.zip") },
                    modifier = Modifier.weight(1f)
                ) { Text("データを保存") }
                OutlinedButton(
                    onClick = { restoreBackupLauncher.launch(arrayOf("application/zip", "application/octet-stream")) },
                    modifier = Modifier.weight(1f)
                ) { Text("データを復元") }
            }
            if (backupMessage.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(backupMessage, color = Color(0xFFB9C1C9), fontSize = 12.sp)
            }
            Spacer(Modifier.height(24.dp))
        }
        itemsIndexed(AppTheme.values().toList()) { _, theme ->
            val selected = theme == selectedTheme
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                    .background(if (selected) theme.accent.copy(alpha = .16f) else Color.Transparent)
                    .clickable { onThemeChange(theme) }
                    .padding(horizontal = 14.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(30.dp).clip(RoundedCornerShape(50)).background(theme.accent))
                Column(Modifier.weight(1f).padding(start = 14.dp)) {
                    Text(theme.label, color = Color.White, fontSize = 16.sp)
                    Text(theme.description, color = Color(0xFF8F969D), fontSize = 12.sp)
                }
                if (selected) Icon(Icons.Default.Check, null, tint = theme.accent)
            }
            Spacer(Modifier.height(5.dp))
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
}

@Composable
private fun SectionPlaceholder(title: String) {
    Column(Modifier.fillMaxWidth().padding(22.dp)) {
        Text(
            when (title) {
                "Play Queue" -> "再生キュー"
                "Playlists" -> "プレイリスト"
                "Folders" -> "フォルダ"
                "Google Drive" -> "Google Drive"
                "New Releases" -> "新着リリース"
                "Charts" -> "チャート"
                "Settings" -> "設定"
                "Equalizer" -> "イコライザー"
                "Audio Enhancement" -> "音質補完（試験版）"
                else -> title
            },
            color = Color.White,
            fontSize = 18.sp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "この画面の詳細UIは次の段階で実装します。",
            color = Color(0xFF858C93),
            fontSize = 13.sp
        )
    }
}

@Composable
private fun EmptyMessage(message: String) {
    Text(
        message,
        color = Color(0xFF9AA0A6),
        modifier = Modifier.padding(horizontal = 22.dp)
    )
}

@Composable
private fun SongRow(
    song: MusicSong,
    selected: Boolean,
    onAddToQueue: () -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit,
    onRemoveFromPlaylist: () -> Unit = {},
    showRemoveFromPlaylist: Boolean = false,
    onClick: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AlbumArt(song = song, size = 56.dp)
            Column(Modifier.weight(1f).padding(start = 16.dp)) {
                Text(song.title.ifBlank { "Unknown title" }, color = if (selected) LocalAccentColor.current else Color.White, maxLines = 1, fontSize = 16.sp)
                Text(listOf(song.artist, song.album).filter { it.isNotBlank() }.joinToString(" • "), color = Color(0xFF9AA0A6), fontSize = 13.sp, maxLines = 1)
            }
            if (selected && song.title.isNotBlank()) {
                Icon(Icons.Default.GraphicEq, null, tint = LocalAccentColor.current)
            } else {
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.MoreVert, "More", tint = Color(0xFF777B80))
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Add to Play Queue") },
                            leadingIcon = { Icon(Icons.Default.QueueMusic, null) },
                            onClick = {
                                menuOpen = false
                                onAddToQueue()
                            }
                        )
                        playlistNames.forEach { playlistName ->
                            DropdownMenuItem(
                                text = { Text("Add to $playlistName") },
                                leadingIcon = { Icon(Icons.Default.PlaylistAdd, null) },
                                onClick = {
                                    menuOpen = false
                                    onAddToPlaylist(playlistName, song)
                                }
                            )
                        }
                        if (playlistNames.isEmpty()) {
                            DropdownMenuItem(
                                text = { Text("No custom playlists yet") },
                                enabled = false,
                                onClick = { }
                            )
                        }
                        if (showRemoveFromPlaylist) {
                            DropdownMenuItem(
                                text = { Text("Remove from Playlist") },
                                leadingIcon = { Icon(Icons.Default.RemoveCircleOutline, null) },
                                onClick = {
                                    menuOpen = false
                                    onRemoveFromPlaylist()
                                }
                            )
                        }
                    }
                }
            }
        }
        HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
    }
}

private object ArtworkBitmapCache {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    @Synchronized
    fun get(key: String): Bitmap? = cache.get(key)

    @Synchronized
    fun put(key: String, bitmap: Bitmap): Bitmap {
        cache.put(key, bitmap)
        return bitmap
    }
}

private val artworkLoadSemaphore = Semaphore(2)

private fun artworkCacheKey(song: MusicSong, overridePath: String?, targetPx: Int): String {
    val source = overridePath?.takeIf { it.isNotBlank() } ?: song.artworkUriString ?: song.uriString
    return "$source|${targetPx.coerceAtLeast(64)}"
}

private fun calculateSampleSize(width: Int, height: Int, targetPx: Int): Int {
    val target = targetPx.coerceAtLeast(64)
    var sample = 1
    while (width / sample > target * 2 || height / sample > target * 2) {
        sample *= 2
    }
    return sample
}

private fun decodeSampledFile(path: String, targetPx: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    val options = BitmapFactory.Options().apply {
        inSampleSize = calculateSampleSize(bounds.outWidth, bounds.outHeight, targetPx)
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    return BitmapFactory.decodeFile(path, options)
}

private fun decodeSampledBytes(bytes: ByteArray, targetPx: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    val options = BitmapFactory.Options().apply {
        inSampleSize = calculateSampleSize(bounds.outWidth, bounds.outHeight, targetPx)
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
}

private suspend fun loadArtworkBitmap(
    context: android.content.Context,
    song: MusicSong,
    overridePath: String?,
    targetPx: Int
): Bitmap? = withContext(Dispatchers.IO) {
    val key = artworkCacheKey(song, overridePath, targetPx)
    ArtworkBitmapCache.get(key)?.let { return@withContext it }

    artworkLoadSemaphore.withPermit {
        ArtworkBitmapCache.get(key)?.let { return@withPermit it }
        val bitmap = runCatching {
            // 1) User-selected artwork saved by the edit screen.
            if (!overridePath.isNullOrBlank() && File(overridePath).exists()) {
                decodeSampledFile(overridePath, targetPx)
            } else {
                // 2) MediaStore album artwork URI.
                var result: Bitmap? = null
                song.artworkUriString?.let { artworkUriString ->
                    result = runCatching {
                        context.contentResolver.openInputStream(Uri.parse(artworkUriString))?.use { input ->
                            input.readBytes().let { bytes -> decodeSampledBytes(bytes, targetPx) }
                        }
                    }.getOrNull()
                }

                // 3) Embedded artwork inside the audio file as a fallback.
                if (result == null) {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(context, Uri.parse(song.uriString))
                        retriever.embeddedPicture?.let { bytes ->
                            result = decodeSampledBytes(bytes, targetPx)
                        }
                    } finally {
                        retriever.release()
                    }
                }
                result
            }
        }.getOrNull()

        bitmap?.let { ArtworkBitmapCache.put(key, it) }
        bitmap
    }
}

@Composable
private fun rememberArtworkBitmap(song: MusicSong?, overridePath: String?, targetPx: Int): Bitmap? {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(song?.uriString, song?.artworkUriString, overridePath, targetPx) {
        mutableStateOf<Bitmap?>(null)
    }
    LaunchedEffect(song?.uriString, song?.artworkUriString, overridePath, targetPx) {
        bitmap = null
        if (song != null) {
            bitmap = loadArtworkBitmap(
                context = context,
                song = song,
                overridePath = overridePath,
                targetPx = targetPx
            )
        }
    }
    return bitmap
}

@Composable
private fun ArtworkImage(song: MusicSong?, modifier: Modifier, contentScale: ContentScale) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("pixelmusic_artwork", android.content.Context.MODE_PRIVATE) }
    val overridePath = song?.id?.let { prefs.getString("art_$it", null) }
    val density = androidx.compose.ui.platform.LocalDensity.current.density
    val targetPx = (420f * density).roundToInt().coerceAtMost(1024)
    val bitmap = rememberArtworkBitmap(song, overridePath, targetPx)

    Box(modifier.background(Brush.verticalGradient(listOf(LocalAccentColor.current.copy(alpha=.55f), Color(0xFF101419))))) {
        bitmap?.let {
            Image(bitmap = it.asImageBitmap(), contentDescription = song?.album ?: "Album artwork", modifier = Modifier.fillMaxSize(), contentScale = contentScale)
        }
    }
}

@Composable
private fun AlbumArt(
    song: MusicSong? = null,
    size: Dp,
    modifier: Modifier = Modifier,
    showFallback: Boolean = true
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("pixelmusic_artwork", android.content.Context.MODE_PRIVATE) }
    val overridePath = song?.id?.let { prefs.getString("art_$it", null) }
    val density = androidx.compose.ui.platform.LocalDensity.current.density
    val targetPx = (size.value * density).roundToInt().coerceAtLeast(96).coerceAtMost(2048)
    val bitmap = rememberArtworkBitmap(song, overridePath, targetPx)

    Box(
        modifier
            .then(Modifier.size(size))
            .clip(RoundedCornerShape(7.dp))
            .background(
                Brush.linearGradient(
                    listOf(LocalAccentColor.current.copy(alpha = .88f), Color(0xFF11151A), Color(0xFF20252B))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = song?.album ?: "Album artwork",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .08f)))
        } else if (showFallback) {
            Icon(Icons.Default.MusicNote, null, tint = Color.White.copy(alpha = .82f), modifier = Modifier.size(size * .43f))
        }
    }
}

@Composable
private fun MiniPlayer(
    song: MusicSong,
    playing: Boolean,
    onPlay: () -> Unit,
    onOpen: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long
) {
    var positionMs by remember(song.uriString) { mutableLongStateOf(positionProvider().coerceAtLeast(0L)) }
    var durationMs by remember(song.uriString) { mutableLongStateOf(durationProvider().coerceAtLeast(song.duration)) }

    LaunchedEffect(playing, song.uriString) {
        while (true) {
            positionMs = positionProvider().coerceAtLeast(0L)
            val latestDuration = durationProvider().coerceAtLeast(0L)
            if (latestDuration > 0L) durationMs = latestDuration
            if (!playing) break
            delay(500L)
        }
    }

    val progress = if (durationMs > 0L) (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f

    Column(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFF111418))
            .clickable(onClick = onOpen)
    ) {
        // Xperia-like thin progress indicator at the very top.
        Box(Modifier.fillMaxWidth().height(3.dp).background(Color.White.copy(alpha = .10f))) {
            Box(
                Modifier
                    .fillMaxWidth(progress)
                    .fillMaxHeight()
                    .background(LocalAccentColor.current)
            )
        }

        Row(
            Modifier
                .fillMaxWidth()
                .height(76.dp)
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AlbumArt(song = song, size = 54.dp)

            Column(
                Modifier
                    .weight(1f)
                    .padding(start = 12.dp, end = 4.dp)
            ) {
                Text(
                    song.title,
                    color = Color.White,
                    maxLines = 1,
                    softWrap = false,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .basicMarquee(
                            iterations = Int.MAX_VALUE,
                            animationMode = MarqueeAnimationMode.Immediately,
                            spacing = MarqueeSpacing(24.dp),
                            velocity = 30.dp
                        )
                )
                Text(
                    song.artist,
                    color = Color(0xFF9AA0A6),
                    fontSize = 12.sp,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier
                        .fillMaxWidth()
                        .basicMarquee(
                            iterations = Int.MAX_VALUE,
                            animationMode = MarqueeAnimationMode.Immediately,
                            spacing = MarqueeSpacing(20.dp),
                            velocity = 28.dp
                        )
                )
                Text(
                    song.album,
                    color = Color(0xFF6F757B),
                    fontSize = 10.sp,
                    maxLines = 1
                )
            }

            IconButton(
                onClick = onPrevious,
                modifier = Modifier.size(42.dp)
            ) {
                Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(23.dp))
            }
            IconButton(
                onClick = onPlay,
                modifier = Modifier.size(46.dp)
            ) {
                Icon(
                    if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                    if (playing) "Pause" else "Play",
                    tint = LocalAccentColor.current,
                    modifier = Modifier.size(28.dp)
                )
            }
            IconButton(
                onClick = onNext,
                modifier = Modifier.size(42.dp)
            ) {
                Icon(Icons.Default.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(23.dp))
            }
        }
    }
}

@Composable
private fun OptionsScreen(
    folderRevealEnabled: Boolean,
    onFolderRevealEnabledChange: (Boolean) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF101216))
            .padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Option", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Medium)
        Text(
            "ホーム画面の表示やアニメーションを設定します。",
            color = Color(0xFF9DA3AA),
            fontSize = 13.sp
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF1C2026))
                .clickable { onFolderRevealEnabledChange(!folderRevealEnabled) }
                .padding(horizontal = 16.dp, vertical = 15.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("再生中フォルダの浮上演出", color = Color.White, fontSize = 15.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    if (folderRevealEnabled) "再生開始から10秒後に表示" else "表示しない",
                    color = Color(0xFF9DA3AA),
                    fontSize = 12.sp
                )
            }
            Switch(
                checked = folderRevealEnabled,
                onCheckedChange = onFolderRevealEnabledChange
            )
        }
    }
}

@Composable
private fun NavigationDrawer(
    selected: String,
    progress: Float,
    onDragStart: () -> Unit,
    onDragProgress: (Float) -> Unit,
    onDragEnd: () -> Unit,
    onClose: () -> Unit,
    onSelect: (String) -> Unit
) {
    val latestProgress by rememberUpdatedState(progress)
    Box(Modifier.fillMaxSize()) {
        Spacer(
            Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.55f * progress))
                .clickable(onClick = onClose)
        )
        Column(
            Modifier
                .width(300.dp)
                .fillMaxHeight()
                .graphicsLayer {
                    // Keep sub-pixel movement so the drawer glides smoothly instead of stepping by whole pixels.
                    translationX = -300.dp.toPx() * (1f - progress)
                }
                .background(Color(0xE6121417))
                .pointerInput(Unit) {
                    var startProgress = latestProgress
                    var totalDrag = 0f
                    detectHorizontalDragGestures(
                        onDragStart = {
                            startProgress = latestProgress
                            totalDrag = 0f
                            onDragStart()
                        },
                        onHorizontalDrag = { change, dragAmount ->
                            totalDrag += dragAmount
                            onDragProgress(startProgress + totalDrag / 300.dp.toPx())
                            change.consume()
                        },
                        onDragEnd = onDragEnd,
                        onDragCancel = onDragEnd
                    )
                }
                .padding(top = 32.dp)
        ) {
            Text(
                "PIXEL MUSIC",
                color = LocalAccentColor.current,
                fontSize = 22.sp,
                fontWeight = FontWeight.Light,
                modifier = Modifier.padding(24.dp)
            )
            listOf(
                "Home", "Play Queue", "Playlists", "Artists", "Albums", "Songs",
                "Genres", "Folders", "Equalizer", "Audio Enhancement", "Settings", "Option"
            ).forEach { item ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(item) }
                        .background(
                            if (item == selected) LocalAccentColor.current.copy(alpha = .16f) else Color.Transparent
                        )
                        .padding(horizontal = 24.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        item,
                        color = if (item == selected) LocalAccentColor.current else Color(0xFFE2E5E8),
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FullPlayer(
    song: MusicSong,
    playing: Boolean,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long,
    onSeekTo: (Long) -> Unit,
    shuffleEnabled: Boolean,
    repeatMode: Int,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit,
    onEditInfo: () -> Unit,
    sleepTimerMinutes: Int? = null,
    onSetSleepTimer: (Int?) -> Unit = {},
    onNavigate: (String) -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var positionMs by remember(song.uriString) { mutableLongStateOf(positionProvider().coerceAtLeast(0L)) }
    var durationMs by remember(song.uriString) { mutableLongStateOf(durationProvider().coerceAtLeast(0L)) }
    var moreOpen by remember { mutableStateOf(false) }
    var sleepTimerDialog by remember { mutableStateOf(false) }
    var detailDialog by remember { mutableStateOf(false) }
    var addToPlaylistDialog by remember { mutableStateOf(false) }
    var artworkTapPulse by remember(song.uriString) { mutableStateOf(false) }
    val artworkScale by animateFloatAsState(
        targetValue = if (artworkTapPulse) 0.965f else 1f,
        animationSpec = tween(durationMillis = 130),
        label = "artworkTapScale"
    )
    val artworkTapScope = rememberCoroutineScope()
    var artworkSlideDirection by remember { mutableIntStateOf(1) }

    fun requestNextWithArtworkAnimation() {
        artworkSlideDirection = 1
        onNext()
    }
    fun requestPreviousWithArtworkAnimation() {
        artworkSlideDirection = -1
        onPrevious()
    }

    LaunchedEffect(playing, song.uriString) {
        while (true) {
            positionMs = positionProvider().coerceAtLeast(0L)
            val latestDuration = durationProvider().coerceAtLeast(0L)
            if (latestDuration > 0L) durationMs = latestDuration
            if (!playing) break
            delay(350L)
        }
    }

    val safeDuration = durationMs.coerceAtLeast(1L)
    val sliderValue = (positionMs.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)
    val seekInteractionSource = remember { MutableInteractionSource() }
    val seekColors = SliderDefaults.colors(
        thumbColor = Color.White,
        activeTrackColor = Color.White,
        inactiveTrackColor = Color.White.copy(alpha = .24f)
    )
    val remainingMs = (durationMs - positionMs).coerceAtLeast(0L)
    val repeatLabel = when (repeatMode) {
        androidx.media3.common.Player.REPEAT_MODE_ONE -> "1"
        androidx.media3.common.Player.REPEAT_MODE_ALL -> "ALL"
        else -> "OFF"
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        LocalAccentColor.current.copy(alpha = .82f),
                        Color(0xFF20262C),
                        Color(0xFF08090B),
                        Color(0xFF050607)
                    )
                )
            )
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 20.dp)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onBack) {
                    Icon(Icons.Default.KeyboardArrowDown, "Close player", tint = Color.White)
                }
                Spacer(Modifier.weight(1f))
                Text(
                    "NOW PLAYING",
                    color = Color.White.copy(alpha = .72f),
                    fontSize = 11.sp,
                    letterSpacing = 1.4.sp
                )
                Spacer(Modifier.weight(1f))
                Box {
                    IconButton({ moreOpen = true }) {
                        Icon(Icons.Default.MoreVert, "More", tint = Color.White)
                    }
                    DropdownMenu(
                        expanded = moreOpen,
                        onDismissRequest = { moreOpen = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text(if (sleepTimerMinutes == null) "スリープタイマー" else "スリープタイマー（${sleepTimerMinutes}分）") },
                            leadingIcon = { Icon(Icons.Default.Timer, null) },
                            onClick = { moreOpen = false; sleepTimerDialog = true }
                        )
                        DropdownMenuItem(
                            text = { Text("アーティスト") },
                            leadingIcon = { Icon(Icons.Default.Person, null) },
                            onClick = { moreOpen = false; onBack(); onNavigate("Artist::${song.artist.ifBlank { "Unknown Artist" }}") }
                        )
                        DropdownMenuItem(
                            text = { Text("アルバム") },
                            leadingIcon = { Icon(Icons.Default.Album, null) },
                            onClick = { moreOpen = false; onBack(); onNavigate("Album::${song.album.ifBlank { "Unknown Album" }}") }
                        )
                        DropdownMenuItem(
                            text = { Text("共有") },
                            leadingIcon = { Icon(Icons.Default.Share, null) },
                            onClick = {
                                moreOpen = false
                                val sendIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(android.content.Intent.EXTRA_TEXT, "${song.title} — ${song.artist}")
                                }
                                context.startActivity(android.content.Intent.createChooser(sendIntent, "共有"))
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("ミュージック情報を編集") },
                            leadingIcon = { Icon(Icons.Default.Edit, null) },
                            onClick = { moreOpen = false; onEditInfo() }
                        )
                        DropdownMenuItem(
                            text = { Text("詳細情報") },
                            leadingIcon = { Icon(Icons.Default.Info, null) },
                            onClick = { moreOpen = false; detailDialog = true }
                        )
                    }
                }
            }

            if (sleepTimerDialog) {
                AlertDialog(
                    onDismissRequest = { sleepTimerDialog = false },
                    title = { Text("スリープタイマー") },
                    text = {
                        Column {
                            listOf(null, 15, 30, 60, 90).forEach { minutes ->
                                val label = if (minutes == null) "オフ" else "${minutes}分後"
                                Text(label, modifier = Modifier.fillMaxWidth().clickable { onSetSleepTimer(minutes); sleepTimerDialog = false }.padding(vertical = 12.dp), color = if (minutes == sleepTimerMinutes) LocalAccentColor.current else Color.Unspecified)
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { sleepTimerDialog = false }) { Text("閉じる") } }
                )
            }

            if (addToPlaylistDialog) {
                AlertDialog(
                    onDismissRequest = { addToPlaylistDialog = false },
                    title = { Text("プレイリストに追加") },
                    text = {
                        if (playlistNames.isEmpty()) {
                            Text("プレイリストがありません。先にプレイリストを作成してください。")
                        } else {
                            Column {
                                playlistNames.forEach { name ->
                                    TextButton(
                                        onClick = {
                                            onAddToPlaylist(name, song)
                                            addToPlaylistDialog = false
                                            android.widget.Toast.makeText(context, "「$name」に追加しました", android.widget.Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Default.PlaylistAdd, null)
                                        Spacer(Modifier.width(10.dp))
                                        Text(name, modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { addToPlaylistDialog = false }) { Text("閉じる") }
                    }
                )
            }

            if (detailDialog) {
                AlertDialog(
                    onDismissRequest = { detailDialog = false },
                    title = { Text("詳細情報") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("タイトル: ${song.title.ifBlank { "Unknown" }}")
                            Text("アーティスト: ${song.artist.ifBlank { "Unknown" }}")
                            Text("アルバム: ${song.album.ifBlank { "Unknown" }}")
                            Text("ジャンル: —")
                            Text("年: —")
                            Text("トラック: —")
                            Text("ディスク: —")
                            Text("URI: ${song.uriString}", fontSize = 11.sp)
                        }
                    },
                    confirmButton = { TextButton(onClick = { detailDialog = false }) { Text("閉じる") } }
                )
            }

            Spacer(Modifier.height(4.dp))

            BoxWithConstraints(
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 4.dp)
                    .pointerInput(song.uriString) {
                        var dragDistance = 0f
                        detectHorizontalDragGestures(
                            onHorizontalDrag = { change, dragAmount ->
                                change.consume()
                                dragDistance += dragAmount
                            },
                            onDragEnd = {
                                when {
                                    dragDistance <= -72f -> requestNextWithArtworkAnimation()
                                    dragDistance >= 72f -> requestPreviousWithArtworkAnimation()
                                }
                                dragDistance = 0f
                            },
                            onDragCancel = { dragDistance = 0f }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                // Large album art: ~94% of available width, capped by height so controls still fit
                val artSize = minOf(maxWidth * 0.94f, maxHeight * 0.98f)
                AnimatedContent(
                    targetState = song,
                    transitionSpec = {
                        val direction = artworkSlideDirection
                        (slideInHorizontally(
                            animationSpec = tween(320),
                            initialOffsetX = { width -> if (direction > 0) width + 280 else -width - 280 }
                        ) togetherWith slideOutHorizontally(
                            animationSpec = tween(320),
                            targetOffsetX = { width -> if (direction > 0) -width - 280 else width + 280 }
                        )).using(SizeTransform(clip = false))
                    },
                    label = "playerArtworkSlide"
                ) { displayedSong ->
                    AlbumArt(
                        song = displayedSong,
                        size = artSize,
                        modifier = Modifier
                            .graphicsLayer {
                                scaleX = artworkScale
                                scaleY = artworkScale
                            }
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) {
                                artworkTapScope.launch {
                                    artworkTapPulse = true
                                    delay(100L)
                                    artworkTapPulse = false
                                }
                            }
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                IconButton(
                    onClick = { addToPlaylistDialog = true },
                    enabled = playlistNames.isNotEmpty(),
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(
                        Icons.Default.Add,
                        "プレイリストに追加",
                        tint = if (playlistNames.isNotEmpty()) Color.White.copy(alpha = .9f) else Color.White.copy(alpha = .3f),
                        modifier = Modifier.size(27.dp)
                    )
                }
                Column(Modifier.weight(1f).padding(horizontal = 4.dp)) {
                    Text(
                        song.title.ifBlank { "Unknown title" },
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier
                            .fillMaxWidth()
                            .basicMarquee(
                                iterations = Int.MAX_VALUE,
                                animationMode = MarqueeAnimationMode.Immediately,
                                spacing = MarqueeSpacing(32.dp),
                                velocity = 36.dp
                            )
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        song.artist.ifBlank { "Unknown Artist" },
                        color = LocalAccentColor.current,
                        fontSize = 15.sp,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier
                            .fillMaxWidth()
                            .basicMarquee(
                                iterations = Int.MAX_VALUE,
                                animationMode = MarqueeAnimationMode.Immediately,
                                spacing = MarqueeSpacing(28.dp),
                                velocity = 32.dp
                            )
                    )
                    Text(
                        song.album.ifBlank { "Unknown Album" },
                        color = Color(0xFFB4BAC0),
                        fontSize = 13.sp,
                        maxLines = 1
                    )
                }
                IconButton(onToggleFavorite, modifier = Modifier.size(44.dp)) {
                    Icon(
                        if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        "Favorite",
                        tint = if (isFavorite) LocalAccentColor.current else Color.White.copy(alpha = .88f),
                        modifier = Modifier.size(27.dp)
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            Slider(
                value = sliderValue,
                onValueChange = { fraction ->
                    positionMs = (safeDuration * fraction).toLong().coerceIn(0L, safeDuration)
                },
                onValueChangeFinished = {
                    onSeekTo(positionMs.coerceIn(0L, safeDuration))
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(22.dp),
                interactionSource = seekInteractionSource,
                colors = seekColors,
                thumb = {},
                track = { sliderState ->
                    Canvas(Modifier.fillMaxWidth().height(22.dp)) {
                        val progress = sliderState.value.coerceIn(0f, 1f)
                        val centerY = size.height / 2f
                        val trackThickness = 4.dp.toPx()
                        drawLine(
                            color = Color.White.copy(alpha = .24f),
                            start = Offset(0f, centerY),
                            end = Offset(size.width, centerY),
                            strokeWidth = trackThickness,
                            cap = StrokeCap.Round
                        )
                        drawLine(
                            color = Color.White,
                            start = Offset(0f, centerY),
                            end = Offset(size.width * progress, centerY),
                            strokeWidth = trackThickness,
                            cap = StrokeCap.Round
                        )
                    }
                }
            )

            Row(Modifier.fillMaxWidth()) {
                Text(formatDuration(positionMs), color = Color(0xFFB0B6BC), fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Text("-${formatDuration(remainingMs)}", color = Color(0xFFB0B6BC), fontSize = 11.sp)
            }

            Spacer(Modifier.height(6.dp))

            Row(
                Modifier
                    .fillMaxWidth()
                    .height(76.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                IconButton(onToggleShuffle) {
                    Icon(
                        Icons.Default.Shuffle,
                        "Shuffle",
                        tint = if (shuffleEnabled) LocalAccentColor.current else Color.White.copy(alpha = .82f)
                    )
                }
                IconButton(::requestPreviousWithArtworkAnimation, modifier = Modifier.size(52.dp)) {
                    Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(31.dp))
                }
                FilledIconButton(
                    onClick = onPlay,
                    modifier = Modifier.size(72.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = LocalAccentColor.current,
                        contentColor = Color(0xFF111316)
                    )
                ) {
                    Icon(
                        if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                        "Play or pause",
                        modifier = Modifier.size(37.dp)
                    )
                }
                IconButton(::requestNextWithArtworkAnimation, modifier = Modifier.size(52.dp)) {
                    Icon(Icons.Default.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(31.dp))
                }
                IconButton(onCycleRepeat) {
                    Icon(
                        if (repeatMode == androidx.media3.common.Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        "Repeat $repeatLabel",
                        tint = if (repeatMode != androidx.media3.common.Player.REPEAT_MODE_OFF) LocalAccentColor.current else Color.White.copy(alpha = .82f)
                    )
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .height(26.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    buildString {
                        if (shuffleEnabled) append("SHUFFLE")
                        if (shuffleEnabled && repeatMode != androidx.media3.common.Player.REPEAT_MODE_OFF) append("  •  ")
                        if (repeatMode != androidx.media3.common.Player.REPEAT_MODE_OFF) append("REPEAT $repeatLabel")
                        if (isEmpty()) append("NOW PLAYING")
                    },
                    color = Color.White.copy(alpha = .48f),
                    fontSize = 10.sp,
                    letterSpacing = 1.0.sp
                )
            }

            Spacer(Modifier.height(4.dp))
        }
    }
}

@Composable
private fun EditMusicInfoScreen(
    song: MusicSong,
    onBack: () -> Unit,
    onSave: (MusicSong) -> Unit,
    onArtistImageSaved: () -> Unit
) {
    var title by remember(song.uriString) { mutableStateOf(song.title) }
    var artist by remember(song.uriString) { mutableStateOf(song.artist) }
    var album by remember(song.uriString) { mutableStateOf(song.album) }
    var disc by remember(song.uriString) { mutableStateOf("1") }
    var track by remember(song.uriString) { mutableStateOf("") }
    var year by remember(song.uriString) { mutableStateOf("") }
    var genre by remember(song.uriString) { mutableStateOf("") }
    var artworkSet by remember(song.uriString) { mutableStateOf(false) }
    var selectedImageUri by remember(song.uriString) { mutableStateOf<Uri?>(null) }
    var cropScreen by remember(song.uriString) { mutableStateOf(false) }
    var imageTarget by remember(song.uriString) { mutableStateOf("artwork") }
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("pixelmusic_artwork", android.content.Context.MODE_PRIVATE) }
    var customArtworkPath by remember(song.uriString) { mutableStateOf(prefs.getString("art_${song.id}", null)) }
    var customArtistImagePath by remember(song.uriString) { mutableStateOf(prefs.getString("artist_art_${song.artist.hashCode()}", null)) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedImageUri = uri
            cropScreen = true
        }
    }

    if (cropScreen && selectedImageUri != null) {
        CropArtworkScreen(
            uri = selectedImageUri!!,
            onBack = { cropScreen = false },
            onDone = { cropped ->
                if (imageTarget == "artist") {
                    customArtistImagePath = cropped
                    prefs.edit().putString("artist_art_${song.artist.hashCode()}", cropped).apply()
                    onArtistImageSaved()
                } else {
                    customArtworkPath = cropped
                    prefs.edit().putString("art_${song.id}", cropped).apply()
                    artworkSet = true
                }
                cropScreen = false
            }
        )
        return
    }

    Box(
        Modifier.fillMaxSize().background(Color(0xFF08090B))
    ) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(
                Modifier.fillMaxWidth().height(64.dp).background(Color(0xFF0A0B0D)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onBack) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
                }
                Text("ミュージック情報を編集", color = Color.White, fontSize = 19.sp)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = {
                    onSave(song.copy(title = title, artist = artist, album = album))
                }) {
                    Text("保存", color = LocalAccentColor.current)
                }
            }

            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                item {
                    // Artist image region (blue in the Xperia reference). Tapping it opens image selection and framing.
                    Box(
                        Modifier.fillMaxWidth().height(168.dp)
                            .background(Color(0xFF3478D4))
                            .clickable { imageTarget = "artist"; imagePicker.launch("image/*") },
                        contentAlignment = Alignment.BottomEnd
                    ) {
                        customArtistImagePath?.let { path ->
                            val artistBitmap = remember(path) { runCatching { android.graphics.BitmapFactory.decodeFile(path)?.asImageBitmap() }.getOrNull() }
                            if (artistBitmap != null) Image(artistBitmap, contentDescription = "アーティスト画像", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        }
                        Icon(Icons.Default.Edit, "アーティスト画像を編集", tint = Color.White, modifier = Modifier.padding(12.dp).background(Color(0x99000000), CircleShape).padding(8.dp))
                    }
                    Text("アーティスト画像を編集", color = Color(0xFFB9C0C8), fontSize = 12.sp, modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 16.dp))
                }
                item {
                    // Artwork region (orange in the reference). Tap the artwork itself to edit it.
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(96.dp).clickable { imageTarget = "artwork"; imagePicker.launch("image/*") }) {
                            val artworkBitmap = remember(customArtworkPath) { customArtworkPath?.let { runCatching { android.graphics.BitmapFactory.decodeFile(it)?.asImageBitmap() }.getOrNull() } }
                            if (artworkBitmap != null) Image(artworkBitmap, contentDescription = "アートワーク", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            else AlbumArt(song = song, size = 96.dp)
                            Icon(Icons.Default.Edit, "アートワークを編集", tint = Color.White, modifier = Modifier.align(Alignment.BottomEnd).background(Color(0xCC000000), CircleShape).padding(5.dp))
                        }
                        Column(Modifier.padding(start = 14.dp).weight(1f)) {
                            Text(song.title, color = Color.White, fontSize = 16.sp, maxLines = 1)
                            Text(song.artist.ifBlank { "不明なアーティスト" }, color = Color(0xFFB7BDC4), fontSize = 13.sp)
                            Text(song.album.ifBlank { "Music" }, color = Color(0xFFB7BDC4), fontSize = 13.sp)
                            Text("アートワーク画像を編集", color = Color(0xFFB7BDC4), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { prefs.edit().remove("art_${song.id}").apply(); customArtworkPath = null; artworkSet = false }) { Text("画像を削除") }
                    }
                    Divider(color = Color(0xFF33383E), modifier = Modifier.padding(vertical = 12.dp))
                }
                item { EditField("タイトル", title) { title = it } }
                item { EditField("アーティスト", artist) { artist = it } }
                item { EditField("アルバム", album) { album = it } }
                item { EditField("ディスク", disc) { disc = it } }
                item { EditField("トラック", track) { track = it } }
                item { EditField("年", year) { year = it } }
                item { EditField("ジャンル", genre) { genre = it } }
            }
        }
    }
}


@Composable
private fun CropArtworkScreen(
    uri: Uri,
    onBack: () -> Unit,
    onDone: (String) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(uri) { mutableStateOf<android.graphics.Bitmap?>(null) }
    var aspect by remember(uri) { mutableStateOf("正方形") }

    // Crop window as normalized rect inside the *displayed image* (0..1)
    var cropLeft by remember { mutableFloatStateOf(0.15f) }
    var cropTop by remember { mutableFloatStateOf(0.15f) }
    var cropRight by remember { mutableFloatStateOf(0.85f) }
    var cropBottom by remember { mutableFloatStateOf(0.85f) }

    // Layout of the fitted image inside the preview box
    var containerW by remember { mutableFloatStateOf(0f) }
    var containerH by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(uri) {
        bitmap = withContext(Dispatchers.IO) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }.getOrNull()
        }
    }

    val srcRatio = bitmap?.let { b ->
        if (b.height > 0) b.width.toFloat() / b.height.toFloat() else 1f
    } ?: 1f

    val targetRatio = when (aspect) {
        "16:9" -> 16f / 9f
        "オリジナル" -> srcRatio
        else -> 1f // 正方形
    }

    // Fit image rect inside container (ContentScale.Fit style)
    fun imageLayout(): androidx.compose.ui.geometry.Rect {
        val cw = containerW.coerceAtLeast(1f)
        val ch = containerH.coerceAtLeast(1f)
        val containerRatio = cw / ch
        return if (srcRatio > containerRatio) {
            val h = cw / srcRatio
            val top = (ch - h) / 2f
            androidx.compose.ui.geometry.Rect(0f, top, cw, top + h)
        } else {
            val w = ch * srcRatio
            val left = (cw - w) / 2f
            androidx.compose.ui.geometry.Rect(left, 0f, left + w, ch)
        }
    }

    fun applyAspectCentered(ratio: Float) {
        // Place a crop of given aspect centered, covering ~70% of the shorter side
        val img = imageLayout()
        if (img.width <= 0f || img.height <= 0f) return
        val imgRatio = img.width / img.height
        var cropW: Float
        var cropH: Float
        if (imgRatio > ratio) {
            cropH = img.height * 0.72f
            cropW = cropH * ratio
            if (cropW > img.width * 0.95f) {
                val s = (img.width * 0.95f) / cropW
                cropW *= s
                cropH *= s
            }
        } else {
            cropW = img.width * 0.72f
            cropH = cropW / ratio
            if (cropH > img.height * 0.95f) {
                val s = (img.height * 0.95f) / cropH
                cropW *= s
                cropH *= s
            }
        }
        val cx = 0.5f
        val cy = 0.5f
        val nw = cropW / img.width
        val nh = cropH / img.height
        cropLeft = (cx - nw / 2f).coerceIn(0f, 1f - nw)
        cropTop = (cy - nh / 2f).coerceIn(0f, 1f - nh)
        cropRight = cropLeft + nw
        cropBottom = cropTop + nh
    }

    LaunchedEffect(aspect, bitmap, containerW, containerH) {
        if (bitmap != null && containerW > 0f && containerH > 0f) {
            applyAspectCentered(targetRatio)
        }
    }

    fun clampCrop() {
        var l = cropLeft.coerceIn(0f, 0.98f)
        var t = cropTop.coerceIn(0f, 0.98f)
        var r = cropRight.coerceIn(0.02f, 1f)
        var b = cropBottom.coerceIn(0.02f, 1f)
        if (r - l < 0.08f) r = (l + 0.08f).coerceAtMost(1f)
        if (b - t < 0.08f) b = (t + 0.08f).coerceAtMost(1f)
        cropLeft = l
        cropTop = t
        cropRight = r
        cropBottom = b
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF2A2C30))) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(
                Modifier.fillMaxWidth().height(56.dp).background(Color(0xFF1C1E22)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
                Text("トリミング", color = Color.White, fontSize = 18.sp)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = {
                    val source = bitmap ?: return@TextButton
                    val img = imageLayout()
                    if (img.width <= 0f || img.height <= 0f) return@TextButton
                    // Map normalized crop → bitmap pixels
                    val left = (cropLeft * source.width).toInt().coerceIn(0, source.width - 1)
                    val top = (cropTop * source.height).toInt().coerceIn(0, source.height - 1)
                    val right = (cropRight * source.width).toInt().coerceIn(left + 1, source.width)
                    val bottom = (cropBottom * source.height).toInt().coerceIn(top + 1, source.height)
                    val w = (right - left).coerceAtLeast(1)
                    val h = (bottom - top).coerceAtLeast(1)
                    val cropped = Bitmap.createBitmap(source, left, top, w, h)
                    val file = File(
                        context.filesDir,
                        "art_${uri.toString().hashCode().absoluteValue}_${System.currentTimeMillis()}.jpg"
                    )
                    file.outputStream().use { out -> cropped.compress(Bitmap.CompressFormat.JPEG, 94, out) }
                    onDone(file.absolutePath)
                }) { Text("保存", color = LocalAccentColor.current) }
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("正方形", "16:9", "オリジナル").forEach { option ->
                    val selected = aspect == option
                    Text(
                        option,
                        color = if (selected) Color.Black else Color.White,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (selected) LocalAccentColor.current else Color(0xFF3A3E44))
                            .clickable { aspect = option }
                            .padding(vertical = 10.dp),
                        textAlign = TextAlign.Center,
                        fontSize = 13.sp
                    )
                }
            }

            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(8.dp)
                    .onSizeChanged {
                        containerW = it.width.toFloat()
                        containerH = it.height.toFloat()
                    },
                contentAlignment = Alignment.Center
            ) {
                val bmp = bitmap
                if (bmp == null) {
                    Text("画像を読み込み中…", color = Color(0xFF858C93))
                } else {
                    val img = imageLayout()
                    // Full original image (fitted)
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier
                            .fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )

                    // Dim outside crop + white frame + grid + drag
                    Canvas(Modifier.fillMaxSize()) {
                        val l = img.left + cropLeft * img.width
                        val t = img.top + cropTop * img.height
                        val r = img.left + cropRight * img.width
                        val b = img.top + cropBottom * img.height

                        // Dim overlay outside crop
                        val dim = Color.Black.copy(alpha = 0.55f)
                        drawRect(dim, topLeft = Offset(0f, 0f), size = androidx.compose.ui.geometry.Size(size.width, t.coerceAtLeast(0f)))
                        drawRect(dim, topLeft = Offset(0f, b), size = androidx.compose.ui.geometry.Size(size.width, (size.height - b).coerceAtLeast(0f)))
                        drawRect(dim, topLeft = Offset(0f, t), size = androidx.compose.ui.geometry.Size(l.coerceAtLeast(0f), (b - t).coerceAtLeast(0f)))
                        drawRect(dim, topLeft = Offset(r, t), size = androidx.compose.ui.geometry.Size((size.width - r).coerceAtLeast(0f), (b - t).coerceAtLeast(0f)))

                        val stroke = Color.White.copy(alpha = 0.95f)
                        val strokeW = 2.dp.toPx()
                        // Outer frame
                        drawRect(
                            color = stroke,
                            topLeft = Offset(l, t),
                            size = androidx.compose.ui.geometry.Size(r - l, b - t),
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeW)
                        )
                        // Rule-of-thirds grid
                        val gw = (r - l) / 3f
                        val gh = (b - t) / 3f
                        val gridStroke = Color.White.copy(alpha = 0.55f)
                        val gwStroke = 1.dp.toPx()
                        for (i in 1..2) {
                            drawLine(gridStroke, Offset(l + gw * i, t), Offset(l + gw * i, b), strokeWidth = gwStroke)
                            drawLine(gridStroke, Offset(l, t + gh * i), Offset(r, t + gh * i), strokeWidth = gwStroke)
                        }
                        // Corner handles
                        val hs = 18.dp.toPx()
                        val hw = 3.dp.toPx()
                        fun corner(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float) {
                            drawLine(stroke, Offset(x1, y1), Offset(x2, y2), strokeWidth = hw, cap = StrokeCap.Square)
                            drawLine(stroke, Offset(x1, y1), Offset(x3, y3), strokeWidth = hw, cap = StrokeCap.Square)
                        }
                        corner(l, t, l + hs, t, l, t + hs)
                        corner(r, t, r - hs, t, r, t + hs)
                        corner(l, b, l + hs, b, l, b - hs)
                        corner(r, b, r - hs, b, r, b - hs)
                        // Edge mid handles
                        val mid = 14.dp.toPx()
                        drawLine(stroke, Offset((l + r) / 2f - mid, t), Offset((l + r) / 2f + mid, t), strokeWidth = hw)
                        drawLine(stroke, Offset((l + r) / 2f - mid, b), Offset((l + r) / 2f + mid, b), strokeWidth = hw)
                        drawLine(stroke, Offset(l, (t + b) / 2f - mid), Offset(l, (t + b) / 2f + mid), strokeWidth = hw)
                        drawLine(stroke, Offset(r, (t + b) / 2f - mid), Offset(r, (t + b) / 2f + mid), strokeWidth = hw)
                    }

                    // Gesture layer: move / resize crop frame
                    Box(
                        Modifier
                            .fillMaxSize()
                            .pointerInput(aspect, containerW, containerH, srcRatio) {
                                awaitPointerEventScope {
                                    while (true) {
                                        val down = awaitFirstDown(requireUnconsumed = false)
                                        val imgRect = imageLayout()
                                        if (imgRect.width <= 0f || imgRect.height <= 0f) continue

                                        fun toNorm(x: Float, y: Float): Pair<Float, Float> {
                                            val nx = ((x - imgRect.left) / imgRect.width).coerceIn(0f, 1f)
                                            val ny = ((y - imgRect.top) / imgRect.height).coerceIn(0f, 1f)
                                            return nx to ny
                                        }

                                        val (nx, ny) = toNorm(down.position.x, down.position.y)
                                        val handlePx = 28.dp.toPx()
                                        val handleN = handlePx / imgRect.width
                                        val handleNy = handlePx / imgRect.height

                                        // Which handle? corners / edges / inside = move
                                        val nearL = kotlin.math.abs(nx - cropLeft) < handleN
                                        val nearR = kotlin.math.abs(nx - cropRight) < handleN
                                        val nearT = kotlin.math.abs(ny - cropTop) < handleNy
                                        val nearB = kotlin.math.abs(ny - cropBottom) < handleNy
                                        val inside = nx in cropLeft..cropRight && ny in cropTop..cropBottom

                                        val mode = when {
                                            nearL && nearT -> "tl"
                                            nearR && nearT -> "tr"
                                            nearL && nearB -> "bl"
                                            nearR && nearB -> "br"
                                            nearT && nx in cropLeft..cropRight -> "t"
                                            nearB && nx in cropLeft..cropRight -> "b"
                                            nearL && ny in cropTop..cropBottom -> "l"
                                            nearR && ny in cropTop..cropBottom -> "r"
                                            inside -> "move"
                                            else -> "move"
                                        }

                                        val startL = cropLeft
                                        val startT = cropTop
                                        val startR = cropRight
                                        val startB = cropBottom
                                        val startNx = nx
                                        val startNy = ny
                                        val ratio = targetRatio

                                        var event = awaitPointerEvent()
                                        while (event.changes.any { it.pressed }) {
                                            val pos = event.changes.first().position
                                            event.changes.forEach { it.consume() }
                                            val (cx, cy) = toNorm(pos.x, pos.y)
                                            val dx = cx - startNx
                                            val dy = cy - startNy

                                            when (mode) {
                                                "move" -> {
                                                    var w = startR - startL
                                                    var h = startB - startT
                                                    var nl = (startL + dx).coerceIn(0f, 1f - w)
                                                    var nt = (startT + dy).coerceIn(0f, 1f - h)
                                                    cropLeft = nl
                                                    cropTop = nt
                                                    cropRight = nl + w
                                                    cropBottom = nt + h
                                                }
                                                else -> {
                                                    var l = startL
                                                    var t = startT
                                                    var r = startR
                                                    var b = startB
                                                    when (mode) {
                                                        "tl" -> { l = startL + dx; t = startT + dy }
                                                        "tr" -> { r = startR + dx; t = startT + dy }
                                                        "bl" -> { l = startL + dx; b = startB + dy }
                                                        "br" -> { r = startR + dx; b = startB + dy }
                                                        "t" -> t = startT + dy
                                                        "b" -> b = startB + dy
                                                        "l" -> l = startL + dx
                                                        "r" -> r = startR + dx
                                                    }
                                                    // min size
                                                    val minN = 0.08f
                                                    if (r - l < minN) {
                                                        if (mode.contains("l") || mode == "l") l = r - minN else r = l + minN
                                                    }
                                                    if (b - t < minN) {
                                                        if (mode.contains("t") || mode == "t") t = b - minN else b = t + minN
                                                    }
                                                    // lock aspect
                                                    var w = (r - l).coerceAtLeast(minN)
                                                    var h = (b - t).coerceAtLeast(minN)
                                                    val imgAspect = 1f // normalized space is image space; aspect is in pixel space
                                                    // In normalized image coords, width/height already match bitmap aspect.
                                                    // Desired: (w * srcW) / (h * srcH) = ratio → w/h = ratio / srcRatio * (but wait)
                                                    // pixelW/pixelH = (w*srcW)/(h*srcH) = ratio
                                                    // w/h = ratio * srcH / srcW = ratio / srcRatio
                                                    val normRatio = ratio / srcRatio.coerceAtLeast(0.01f)

                                                    when (mode) {
                                                        "tl", "tr", "bl", "br" -> {
                                                            // Drive by the dominant drag axis
                                                            if (kotlin.math.abs(dx) * imgRect.width > kotlin.math.abs(dy) * imgRect.height) {
                                                                h = w / normRatio
                                                            } else {
                                                                w = h * normRatio
                                                            }
                                                            when (mode) {
                                                                "tl" -> { l = r - w; t = b - h }
                                                                "tr" -> { r = l + w; t = b - h }
                                                                "bl" -> { l = r - w; b = t + h }
                                                                "br" -> { r = l + w; b = t + h }
                                                            }
                                                        }
                                                        "l", "r" -> {
                                                            h = w / normRatio
                                                            val cy0 = (startT + startB) / 2f
                                                            t = cy0 - h / 2f
                                                            b = cy0 + h / 2f
                                                            if (mode == "l") l = r - w else r = l + w
                                                        }
                                                        "t", "b" -> {
                                                            w = h * normRatio
                                                            val cx0 = (startL + startR) / 2f
                                                            l = cx0 - w / 2f
                                                            r = cx0 + w / 2f
                                                            if (mode == "t") t = b - h else b = t + h
                                                        }
                                                    }
                                                    // clamp inside image
                                                    if (l < 0f) { r -= l; l = 0f }
                                                    if (t < 0f) { b -= t; t = 0f }
                                                    if (r > 1f) { l -= (r - 1f); r = 1f }
                                                    if (b > 1f) { t -= (b - 1f); b = 1f }
                                                    l = l.coerceIn(0f, 1f)
                                                    t = t.coerceIn(0f, 1f)
                                                    r = r.coerceIn(0f, 1f)
                                                    b = b.coerceIn(0f, 1f)
                                                    if (r - l >= minN && b - t >= minN) {
                                                        cropLeft = l
                                                        cropTop = t
                                                        cropRight = r
                                                        cropBottom = b
                                                    }
                                                }
                                            }
                                            event = awaitPointerEvent()
                                        }
                                    }
                                }
                            }
                    )
                }
            }

            Text(
                "枠をドラッグで移動、角・辺でサイズ変更",
                color = Color(0xFFB0B4B8),
                fontSize = 12.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun EditField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedBorderColor = LocalAccentColor.current,
            unfocusedBorderColor = Color(0xFF4B5157),
            focusedLabelColor = LocalAccentColor.current,
            unfocusedLabelColor = Color(0xFF858C93),
            cursorColor = LocalAccentColor.current
        )
    )
}

private fun formatDuration(milliseconds: Long): String {
    val totalSeconds = (milliseconds / 1000L).coerceAtLeast(0L)
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return "%d:%02d".format(minutes, seconds)
}
