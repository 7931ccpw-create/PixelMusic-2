package com.example.pixelmusic.ui

import com.example.pixelmusic.MusicSong
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PixelMusicApp(
    songs: List<MusicSong>,
    currentIndex: Int,
    playing: Boolean,
    onSongClick: (Int) -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit
) {
    var drawer by remember { mutableStateOf(false) }
    var fullPlayer by remember { mutableStateOf(false) }
    val current = songs.getOrNull(currentIndex)

    Box(Modifier.fillMaxSize().background(Color(0xFF08090B))) {
        Column(Modifier.fillMaxSize()) {
            TopBar { drawer = true }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 80.dp)) {
                item {
                    Text(
                        "Songs",
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Light,
                        modifier = Modifier.padding(22.dp)
                    )
                }
                if (songs.isEmpty()) {
                    item {
                        Text(
                            "音楽ファイルが見つかりません",
                            color = Color(0xFF9AA0A6),
                            modifier = Modifier.padding(horizontal = 22.dp)
                        )
                    }
                } else {
                    itemsIndexed(songs) { index, song ->
                        SongRow(song, index == currentIndex) { onSongClick(index) }
                    }
                }
            }
            if (current != null) {
                MiniPlayer(current, playing, onPlayPause, { fullPlayer = true }, onNext)
            }
        }

        if (drawer) NavigationDrawer({ drawer = false }) { drawer = false }
        if (fullPlayer && current != null) {
            FullPlayer(current, playing, { fullPlayer = false }, onPlayPause, onPrevious, onNext)
        }
    }
}

@Composable private fun TopBar(onMenu: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(64.dp).background(Color(0xFF0A0B0D)), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onMenu) { Icon(Icons.Default.Menu, null, tint = Color.White) }
        Text("Pixel Music", color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.weight(1f))
        IconButton({}) { Icon(Icons.Default.Search, null, tint = Color.White) }
        IconButton({}) { Icon(Icons.Default.MoreVert, null, tint = Color.White) }
    }
}

@Composable private fun SongRow(song: MusicSong, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(18.dp, 10.dp), verticalAlignment = Alignment.CenterVertically) {
        AlbumArt(56.dp)
        Column(Modifier.weight(1f).padding(start = 16.dp)) {
            Text(song.title, color = Color.White, maxLines = 1)
            Text("${song.artist} • ${song.album}", color = Color(0xFF9AA0A6), fontSize = 13.sp, maxLines = 1)
        }
        Icon(if (selected && song.title.isNotBlank()) Icons.Default.GraphicEq else Icons.Default.MoreVert, null, tint = if (selected) Color(0xFF4DA3FF) else Color(0xFF777B80))
    }
}

@Composable private fun AlbumArt(size: Dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(4.dp)).background(Brush.linearGradient(listOf(Color(0xFF26384A), Color(0xFF11151A), Color(0xFF4C2020)))), contentAlignment = Alignment.Center) {
        Icon(Icons.Default.MusicNote, null, tint = Color.White.copy(alpha = .8f))
    }
}

@Composable private fun MiniPlayer(song: MusicSong, playing: Boolean, onPlay: () -> Unit, onOpen: () -> Unit, onNext: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(72.dp).background(Color(0xFF15181C)).clickable(onClick = onOpen).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        AlbumArt(48.dp)
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(song.title, color = Color.White, maxLines = 1)
            Text(song.artist, color = Color(0xFF9AA0A6), fontSize = 12.sp, maxLines = 1)
        }
        IconButton(onPlay) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White) }
        IconButton(onNext) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
    }
}

@Composable private fun NavigationDrawer(onClose: () -> Unit, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxSize()) {
        Column(Modifier.width(300.dp).fillMaxHeight().background(Color(0xFF121417)).padding(top = 32.dp)) {
            Text("PIXEL MUSIC", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Light, modifier = Modifier.padding(24.dp))
            listOf("Home", "Play Queue", "Playlists", "Artists", "Albums", "Songs", "Genres", "Folders", "Google Drive", "New Releases", "Charts", "Settings").forEach {
                Text(it, color = if (it == "Songs") Color(0xFF4DA3FF) else Color(0xFFE2E5E8), fontSize = 15.sp, modifier = Modifier.fillMaxWidth().clickable { onSelect(it) }.padding(horizontal = 24.dp, vertical = 13.dp))
            }
        }
        Spacer(Modifier.fillMaxSize().weight(1f).background(Color.Black.copy(alpha = .55f)).clickable(onClick = onClose))
    }
}

@Composable private fun FullPlayer(song: MusicSong, playing: Boolean, onBack: () -> Unit, onPlay: () -> Unit, onPrevious: () -> Unit, onNext: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF27323C), Color(0xFF08090B), Color(0xFF08090B)))) ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 22.dp)) {
            Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onBack) { Icon(Icons.Default.KeyboardArrowDown, null, tint = Color.White) }
                Spacer(Modifier.weight(1f))
                IconButton({}) { Icon(Icons.Default.MoreVert, null, tint = Color.White) }
            }
            Spacer(Modifier.weight(1f))
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { AlbumArt(290.dp) }
            Spacer(Modifier.height(28.dp))
            Text(song.title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Light, maxLines = 1)
            Text(song.artist, color = Color(0xFFB4B9BE), fontSize = 15.sp, maxLines = 1)
            Text(song.album, color = Color(0xFF80868C), fontSize = 13.sp, maxLines = 1)
            Spacer(Modifier.height(20.dp))
            Slider(value = if (playing) .1f else 0f, onValueChange = {}, colors = SliderDefaults.colors(thumbColor = Color(0xFF4DA3FF), activeTrackColor = Color(0xFF4DA3FF), inactiveTrackColor = Color(0xFF50555B)))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                IconButton({}) { Icon(Icons.Default.Shuffle, null, tint = Color.White) }
                IconButton(onPrevious) { Icon(Icons.Default.SkipPrevious, null, tint = Color.White) }
                FilledIconButton(onClick = onPlay, modifier = Modifier.size(68.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color(0xFFE7EAED))) {
                    Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.Black, modifier = Modifier.size(34.dp))
                }
                IconButton(onNext) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
                IconButton({}) { Icon(Icons.Default.Repeat, null, tint = Color.White) }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}
