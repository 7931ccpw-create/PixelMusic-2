package com.example.pixelmusic

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.pixelmusic.ui.PixelMusicApp

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    private lateinit var playbackService: PlaybackService
    private val songs = mutableListOf<MusicSong>()
    private val queue = mutableListOf<Int>()
    private var permissionGranted = false
    private var bound = false

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionGranted = granted
        if (granted && bound) loadMusic()
        if (granted && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        render()
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {
        // Notification permission is optional for playback; the media service can still play.
        render()
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as? PlaybackService.LocalBinder ?: return
            playbackService = binder.getService()
            player = playbackService.player
            bound = true
            player.addListener(playerListener)
            if (permissionGranted) loadMusic()
            render()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            bound = false
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) = render()
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = render()
        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) = render()
        override fun onRepeatModeChanged(repeatMode: Int) = render()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        permissionGranted = hasAudioPermission()

        bindService(
            Intent(this, PlaybackService::class.java),
            serviceConnection,
            BIND_AUTO_CREATE
        )

        if (!permissionGranted) {
            requestAudioPermission()
        } else if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun hasAudioPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        audioPermissionLauncher.launch(permission)
    }

    private fun startPlaybackServiceIfNeeded() {
        ContextCompat.startForegroundService(
            this,
            Intent(this, PlaybackService::class.java)
        )
    }

    private fun mediaItem(song: MusicSong): MediaItem = MediaItem.Builder()
        .setUri(song.uriString)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(song.title)
                .setArtist(song.artist)
                .setAlbumTitle(song.album)
                .setArtworkUri(song.artworkUriString?.let(android.net.Uri::parse))
                .build()
        )
        .build()

    private fun loadMusic() {
        if (!bound) return
        songs.clear()
        val baseSongs = MusicRepository.querySongs(contentResolver)
        val metaPrefs = getSharedPreferences("pixelmusic_metadata", MODE_PRIVATE)
        songs += baseSongs.map { song ->
            song.copy(
                title = metaPrefs.getString("${song.id}_title", song.title) ?: song.title,
                artist = metaPrefs.getString("${song.id}_artist", song.artist) ?: song.artist,
                album = metaPrefs.getString("${song.id}_album", song.album) ?: song.album
            )
        }
        if (songs.isNotEmpty() && player.mediaItemCount == 0) {
            queue.clear()
            queue.addAll(songs.indices)
            player.setMediaItems(queue.map { mediaItem(songs[it]) })
            player.prepare()
        }
    }

    private fun render() {
        if (!bound || !::player.isInitialized) return
        val queueIndex = player.currentMediaItemIndex.coerceIn(0, (queue.size - 1).coerceAtLeast(0))
        val index = if (queue.isNotEmpty() && queueIndex in queue.indices) queue[queueIndex] else -1
        setContent {
            PixelMusicApp(
                songs = songs.toList(),
                currentIndex = if (songs.isEmpty()) -1 else index,
                playing = player.isPlaying,
                onSongClick = { i ->
                    if (i in songs.indices) {
                        val queuePosition = queue.indexOf(i)
                        if (queuePosition >= 0) player.seekToDefaultPosition(queuePosition)
                        else {
                            queue.add(i)
                            player.addMediaItem(mediaItem(songs[i]))
                            player.seekToDefaultPosition(queue.lastIndex)
                        }
                        startPlaybackServiceIfNeeded()
                        player.play()
                        render()
                    }
                },
                onPlayPause = {
                    if (player.isPlaying) {
                        player.pause()
                    } else if (player.mediaItemCount > 0) {
                        startPlaybackServiceIfNeeded()
                        player.play()
                    }
                    render()
                },
                onNext = { if (player.mediaItemCount > 0) { startPlaybackServiceIfNeeded(); player.seekToNextMediaItem(); player.play() }; render() },
                onPrevious = { if (player.mediaItemCount > 0) { startPlaybackServiceIfNeeded(); player.seekToPreviousMediaItem(); player.play() }; render() },
                positionProvider = { player.currentPosition },
                durationProvider = { player.duration.takeIf { it != androidx.media3.common.C.TIME_UNSET } ?: 0L },
                onSeekTo = { position -> player.seekTo(position) },
                shuffleEnabled = player.shuffleModeEnabled,
                repeatMode = player.repeatMode,
                onToggleShuffle = {
                    player.shuffleModeEnabled = !player.shuffleModeEnabled
                    render()
                },
                onCycleRepeat = {
                    player.repeatMode = when (player.repeatMode) {
                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                        else -> Player.REPEAT_MODE_OFF
                    }
                    render()
                },
                queueSongIndices = queue.toList(),
                onQueueRemove = { queuePosition ->
                    if (queuePosition in queue.indices) {
                        player.removeMediaItem(queuePosition)
                        queue.removeAt(queuePosition)
                        render()
                    }
                },
                onQueueMove = { from, to ->
                    if (from in queue.indices && to in queue.indices && from != to) {
                        player.moveMediaItem(from, to)
                        val moved = queue.removeAt(from)
                        queue.add(to, moved)
                        render()
                    }
                },
                onQueueClear = {
                    player.clearMediaItems()
                    queue.clear()
                    render()
                },
                onQueueAdd = { songIndex ->
                    if (songIndex in songs.indices) {
                        queue.add(songIndex)
                        player.addMediaItem(mediaItem(songs[songIndex]))
                        if (player.playbackState == Player.STATE_IDLE) player.prepare()
                        render()
                    }
                },
                onUpdateSong = { updated ->
                    val index = songs.indexOfFirst { it.id == updated.id }
                    if (index >= 0) songs[index] = updated
                    getSharedPreferences("pixelmusic_metadata", MODE_PRIVATE).edit()
                        .putString("${updated.id}_title", updated.title)
                        .putString("${updated.id}_artist", updated.artist)
                        .putString("${updated.id}_album", updated.album)
                        .apply()
                    render()
                }
            )
        }
    }

    override fun onDestroy() {
        if (bound) {
            player.removeListener(playerListener)
            unbindService(serviceConnection)
            bound = false
        }
        super.onDestroy()
    }
}
