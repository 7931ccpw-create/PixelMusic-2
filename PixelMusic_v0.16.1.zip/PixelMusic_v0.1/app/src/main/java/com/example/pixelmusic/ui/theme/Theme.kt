package com.example.pixelmusic.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

enum class AppTheme(val label: String, val description: String, val accent: Color) {
    Black("Black", "深いブラック", Color(0xFFB8BDC3)),
    Blue("Blue", "クラシックブルー", Color(0xFF4DA3FF)),
    Red("Red", "アクセントレッド", Color(0xFFFF5A64)),
    Purple("Purple", "ディープパープル", Color(0xFFB68CFF)),
    Green("Green", "ナチュラルグリーン", Color(0xFF63D391)),
    Orange("Orange", "ウォームオレンジ", Color(0xFFFFA64D)),
    Cyan("Cyan", "クールシアン", Color(0xFF55D6E8)),
    Silver("Silver", "シルバーグレー", Color(0xFFD0D5DA))
}

val LocalAccentColor = staticCompositionLocalOf { Color(0xFF4DA3FF) }

@Composable
fun PixelMusicTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF4DA3FF),
            background = Color(0xFF08090B),
            surface = Color(0xFF121417),
            onSurface = Color(0xFFF3F4F5),
            onSurfaceVariant = Color(0xFF9AA0A6)
        ),
        content = content
    )
}
