package com.example.pixelmusic

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink

/**
 * Single shared ExoPlayer used by [MainActivity] and [PlaybackService]
 * so playback continues when the UI is in the background.
 */
@OptIn(UnstableApi::class)
object PlayerHolder {
    @Volatile
    private var player: ExoPlayer? = null

    /** Shared crossfeed processor; toggle/strength controlled from MainActivity. */
    val crossfeedProcessor = CrossfeedAudioProcessor()

    fun getOrCreate(context: Context): ExoPlayer {
        player?.let { return it }
        synchronized(this) {
            player?.let { return it }
            val appContext = context.applicationContext
            val renderersFactory = object : DefaultRenderersFactory(appContext) {
                override fun buildAudioSink(
                    context: Context,
                    enableFloatOutput: Boolean,
                    enableAudioTrackPlaybackParams: Boolean
                ): AudioSink {
                    return DefaultAudioSink.Builder(context)
                        .setEnableFloatOutput(enableFloatOutput)
                        .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                        .setAudioProcessors(arrayOf(crossfeedProcessor))
                        .build()
                }
            }
            val created = ExoPlayer.Builder(appContext, renderersFactory)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                        .build(),
                    /* handleAudioFocus = */ true
                )
                .setHandleAudioBecomingNoisy(true)
                .setWakeMode(C.WAKE_MODE_LOCAL)
                .build()
            created.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true
            )
            player = created
            return created
        }
    }

    fun get(): ExoPlayer? = player

    fun release() {
        synchronized(this) {
            player?.release()
            player = null
        }
    }
}
