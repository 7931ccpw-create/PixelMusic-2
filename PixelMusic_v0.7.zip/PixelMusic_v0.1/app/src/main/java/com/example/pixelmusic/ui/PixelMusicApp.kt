package com.example.pixelmusic.ui

import com.example.pixelmusic.MusicSong
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PixelMusicApp(
    songs: List<MusicSong>,
    currentIndex: Int,
    playing: Boolean,
    onSongClick: (Int) -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long,
    onSeekTo: (Long) -> Unit
) {
    var drawer by remember { mutableStateOf(false) }
    var fullPlayer by remember { mutableStateOf(false) }
    val current = songs.getOrNull(currentIndex)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .background(Color(0xFF08090B))
    ) {
        Column(Modifier.fillMaxSize()) {
            TopBar { drawer = true }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 80.dp)) {
                item {
                    Text(
                        "Songs",
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Light,
                        modifier = Modifier.padding(22.dp)
                    )
                }
                if (songs.isEmpty()) {
                    item {
                        Text(
                            "音楽ファイルが見つかりません",
                            color = Color(0xFF9AA0A6),
                            modifier = Modifier.padding(horizontal = 22.dp)
                        )
                    }
                } else {
                    itemsIndexed(songs) { index, song ->
                        SongRow(song, index == currentIndex) { onSongClick(index) }
                    }
                }
            }
            if (current != null) {
                MiniPlayer(current, playing, onPlayPause, { fullPlayer = true }, onNext)
            }
        }

        if (drawer) NavigationDrawer({ drawer = false }) { drawer = false }
        if (fullPlayer && current != null) {
            FullPlayer(
                song = current,
                playing = playing,
                onBack = { fullPlayer = false },
                onPlay = onPlayPause,
                onPrevious = onPrevious,
                onNext = onNext,
                positionProvider = positionProvider,
                durationProvider = durationProvider,
                onSeekTo = onSeekTo
            )
        }
    }
}

@Composable private fun TopBar(onMenu: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(64.dp).background(Color(0xFF0A0B0D)), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onMenu) { Icon(Icons.Default.Menu, null, tint = Color.White) }
        Text("Pixel Music", color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.weight(1f))
        IconButton({}) { Icon(Icons.Default.Search, null, tint = Color.White) }
        IconButton({}) { Icon(Icons.Default.MoreVert, null, tint = Color.White) }
    }
}

@Composable private fun SongRow(song: MusicSong, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(18.dp, 10.dp), verticalAlignment = Alignment.CenterVertically) {
        AlbumArt(56.dp)
        Column(Modifier.weight(1f).padding(start = 16.dp)) {
            Text(song.title, color = Color.White, maxLines = 1)
            Text("${song.artist} • ${song.album}", color = Color(0xFF9AA0A6), fontSize = 13.sp, maxLines = 1)
        }
        Icon(if (selected && song.title.isNotBlank()) Icons.Default.GraphicEq else Icons.Default.MoreVert, null, tint = if (selected) Color(0xFF4DA3FF) else Color(0xFF777B80))
    }
}

@Composable private fun AlbumArt(size: Dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(4.dp)).background(Brush.linearGradient(listOf(Color(0xFF26384A), Color(0xFF11151A), Color(0xFF4C2020)))), contentAlignment = Alignment.Center) {
        Icon(Icons.Default.MusicNote, null, tint = Color.White.copy(alpha = .8f))
    }
}

@Composable private fun MiniPlayer(song: MusicSong, playing: Boolean, onPlay: () -> Unit, onOpen: () -> Unit, onNext: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(72.dp).background(Color(0xFF15181C)).clickable(onClick = onOpen).padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        AlbumArt(48.dp)
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(song.title, color = Color.White, maxLines = 1)
            Text(song.artist, color = Color(0xFF9AA0A6), fontSize = 12.sp, maxLines = 1)
        }
        IconButton(onPlay) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White) }
        IconButton(onNext) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
    }
}

@Composable private fun NavigationDrawer(onClose: () -> Unit, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxSize()) {
        Column(Modifier.width(300.dp).fillMaxHeight().background(Color(0xFF121417)).padding(top = 32.dp)) {
            Text("PIXEL MUSIC", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Light, modifier = Modifier.padding(24.dp))
            listOf("Home", "Play Queue", "Playlists", "Artists", "Albums", "Songs", "Genres", "Folders", "Google Drive", "New Releases", "Charts", "Settings").forEach {
                Text(it, color = if (it == "Songs") Color(0xFF4DA3FF) else Color(0xFFE2E5E8), fontSize = 15.sp, modifier = Modifier.fillMaxWidth().clickable { onSelect(it) }.padding(horizontal = 24.dp, vertical = 13.dp))
            }
        }
        Spacer(Modifier.fillMaxSize().weight(1f).background(Color.Black.copy(alpha = .55f)).clickable(onClick = onClose))
    }
}

@Composable
private fun FullPlayer(
    song: MusicSong,
    playing: Boolean,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long,
    onSeekTo: (Long) -> Unit
) {
    // Xperia-inspired player: artwork-focused layout, compact metadata, and clear transport controls.
    var positionMs by remember(song.uriString) { mutableLongStateOf(positionProvider().coerceAtLeast(0L)) }
    var durationMs by remember(song.uriString) { mutableLongStateOf(durationProvider().coerceAtLeast(0L)) }

    LaunchedEffect(playing, song.uriString) {
        while (true) {
            positionMs = positionProvider().coerceAtLeast(0L)
            val latestDuration = durationProvider().coerceAtLeast(0L)
            if (latestDuration > 0L) durationMs = latestDuration
            if (!playing) break
            delay(500L)
        }
    }

    val safeDuration = durationMs.coerceAtLeast(1L)
    val sliderValue = (positionMs.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF303943),
                        Color(0xFF15191D),
                        Color(0xFF08090B)
                    )
                )
            )
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(58.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onBack) {
                    Icon(Icons.Default.KeyboardArrowDown, "Close player", tint = Color.White)
                }
                Spacer(Modifier.weight(1f))
                Text(
                    "NOW PLAYING",
                    color = Color.White.copy(alpha = .72f),
                    fontSize = 11.sp,
                    letterSpacing = 1.4.sp
                )
                Spacer(Modifier.weight(1f))
                IconButton({}) {
                    Icon(Icons.Default.MoreVert, "More", tint = Color.White)
                }
            }

            Spacer(Modifier.height(12.dp))

            Box(
                Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                AlbumArt(300.dp)
            }

            Spacer(Modifier.height(20.dp))

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        song.title,
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Normal,
                        maxLines = 1
                    )
                    Text(
                        song.artist,
                        color = Color(0xFFD0D5DA),
                        fontSize = 15.sp,
                        maxLines = 1
                    )
                    Text(
                        song.album,
                        color = Color(0xFF9299A1),
                        fontSize = 13.sp,
                        maxLines = 1
                    )
                }
                IconButton({}) {
                    Icon(
                        Icons.Default.FavoriteBorder,
                        "Favorite",
                        tint = Color.White,
                        modifier = Modifier.size(27.dp)
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            Slider(
                value = sliderValue,
                onValueChange = { fraction ->
                    positionMs = (safeDuration * fraction).toLong().coerceIn(0L, safeDuration)
                },
                onValueChangeFinished = {
                    onSeekTo(positionMs.coerceIn(0L, safeDuration))
                },
                modifier = Modifier.fillMaxWidth(),
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = Color.White,
                    inactiveTrackColor = Color.White.copy(alpha = .28f)
                )
            )

            Row(Modifier.fillMaxWidth()) {
                Text(formatDuration(positionMs), color = Color(0xFF9DA4AA), fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Text(formatDuration(durationMs), color = Color(0xFF9DA4AA), fontSize = 11.sp)
            }

            Spacer(Modifier.height(8.dp))

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                IconButton({}) {
                    Icon(Icons.Default.Shuffle, "Shuffle", tint = Color.White.copy(alpha = .9f))
                }
                IconButton(onPrevious, modifier = Modifier.size(52.dp)) {
                    Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(31.dp))
                }
                FilledIconButton(
                    onClick = onPlay,
                    modifier = Modifier.size(70.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = Color.White,
                        contentColor = Color(0xFF111316)
                    )
                ) {
                    Icon(
                        if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                        "Play or pause",
                        modifier = Modifier.size(36.dp)
                    )
                }
                IconButton(onNext, modifier = Modifier.size(52.dp)) {
                    Icon(Icons.Default.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(31.dp))
                }
                IconButton({}) {
                    Icon(Icons.Default.Repeat, "Repeat", tint = Color.White.copy(alpha = .9f))
                }
            }

            Spacer(Modifier.height(18.dp))

            Row(
                Modifier
                    .fillMaxWidth()
                    .height(42.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${song.artist}  •  ${song.album}",
                    color = Color(0xFF858C93),
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

private fun formatDuration(milliseconds: Long): String {
    val totalSeconds = (milliseconds / 1000L).coerceAtLeast(0L)
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return "%d:%02d".format(minutes, seconds)
}
