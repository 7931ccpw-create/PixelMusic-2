package com.example.pixelmusic.ui

import com.example.pixelmusic.MusicSong
import com.example.pixelmusic.ui.theme.AppTheme
import com.example.pixelmusic.ui.theme.LocalAccentColor
import com.example.pixelmusic.ui.theme.PixelMusicTheme
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.Velocity
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.util.LruCache
import android.media.MediaMetadataRetriever
import java.io.File
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlin.math.absoluteValue
import kotlin.math.roundToInt

@Composable
fun PixelMusicApp(
    songs: List<MusicSong>,
    currentIndex: Int,
    playing: Boolean,
    onSongClick: (Int) -> Unit,
    onRecentSongClick: (Int) -> Unit,
    onPlayFolder: (List<Int>) -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long,
    onSeekTo: (Long) -> Unit,
    shuffleEnabled: Boolean = false,
    repeatMode: Int = 0,
    onToggleShuffle: () -> Unit = {},
    onCycleRepeat: () -> Unit = {},
    queueSongIndices: List<Int>,
    onQueueRemove: (Int) -> Unit,
    onQueueMove: (Int, Int) -> Unit,
    onQueueClear: () -> Unit,
    onQueueAdd: (Int) -> Unit,
    onUpdateSong: (MusicSong) -> Unit,
    onNavigate: (String) -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("pixelmusic_settings", android.content.Context.MODE_PRIVATE) }
    var favoriteIds by remember {
        mutableStateOf(prefs.getStringSet("favorite_ids", emptySet())?.toSet() ?: emptySet())
    }
    var recentIds by remember {
        mutableStateOf(prefs.getString("recent_ids", "").orEmpty().split(",").filter { it.isNotBlank() })
    }
    var playlistNames by remember {
        mutableStateOf(prefs.getString("playlist_names", "").orEmpty().split("\u001f").filter { it.isNotBlank() })
    }
    var playlists by remember {
        mutableStateOf(playlistNames.associateWith { name ->
            prefs.getString("playlist_$name", "").orEmpty().split(",").filter { it.isNotBlank() }.toSet()
        })
    }
    fun persistPlaylists(updated: Map<String, Set<String>>) {
        val names = updated.keys.toList()
        playlistNames = names
        playlists = updated
        val editor = prefs.edit().putString("playlist_names", names.joinToString("\u001f"))
        names.forEach { name -> editor.putString("playlist_$name", updated[name].orEmpty().joinToString(",")) }
        editor.apply()
    }
    fun addToPlaylist(name: String, song: MusicSong) {
        val updated = playlists.toMutableMap()
        updated[name] = (updated[name].orEmpty() + song.id.toString()).toSet()
        persistPlaylists(updated)
    }
    fun removeFromPlaylist(name: String, song: MusicSong) {
        val updated = playlists.toMutableMap()
        updated[name] = updated[name].orEmpty() - song.id.toString()
        persistPlaylists(updated)
    }
    fun createPlaylist(name: String) {
        val clean = name.trim()
        if (clean.isBlank() || playlists.containsKey(clean)) return
        val updated = playlists.toMutableMap()
        updated[clean] = emptySet()
        persistPlaylists(updated)
    }
    fun toggleFavorite(song: MusicSong) {
        val key = song.id.toString()
        val updated = favoriteIds.toMutableSet().apply { if (!add(key)) remove(key) }
        favoriteIds = updated
        prefs.edit().putStringSet("favorite_ids", updated).apply()
    }
    fun recordRecent(song: MusicSong) {
        val key = song.id.toString()
        val updated = (listOf(key) + recentIds.filterNot { it == key }).take(30)
        recentIds = updated
        prefs.edit().putString("recent_ids", updated.joinToString(",")).apply()
    }
    // Record the actual currently playing song as recent. This also captures
    // next/previous/queue playback, not only taps on a song card.
    val currentSongForRecent = songs.getOrNull(currentIndex)
    LaunchedEffect(currentSongForRecent?.id, playing) {
        if (playing) {
            currentSongForRecent?.let { recordRecent(it) }
        }
    }
    var selectedTheme by remember {
        mutableStateOf(
            runCatching {
                AppTheme.valueOf(prefs.getString("theme", AppTheme.Blue.name) ?: AppTheme.Blue.name)
            }.getOrDefault(AppTheme.Blue)
        )
    }
    val accent = selectedTheme.accent
    CompositionLocalProvider(LocalAccentColor provides accent) {
        PixelMusicTheme(accent = accent) {
        PixelMusicContent(
            songs = songs, currentIndex = currentIndex, playing = playing,
            onSongClick = onSongClick, onRecentSongClick = onRecentSongClick, onPlayFolder = onPlayFolder, onPlayPause = onPlayPause, onNext = onNext,
            onPrevious = onPrevious, positionProvider = positionProvider,
            durationProvider = durationProvider, onSeekTo = onSeekTo,
            shuffleEnabled = shuffleEnabled, repeatMode = repeatMode,
            onToggleShuffle = onToggleShuffle, onCycleRepeat = onCycleRepeat,
            favoriteIds = favoriteIds, recentIds = recentIds,
            onToggleFavorite = ::toggleFavorite, onRecordRecent = ::recordRecent,
            selectedTheme = selectedTheme, onThemeChange = {
                selectedTheme = it
                prefs.edit().putString("theme", it.name).apply()
            },
            queueSongIndices = queueSongIndices,
            onQueueRemove = onQueueRemove,
            onQueueMove = onQueueMove,
            onQueueClear = onQueueClear,
            onQueueAdd = onQueueAdd,
            onUpdateSong = onUpdateSong,
            onNavigate = onNavigate,
            playlistNames = playlistNames,
            playlists = playlists,
            onCreatePlaylist = { createPlaylist(it) },
            onAddToPlaylist = { name, song -> addToPlaylist(name, song) },
            onRemoveFromPlaylist = { name, song -> removeFromPlaylist(name, song) }
        )
        }
    }

}

@Composable
fun PixelMusicContent(
    songs: List<MusicSong>,
    currentIndex: Int,
    playing: Boolean,
    onSongClick: (Int) -> Unit,
    onRecentSongClick: (Int) -> Unit,
    onPlayFolder: (List<Int>) -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long,
    onSeekTo: (Long) -> Unit,
    shuffleEnabled: Boolean,
    repeatMode: Int,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    favoriteIds: Set<String>,
    recentIds: List<String>,
    onToggleFavorite: (MusicSong) -> Unit,
    onRecordRecent: (MusicSong) -> Unit,
    selectedTheme: AppTheme,
    onThemeChange: (AppTheme) -> Unit,
    queueSongIndices: List<Int>,
    onQueueRemove: (Int) -> Unit,
    onQueueMove: (Int, Int) -> Unit,
    onQueueClear: () -> Unit,
    onQueueAdd: (Int) -> Unit,
    onUpdateSong: (MusicSong) -> Unit,
    onNavigate: (String) -> Unit,
    playlistNames: List<String>,
    playlists: Map<String, Set<String>>,
    onCreatePlaylist: (String) -> Unit,
    onAddToPlaylist: (String, MusicSong) -> Unit,
    onRemoveFromPlaylist: (String, MusicSong) -> Unit
) {
    var drawer by remember { mutableStateOf(false) }
    var sleepTimerMinutes by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(sleepTimerMinutes) {
        val minutes = sleepTimerMinutes ?: return@LaunchedEffect
        if (minutes <= 0) return@LaunchedEffect
        delay(minutes * 60_000L)
        if (playing) onPlayPause()
        sleepTimerMinutes = null
    }
    var fullPlayer by remember { mutableStateOf(false) }
    var editInfo by remember { mutableStateOf(false) }
    var screen by remember { mutableStateOf("Home") }
    val context = androidx.compose.ui.platform.LocalContext.current

    // System navigation-bar Back button: return to Home from any screen.
    // If an overlay is open, close it first so the underlying screen remains intact.
    BackHandler(enabled = true) {
        when {
            drawer -> drawer = false
            editInfo -> editInfo = false
            fullPlayer -> fullPlayer = false
            screen != "Home" -> screen = "Home"
            else -> {
                val activity = context as? android.app.Activity
                activity?.finish()
            }
        }
    }
    val current = songs.getOrNull(currentIndex)
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var heroPull by remember { mutableFloatStateOf(0f) }
    val pullConnection = remember(listState) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: androidx.compose.ui.geometry.Offset, source: NestedScrollSource): androidx.compose.ui.geometry.Offset {
                if (source == NestedScrollSource.UserInput && available.y > 0f && listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset == 0) {
                    val consumed = available.y.coerceAtMost(available.y * 0.48f)
                    heroPull = (heroPull + consumed).coerceIn(0f, 240f)
                    return androidx.compose.ui.geometry.Offset(0f, consumed)
                }
                return androidx.compose.ui.geometry.Offset.Zero
            }
            override suspend fun onPreFling(available: Velocity): Velocity {
                if (heroPull > 0f) {
                    scope.launch {
                        androidx.compose.animation.core.Animatable(heroPull).animateTo(0f) { heroPull = value }
                    }
                }
                return Velocity.Zero
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF08090B))
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            Column(Modifier.fillMaxSize()) {
                if (screen != "Home") {
                    TopBar(
                        title = screen,
                        onMenu = { drawer = true },
                        onSearch = { screen = "Search" }
                    )
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                when (screen) {
                    "Home" -> HomeScreen(
                        songs = songs,
                        currentIndex = currentIndex,
                        current = current,
                        listState = listState,
                        pullConnection = pullConnection,
                        heroPull = heroPull,
                        onHeroOpen = { if (current != null) fullPlayer = true },
                        queueSongIndices = queueSongIndices,
                        recentIds = recentIds,
                        onNavigate = { screen = it },
                        onCycleRepeat = onCycleRepeat,
                        onQueueAdd = onQueueAdd,
                        playlistNames = playlistNames,
                        onAddToPlaylist = onAddToPlaylist,
                        onRecentSongClick = { index -> onRecentSongClick(index) },
                        onSongClick = { index ->
                            songs.getOrNull(index)?.let(onRecordRecent)
                            onSongClick(index)
                        }
                    )
                    "Settings" -> SettingsScreen(
                        selectedTheme = selectedTheme,
                        onThemeChange = onThemeChange
                    )
                    "Folders" -> FolderBrowserScreen(
                        songs = songs,
                        onSongClick = { index ->
                            songs.getOrNull(index)?.let(onRecordRecent)
                            onSongClick(index)
                        },
                        onPlayFolder = { indices ->
                            onPlayFolder(indices)
                        },
                        onExit = { screen = "Home" },
                        onQueueAdd = onQueueAdd,
                        playlistNames = playlistNames,
                        onAddToPlaylist = onAddToPlaylist
                    )
                    "Search" -> SearchScreen(
                        songs = songs,
                        currentIndex = currentIndex,
                        onSongClick = { index ->
                            songs.getOrNull(index)?.let(onRecordRecent)
                            onSongClick(index)
                        },
                        onQueueAdd = onQueueAdd,
                        playlistNames = playlistNames,
                        onAddToPlaylist = onAddToPlaylist
                    )
                    else -> LibraryScreen(
                        title = screen,
                        songs = songs,
                        currentIndex = currentIndex,
                        favoriteIds = favoriteIds,
                        recentIds = recentIds,
                        onSongClick = { index ->
                            songs.getOrNull(index)?.let(onRecordRecent)
                            onSongClick(index)
                        },
                        onNavigate = { screen = it },
                        queueSongIndices = queueSongIndices,
                        onQueueRemove = onQueueRemove,
                        onQueueMove = onQueueMove,
                        onQueueClear = onQueueClear,
                        onQueueAdd = onQueueAdd,
                        playlistNames = playlistNames,
                        playlists = playlists,
                        onCreatePlaylist = onCreatePlaylist,
                        onAddToPlaylist = onAddToPlaylist,
                        onRemoveFromPlaylist = onRemoveFromPlaylist
                    )
                }
            }
                if (current != null) {
                    MiniPlayer(current, playing, onPlayPause, { fullPlayer = true }, onPrevious, onNext, positionProvider, durationProvider)
                }
            }

            // On Home, place the controls over the hero image so the artwork remains
            // visible behind the hamburger, title, search and overflow buttons.
            if (screen == "Home") {
                TopBar(
                    title = "",
                    onMenu = { drawer = true },
                    onSearch = { screen = "Search" },
                    showOverflow = false
                )
            }
        }

        if (drawer) {
            NavigationDrawer(
                selected = screen,
                onClose = { drawer = false },
                onSelect = { selected ->
                    screen = selected
                    drawer = false
                }
            )
        }
        if (editInfo && current != null) {
            EditMusicInfoScreen(
                song = current,
                onBack = { editInfo = false },
                onSave = { updated ->
                    onUpdateSong(updated)
                    editInfo = false
                }
            )
        } else if (fullPlayer && current != null) {
            Box(
                Modifier
                    .fillMaxSize()
                    .zIndex(100f)
                    .background(Color(0xFF050607))
            ) {
                FullPlayer(
                    song = current,
                    playing = playing,
                    onBack = { fullPlayer = false },
                    onPlay = onPlayPause,
                    onPrevious = onPrevious,
                    onNext = onNext,
                    positionProvider = positionProvider,
                    durationProvider = durationProvider,
                    onSeekTo = onSeekTo,
                    shuffleEnabled = shuffleEnabled,
                    repeatMode = repeatMode,
                    onToggleShuffle = onToggleShuffle,
                    onCycleRepeat = onCycleRepeat,
                    isFavorite = current.id.toString() in favoriteIds,
                    onToggleFavorite = { onToggleFavorite(current) },
                    onEditInfo = { editInfo = true },
                    sleepTimerMinutes = sleepTimerMinutes,
                    onSetSleepTimer = { sleepTimerMinutes = it },
                    onNavigate = { target -> screen = target }
                )
            }
        }
    }
}


@Composable
private fun HomeHero(song: MusicSong?, pull: Float, onOpenPlayer: () -> Unit) {
    val scale = 1f + (pull / 720f).coerceIn(0f, 0.34f)
    Box(
        Modifier
            .fillMaxWidth()
            .height(300.dp)
            .graphicsLayer {
                // Keep the top edge of the artwork anchored while pulling down.
                // This prevents the upper part of the artist/album image from
                // being pushed behind the top edge as the image expands.
                transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 0f)
                scaleX = scale
                scaleY = scale
                translationY = pull * 0.08f
            }
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(
                Brush.verticalGradient(
                    0f to Color.Black.copy(alpha = .10f),
                    0.48f to LocalAccentColor.current.copy(alpha = .18f),
                    0.78f to Color(0xFF101419).copy(alpha = .76f),
                    1f to Color(0xFF08090B)
                )
            )
            .clickable(enabled = song != null, onClick = onOpenPlayer)
    ) {
        ArtworkImage(song, Modifier.fillMaxSize(), ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
            listOf(Color.Black.copy(alpha = .08f), Color.Black.copy(alpha = .18f), Color.Black.copy(alpha = .58f))
        )))
        Column(
            Modifier.fillMaxSize().padding(start = 24.dp, end = 24.dp, bottom = 22.dp, top = 18.dp),
            verticalArrangement = Arrangement.Bottom
        ) {
            Text(
                "NOW PLAYING",
                color = Color.White.copy(alpha = 0.72f),
                fontSize = 11.sp,
                letterSpacing = 1.5.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                song?.artist?.takeIf { it.isNotBlank() } ?: "Your Music",
                color = Color.White,
                fontSize = 29.sp,
                fontWeight = FontWeight.Light,
                maxLines = 1
            )
            Text(
                song?.album?.takeIf { it.isNotBlank() } ?: "Music Library",
                color = Color.White.copy(alpha = 0.78f),
                fontSize = 14.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun TopBar(title: String, onMenu: () -> Unit, onSearch: () -> Unit, showOverflow: Boolean = true) {
    Row(
        // Keep the top controls visually floating over the artist/album image.
        // The image remains visible behind the menu, title, search and overflow areas.
        Modifier.fillMaxWidth().height(64.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onMenu) { Icon(Icons.Default.Menu, null, tint = Color.White) }
        Text(title, color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.weight(1f))
        IconButton(onSearch) { Icon(Icons.Default.Search, null, tint = Color.White) }
        if (showOverflow) {
            IconButton({}) { Icon(Icons.Default.MoreVert, null, tint = Color.White) }
        }
    }
}

@Composable
private fun SearchScreen(
    songs: List<MusicSong>,
    currentIndex: Int,
    onSongClick: (Int) -> Unit,
    onQueueAdd: (Int) -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val normalizedQuery = query.trim()
    val results = remember(normalizedQuery, songs) {
        if (normalizedQuery.isBlank()) emptyList() else songs.filter { song ->
            song.title.contains(normalizedQuery, ignoreCase = true) ||
            song.artist.contains(normalizedQuery, ignoreCase = true) ||
            song.album.contains(normalizedQuery, ignoreCase = true)
        }
    }
    val artistCount = remember(results) {
        results.map { it.artist.trim() }.filter { it.isNotBlank() }.distinct().size
    }
    val albumCount = remember(results) {
        results.map { it.album.trim() }.filter { it.isNotBlank() }.distinct().size
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 12.dp),
            placeholder = { Text("曲名・アーティスト・アルバムを検索") },
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Default.Clear, "Clear")
                    }
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = LocalAccentColor.current,
                unfocusedBorderColor = Color(0xFF3B4147),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedPlaceholderColor = Color(0xFF777D83),
                unfocusedPlaceholderColor = Color(0xFF777D83),
                focusedLeadingIconColor = LocalAccentColor.current,
                unfocusedLeadingIconColor = Color(0xFF777D83),
                focusedTrailingIconColor = Color(0xFFB0B5BA),
                unfocusedTrailingIconColor = Color(0xFFB0B5BA)
            )
        )

        when {
            normalizedQuery.isBlank() -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 22.dp, vertical = 30.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = null,
                        tint = LocalAccentColor.current.copy(alpha = .75f),
                        modifier = Modifier.size(42.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text("音楽を検索", color = Color.White, fontSize = 18.sp)
                    Spacer(Modifier.height(5.dp))
                    Text(
                        "曲名・アーティスト・アルバムから検索できます",
                        color = Color(0xFF858C93),
                        fontSize = 13.sp
                    )
                }
            }
            results.isEmpty() -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 22.dp, vertical = 34.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.SearchOff,
                        contentDescription = null,
                        tint = Color(0xFF777D83),
                        modifier = Modifier.size(38.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("一致する曲がありません", color = Color.White, fontSize = 17.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("「$normalizedQuery」", color = Color(0xFF858C93), fontSize = 13.sp)
                }
            }
            else -> {
                Column(Modifier.fillMaxSize()) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 22.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "検索結果",
                            color = LocalAccentColor.current,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Light
                        )
                        Spacer(Modifier.weight(1f))
                        Text(
                            "${results.size}曲  •  ${artistCount}アーティスト  •  ${albumCount}アルバム",
                            color = Color(0xFF777D83),
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }
                    Text(
                        "${results.size} results",
                        color = Color(0xFF777D83),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 22.dp, vertical = 2.dp)
                    )
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        itemsIndexed(results) { _, song ->
                            val actualIndex = songs.indexOf(song)
                            SongRow(
                                song = song,
                                selected = actualIndex == currentIndex,
                                onAddToQueue = { if (actualIndex >= 0) onQueueAdd(actualIndex) },
                                playlistNames = playlistNames,
                                onAddToPlaylist = onAddToPlaylist
                            ) { if (actualIndex >= 0) onSongClick(actualIndex) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    songs: List<MusicSong>,
    currentIndex: Int,
    current: MusicSong?,
    listState: androidx.compose.foundation.lazy.LazyListState,
    pullConnection: NestedScrollConnection,
    heroPull: Float,
    onHeroOpen: () -> Unit,
    queueSongIndices: List<Int>,
    recentIds: List<String>,
    onNavigate: (String) -> Unit,
    onCycleRepeat: () -> Unit,
    onQueueAdd: (Int) -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit,
    onRecentSongClick: (Int) -> Unit,
    onSongClick: (Int) -> Unit
) {
    val recentSongs = remember(recentIds, songs) {
        recentIds.mapNotNull { id -> songs.firstOrNull { it.id.toString() == id } }
    }
    val newSongs = remember(songs) {
        songs.sortedByDescending { it.dateAdded }.take(9)
    }
    val queueEntries = remember(queueSongIndices, songs) {
        queueSongIndices.mapNotNull { index ->
            songs.getOrNull(index)?.let { index to it }
        }
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .nestedScroll(pullConnection),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item {
                HomeHero(song = current, pull = heroPull, onOpenPlayer = onHeroOpen)
            }

            item {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(start = 24.dp, end = 18.dp, top = 22.dp, bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "再生待ちリスト",
                        color = Color.White,
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Light,
                        modifier = Modifier.weight(1f)
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(LocalAccentColor.current)
                            .clickable { onNavigate("Play Queue") }
                            .padding(horizontal = 18.dp, vertical = 9.dp)
                    ) {
                        Text("開く", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }

            if (queueEntries.isEmpty()) {
                item {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 18.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF202225))
                            .padding(22.dp)
                    ) {
                        Text("再生待ちの曲はありません", color = Color(0xFF9AA0A6), fontSize = 14.sp)
                    }
                }
            } else {
                item {
                    androidx.compose.foundation.lazy.LazyRow(
                        contentPadding = PaddingValues(horizontal = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        itemsIndexed(queueEntries.take(12)) { _, entry ->
                            val (actualIndex, song) = entry
                            HomeQueueCard(
                                song = song,
                                selected = song.id == current?.id,
                                onClick = { onSongClick(actualIndex) },
                                onAddToQueue = { onQueueAdd(actualIndex) },
                                playlistNames = playlistNames,
                                onAddToPlaylist = onAddToPlaylist
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    "最近再生した曲",
                    color = Color.White,
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Light,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 22.dp)
                )
            }

            if (recentSongs.isEmpty()) {
                item {
                    Text(
                        "最近再生した曲はありません",
                        color = Color(0xFF9AA0A6),
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                    )
                }
            } else {
                item {
                    Column(
                        Modifier.fillMaxWidth().padding(horizontal = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        recentSongs.take(30).chunked(3).forEach { rowSongs ->
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                rowSongs.forEach { song ->
                                    val songIndex = songs.indexOfFirst { it.id == song.id }
                                    HomeRecentCard(
                                        song = song,
                                        onClick = { if (songIndex >= 0) onRecentSongClick(songIndex) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                repeat(3 - rowSongs.size) {
                                    Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(start = 24.dp, end = 18.dp, top = 22.dp, bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "新規追加",
                        color = Color.White,
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Light,
                        modifier = Modifier.weight(1f)
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF2A2D31))
                            .clickable { onNavigate("Newly Added") }
                            .padding(horizontal = 18.dp, vertical = 9.dp)
                    ) {
                        Text("もっと見る", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }

            item {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    newSongs.chunked(3).forEach { rowSongs ->
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowSongs.forEach { song ->
                                val songIndex = songs.indexOfFirst { it.id == song.id }
                                HomeRecentCard(
                                    song = song,
                                    onClick = { if (songIndex >= 0) onRecentSongClick(songIndex) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            repeat(3 - rowSongs.size) {
                                Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }

        // Small floating repeat control, matching the reference layout while
        // keeping the existing repeat functionality available from Home.
        FloatingActionButton(
            onClick = onCycleRepeat,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 18.dp, bottom = 94.dp),
            containerColor = LocalAccentColor.current,
            contentColor = Color.White,
            shape = androidx.compose.foundation.shape.CircleShape
        ) {
            Icon(Icons.Default.Repeat, contentDescription = "Repeat")
        }
    }
}

@Composable
private fun HomeQueueCard(
    song: MusicSong,
    selected: Boolean,
    onClick: () -> Unit,
    onAddToQueue: () -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit
) {
    var menuOpen by remember(song.id) { mutableStateOf(false) }
    Column(
        Modifier
            .width(112.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFF292A2C))
            .clickable(onClick = onClick)
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f)) {
            AlbumArt(song = song, size = 112.dp, modifier = Modifier.fillMaxSize())
            if (selected) {
                Box(
                    Modifier
                        .align(Alignment.BottomStart)
                        .padding(10.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Black.copy(alpha = .65f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Default.Pause, null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(start = 11.dp, top = 9.dp, bottom = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    song.title.ifBlank { "Unknown title" },
                    color = Color.White,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
                Text(
                    song.artist.ifBlank { "Unknown artist" },
                    color = Color(0xFF9AA0A6),
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
            }
            Box {
                IconButton(
                    onClick = { menuOpen = true },
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        Icons.Default.MoreVert,
                        "More",
                        tint = Color(0xFF858A90),
                        modifier = Modifier.size(21.dp)
                    )
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("Add to Play Queue") },
                        leadingIcon = { Icon(Icons.Default.QueueMusic, null) },
                        onClick = { menuOpen = false; onAddToQueue() }
                    )
                    playlistNames.forEach { name ->
                        DropdownMenuItem(
                            text = { Text("Add to $name") },
                            leadingIcon = { Icon(Icons.Default.PlaylistAdd, null) },
                            onClick = { menuOpen = false; onAddToPlaylist(name, song) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeRecentCard(
    song: MusicSong,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier
            .clip(RoundedCornerShape(3.dp))
            .background(Color(0xFF292A2C))
            .clickable(onClick = onClick)
    ) {
        ArtworkImage(
            song = song,
            modifier = Modifier.fillMaxWidth().aspectRatio(1f),
            contentScale = ContentScale.Crop
        )
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text(song.title.ifBlank { "Unknown title" }, color = Color.White, fontSize = 15.sp, maxLines = 1)
            Text(song.artist.ifBlank { "Unknown artist" }, color = Color(0xFF9AA0A6), fontSize = 12.sp, maxLines = 1)
        }
    }
}

@Composable
private fun FolderBrowserScreen(
    songs: List<MusicSong>,
    onSongClick: (Int) -> Unit,
    onPlayFolder: (List<Int>) -> Unit,
    onExit: () -> Unit,
    onQueueAdd: (Int) -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit
) {
    var currentPath by remember { mutableStateOf<String?>(null) }

    BackHandler {
        if (currentPath != null) currentPath = null else onExit()
    }

    fun folderKey(song: MusicSong): String {
        return song.folderPath.trimEnd('/').ifBlank { "__UNKNOWN__" }
    }

    fun folderName(path: String): String {
        if (path == "__UNKNOWN__") return "その他"
        return path.substringAfterLast('/').ifBlank { path }
    }

    val folders = remember(songs) {
        songs.groupBy { folderKey(it) }
            .mapValues { it.value.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { s -> s.title }) }
            .toList()
            .sortedBy { folderName(it.first).lowercase() }
    }

    val visibleSongs = remember(songs, currentPath) {
        currentPath?.let { path -> songs.filter { folderKey(it) == path } } ?: emptyList()
    }

    val title = currentPath?.let { folderName(it) } ?: "フォルダ"
    val subtitle = if (currentPath == null) {
        "端末内の音楽フォルダ"
    } else {
        "${visibleSongs.size}曲"
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
            Text(title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Light, maxLines = 2)
            Text(subtitle, color = Color(0xFF777D83), fontSize = 12.sp, maxLines = 1)
            if (visibleSongs.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val indices = visibleSongs.mapNotNull { song ->
                            songs.indexOfFirst { it.id == song.id }.takeIf { it >= 0 }
                        }
                        onPlayFolder(indices)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LocalAccentColor.current),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("このフォルダを再生")
                }
            }
        }

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            if (currentPath == null) {
                itemsIndexed(folders) { _, item ->
                    val (path, folderSongs) = item
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { currentPath = path }
                            .padding(horizontal = 18.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(54.dp).clip(RoundedCornerShape(8.dp))
                                .background(LocalAccentColor.current.copy(alpha = .13f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Folder, null, tint = LocalAccentColor.current, modifier = Modifier.size(28.dp))
                        }
                        Column(Modifier.weight(1f).padding(start = 15.dp)) {
                            Text(folderName(path), color = Color.White, fontSize = 16.sp, maxLines = 1)
                            Text("${folderSongs.size}曲", color = Color(0xFF8F969D), fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Color(0xFF777D83))
                    }
                    HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
                }
            } else {
                itemsIndexed(visibleSongs) { _, song ->
                    val index = songs.indexOfFirst { it.id == song.id }
                    if (index >= 0) {
                        SongRow(
                            song = song,
                            selected = false,
                            onAddToQueue = { onQueueAdd(index) },
                            playlistNames = playlistNames,
                            onAddToPlaylist = onAddToPlaylist,
                            onClick = { onSongClick(index) }
                        )
                    }
                }
            }

            if (folders.isEmpty() && currentPath == null) {
                item {
                    Text(
                        "音楽フォルダが見つかりません",
                        color = Color(0xFF8F969D),
                        modifier = Modifier.padding(22.dp)
                    )
                }
            }
            if (visibleSongs.isEmpty() && currentPath != null) {
                item {
                    Text(
                        "このフォルダに音楽ファイルはありません",
                        color = Color(0xFF8F969D),
                        modifier = Modifier.padding(22.dp)
                    )
                }
            }
        }
    }
}
