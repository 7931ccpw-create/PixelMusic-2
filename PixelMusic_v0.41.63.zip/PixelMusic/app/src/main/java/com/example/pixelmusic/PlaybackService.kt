package com.example.pixelmusic

import android.content.Intent
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Foreground media playback service. Owns the [MediaSession] so Android can show
 * the system media notification and keep audio running with the screen off /
 * app in the background.
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val player: ExoPlayer = PlayerHolder.getOrCreate(this)
        mediaSession = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = PlayerHolder.get()
        // If nothing is playing, stop the service so it does not linger.
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        mediaSession?.run {
            // Do not release the shared player here while the activity may still
            // be alive; only release the session. Player is released when the
            // process is finishing and the activity explicitly requests it.
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
}
