package com.example.pixelmusic.ui

import com.example.pixelmusic.MusicSong
import com.example.pixelmusic.ui.theme.AppTheme
import com.example.pixelmusic.ui.theme.LocalAccentColor
import com.example.pixelmusic.ui.theme.PixelMusicTheme
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.Velocity
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.util.LruCache
import android.media.MediaMetadataRetriever
import java.io.File
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlin.math.absoluteValue
import kotlin.math.roundToInt

@Composable
fun PixelMusicApp(
    songs: List<MusicSong>,
    currentIndex: Int,
    playing: Boolean,
    onSongClick: (Int) -> Unit,
    onRecentSongClick: (Int) -> Unit,
    onPlayFolder: (List<Int>) -> Unit,
    onPlaySongList: (List<Int>) -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long,
    onSeekTo: (Long) -> Unit,
    shuffleEnabled: Boolean = false,
    repeatMode: Int = 0,
    onToggleShuffle: () -> Unit = {},
    onCycleRepeat: () -> Unit = {},
    queueSongIndices: List<Int>,
    onQueueRemove: (Int) -> Unit,
    onQueueMove: (Int, Int) -> Unit,
    onQueueClear: () -> Unit,
    onQueueAdd: (Int) -> Unit,
    onUpdateSong: (MusicSong) -> Unit,
    onNavigate: (String) -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("pixelmusic_settings", android.content.Context.MODE_PRIVATE) }
    var favoriteIds by remember {
        mutableStateOf(prefs.getStringSet("favorite_ids", emptySet())?.toSet() ?: emptySet())
    }
    var recentIds by remember {
        mutableStateOf(prefs.getString("recent_ids", "").orEmpty().split(",").filter { it.isNotBlank() })
    }
    var playlistNames by remember {
        mutableStateOf(prefs.getString("playlist_names", "").orEmpty().split("\u001f").filter { it.isNotBlank() })
    }
    var playlists by remember {
        mutableStateOf(playlistNames.associateWith { name ->
            prefs.getString("playlist_$name", "").orEmpty().split(",").filter { it.isNotBlank() }.toSet()
        })
    }
    fun persistPlaylists(updated: Map<String, Set<String>>) {
        val names = updated.keys.toList()
        playlistNames = names
        playlists = updated
        val editor = prefs.edit().putString("playlist_names", names.joinToString("\u001f"))
        names.forEach { name -> editor.putString("playlist_$name", updated[name].orEmpty().joinToString(",")) }
        editor.apply()
    }
    fun addToPlaylist(name: String, song: MusicSong) {
        val updated = playlists.toMutableMap()
        updated[name] = (updated[name].orEmpty() + song.id.toString()).toSet()
        persistPlaylists(updated)
    }
    fun removeFromPlaylist(name: String, song: MusicSong) {
        val updated = playlists.toMutableMap()
        updated[name] = updated[name].orEmpty() - song.id.toString()
        persistPlaylists(updated)
    }
    fun createPlaylist(name: String) {
        val clean = name.trim()
        if (clean.isBlank() || playlists.containsKey(clean)) return
        val updated = playlists.toMutableMap()
        updated[clean] = emptySet()
        persistPlaylists(updated)
    }
    fun toggleFavorite(song: MusicSong) {
        val key = song.id.toString()
        val updated = favoriteIds.toMutableSet().apply { if (!add(key)) remove(key) }
        favoriteIds = updated
        prefs.edit().putStringSet("favorite_ids", updated).apply()
    }
    fun recordRecent(song: MusicSong) {
        val key = song.id.toString()
        val updated = (listOf(key) + recentIds.filterNot { it == key }).take(30)
        recentIds = updated
        prefs.edit().putString("recent_ids", updated.joinToString(",")).apply()
    }
    // Record the actual currently playing song as recent. This also captures
    // next/previous/queue playback, not only taps on a song card.
    val currentSongForRecent = songs.getOrNull(currentIndex)
    LaunchedEffect(currentSongForRecent?.id, playing) {
        if (playing) {
            currentSongForRecent?.let { recordRecent(it) }
        }
    }
    var selectedTheme by remember {
        mutableStateOf(
            runCatching {
                AppTheme.valueOf(prefs.getString("theme", AppTheme.Blue.name) ?: AppTheme.Blue.name)
            }.getOrDefault(AppTheme.Blue)
        )
    }
    val accent = selectedTheme.accent
    CompositionLocalProvider(LocalAccentColor provides accent) {
        PixelMusicTheme(accent = accent) {
        PixelMusicContent(
            songs = songs, currentIndex = currentIndex, playing = playing,
            onSongClick = onSongClick, onRecentSongClick = onRecentSongClick, onPlayFolder = onPlayFolder, onPlaySongList = onPlaySongList, onPlayPause = onPlayPause, onNext = onNext,
            onPrevious = onPrevious, positionProvider = positionProvider,
            durationProvider = durationProvider, onSeekTo = onSeekTo,
            shuffleEnabled = shuffleEnabled, repeatMode = repeatMode,
            onToggleShuffle = onToggleShuffle, onCycleRepeat = onCycleRepeat,
            favoriteIds = favoriteIds, recentIds = recentIds,
            onToggleFavorite = ::toggleFavorite, onRecordRecent = ::recordRecent,
            selectedTheme = selectedTheme, onThemeChange = {
                selectedTheme = it
                prefs.edit().putString("theme", it.name).apply()
            },
            queueSongIndices = queueSongIndices,
            onQueueRemove = onQueueRemove,
            onQueueMove = onQueueMove,
            onQueueClear = onQueueClear,
            onQueueAdd = onQueueAdd,
            onUpdateSong = onUpdateSong,
            onNavigate = onNavigate,
            playlistNames = playlistNames,
            playlists = playlists,
            onCreatePlaylist = { createPlaylist(it) },
            onAddToPlaylist = { name, song -> addToPlaylist(name, song) },
            onRemoveFromPlaylist = { name, song -> removeFromPlaylist(name, song) }
        )
        }
    }

}

@Composable
fun PixelMusicContent(
    songs: List<MusicSong>,
    currentIndex: Int,
    playing: Boolean,
    onSongClick: (Int) -> Unit,
    onRecentSongClick: (Int) -> Unit,
    onPlayFolder: (List<Int>) -> Unit,
    onPlaySongList: (List<Int>) -> Unit,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long,
    onSeekTo: (Long) -> Unit,
    shuffleEnabled: Boolean,
    repeatMode: Int,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    favoriteIds: Set<String>,
    recentIds: List<String>,
    onToggleFavorite: (MusicSong) -> Unit,
    onRecordRecent: (MusicSong) -> Unit,
    selectedTheme: AppTheme,
    onThemeChange: (AppTheme) -> Unit,
    queueSongIndices: List<Int>,
    onQueueRemove: (Int) -> Unit,
    onQueueMove: (Int, Int) -> Unit,
    onQueueClear: () -> Unit,
    onQueueAdd: (Int) -> Unit,
    onUpdateSong: (MusicSong) -> Unit,
    onNavigate: (String) -> Unit,
    playlistNames: List<String>,
    playlists: Map<String, Set<String>>,
    onCreatePlaylist: (String) -> Unit,
    onAddToPlaylist: (String, MusicSong) -> Unit,
    onRemoveFromPlaylist: (String, MusicSong) -> Unit
) {
    var drawer by remember { mutableStateOf(false) }
    var sleepTimerMinutes by remember { mutableStateOf<Int?>(null) }

    LaunchedEffect(sleepTimerMinutes) {
        val minutes = sleepTimerMinutes ?: return@LaunchedEffect
        if (minutes <= 0) return@LaunchedEffect
        delay(minutes * 60_000L)
        if (playing) onPlayPause()
        sleepTimerMinutes = null
    }
    var fullPlayer by remember { mutableStateOf(false) }
    var editInfo by remember { mutableStateOf(false) }
    var screen by remember { mutableStateOf("Home") }
    val context = androidx.compose.ui.platform.LocalContext.current
    val screenBackStack = remember { mutableStateListOf<String>() }
    val topLevelScreens = remember {
        setOf("Home", "Play Queue", "Playlists", "Artists", "Albums", "Songs", "Genres", "Folders", "Favorites", "Recently Played", "New Releases", "Charts", "Settings")
    }
    fun navigateTo(target: String) {
        if (target == screen) return
        if (target == "Home") {
            screenBackStack.clear()
            screen = "Home"
        } else if (target in topLevelScreens) {
            // Switching a main library section replaces the current section,
            // so Back from a detail page returns to the selected section then Home.
            screenBackStack.clear()
            screen = target
        } else {
            screenBackStack.add(screen)
            screen = target
        }
    }
    fun navigateBack() {
        if (screenBackStack.isNotEmpty()) {
            screen = screenBackStack.removeAt(screenBackStack.lastIndex)
        } else if (screen != "Home") {
            screen = "Home"
        } else {
            val activity = context as? android.app.Activity
            activity?.finish()
        }
    }

    // Back closes overlays first, then returns through the screen history.
    BackHandler(enabled = true) {
        when {
            drawer -> drawer = false
            editInfo -> editInfo = false
            fullPlayer -> fullPlayer = false
            else -> navigateBack()
        }
    }
    val current = songs.getOrNull(currentIndex)
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    var heroPull by remember { mutableFloatStateOf(0f) }
    val pullConnection = remember(listState) {
        object : NestedScrollConnection {
            override fun onPreScroll(available: androidx.compose.ui.geometry.Offset, source: NestedScrollSource): androidx.compose.ui.geometry.Offset {
                if (source == NestedScrollSource.UserInput && available.y > 0f && listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset == 0) {
                    val consumed = available.y.coerceAtMost(available.y * 0.48f)
                    heroPull = (heroPull + consumed).coerceIn(0f, 240f)
                    return androidx.compose.ui.geometry.Offset(0f, consumed)
                }
                return androidx.compose.ui.geometry.Offset.Zero
            }
            override suspend fun onPreFling(available: Velocity): Velocity {
                if (heroPull > 0f) {
                    scope.launch {
                        androidx.compose.animation.core.Animatable(heroPull).animateTo(0f) { heroPull = value }
                    }
                }
                return Velocity.Zero
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF08090B))
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            Column(Modifier.fillMaxSize()) {
                if (screen != "Home") {
                    TopBar(
                        title = screen,
                        onMenu = { drawer = true },
                        onSearch = { navigateTo("Search") }
                    )
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                when (screen) {
                    "Home" -> HomeScreen(
                        songs = songs,
                        currentIndex = currentIndex,
                        current = current,
                        listState = listState,
                        pullConnection = pullConnection,
                        heroPull = heroPull,
                        onHeroOpen = { if (current != null) fullPlayer = true },
                        queueSongIndices = queueSongIndices,
                        recentIds = recentIds,
                        onNavigate = { navigateTo(it) },
                        onCycleRepeat = onCycleRepeat,
                        onQueueAdd = onQueueAdd,
                        playlistNames = playlistNames,
                        onAddToPlaylist = onAddToPlaylist,
                        onRecentSongClick = { index -> onRecentSongClick(index) },
                        onSongClick = { index ->
                            songs.getOrNull(index)?.let(onRecordRecent)
                            onSongClick(index)
                        }
                    )
                    "Settings" -> SettingsScreen(
                        selectedTheme = selectedTheme,
                        onThemeChange = onThemeChange
                    )
                    "Folders" -> FolderBrowserScreen(
                        songs = songs,
                        onSongClick = { index ->
                            songs.getOrNull(index)?.let(onRecordRecent)
                            onSongClick(index)
                        },
                        onPlayFolder = { indices ->
                            onPlayFolder(indices)
                        },
                        onExit = { navigateBack() },
                        onQueueAdd = onQueueAdd,
                        playlistNames = playlistNames,
                        onAddToPlaylist = onAddToPlaylist
                    )
                    "Search" -> SearchScreen(
                        songs = songs,
                        currentIndex = currentIndex,
                        onSongClick = { index ->
                            songs.getOrNull(index)?.let(onRecordRecent)
                            onSongClick(index)
                        },
                        onQueueAdd = onQueueAdd,
                        playlistNames = playlistNames,
                        onAddToPlaylist = onAddToPlaylist
                    )
                    else -> LibraryScreen(
                        title = screen,
                        songs = songs,
                        currentIndex = currentIndex,
                        favoriteIds = favoriteIds,
                        recentIds = recentIds,
                        onSongClick = { index ->
                            songs.getOrNull(index)?.let(onRecordRecent)
                            onSongClick(index)
                        },
                        onNavigate = { navigateTo(it) },
                        onPlaySongList = onPlaySongList,
                        queueSongIndices = queueSongIndices,
                        onQueueRemove = onQueueRemove,
                        onQueueMove = onQueueMove,
                        onQueueClear = onQueueClear,
                        onQueueAdd = onQueueAdd,
                        playlistNames = playlistNames,
                        playlists = playlists,
                        onCreatePlaylist = onCreatePlaylist,
                        onAddToPlaylist = onAddToPlaylist,
                        onRemoveFromPlaylist = onRemoveFromPlaylist
                    )
                }
            }
                if (current != null) {
                    MiniPlayer(current, playing, onPlayPause, { fullPlayer = true }, onPrevious, onNext, positionProvider, durationProvider)
                }
            }

            // On Home, place the controls over the hero image so the artwork remains
            // visible behind the hamburger, title, search and overflow buttons.
            if (screen == "Home") {
                TopBar(
                    title = "",
                    onMenu = { drawer = true },
                    onSearch = { navigateTo("Search") },
                    showOverflow = false
                )
            }
        }

        if (drawer) {
            NavigationDrawer(
                selected = screen,
                onClose = { drawer = false },
                onSelect = { selected ->
                    navigateTo(selected)
                    drawer = false
                }
            )
        }
        if (editInfo && current != null) {
            EditMusicInfoScreen(
                song = current,
                onBack = { editInfo = false },
                onSave = { updated ->
                    onUpdateSong(updated)
                    editInfo = false
                }
            )
        } else if (fullPlayer && current != null) {
            Box(
                Modifier
                    .fillMaxSize()
                    .zIndex(100f)
                    .background(Color(0xFF050607))
            ) {
                FullPlayer(
                    song = current,
                    playing = playing,
                    onBack = { fullPlayer = false },
                    onPlay = onPlayPause,
                    onPrevious = onPrevious,
                    onNext = onNext,
                    positionProvider = positionProvider,
                    durationProvider = durationProvider,
                    onSeekTo = onSeekTo,
                    shuffleEnabled = shuffleEnabled,
                    repeatMode = repeatMode,
                    onToggleShuffle = onToggleShuffle,
                    onCycleRepeat = onCycleRepeat,
                    isFavorite = current.id.toString() in favoriteIds,
                    onToggleFavorite = { onToggleFavorite(current) },
                    playlistNames = playlistNames,
                    onAddToPlaylist = { name, song -> onAddToPlaylist(name, song) },
                    onEditInfo = { editInfo = true },
                    sleepTimerMinutes = sleepTimerMinutes,
                    onSetSleepTimer = { sleepTimerMinutes = it },
                    onNavigate = { target -> navigateTo(target) }
                )
            }
        }
    }
}


@Composable
private fun HomeHero(song: MusicSong?, pull: Float, onOpenPlayer: () -> Unit) {
    val scale = 1f + (pull / 720f).coerceIn(0f, 0.34f)
    Box(
        Modifier
            .fillMaxWidth()
            .height(300.dp)
            .graphicsLayer {
                // Keep the top edge of the artwork anchored while pulling down.
                // This prevents the upper part of the artist/album image from
                // being pushed behind the top edge as the image expands.
                transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 0f)
                scaleX = scale
                scaleY = scale
                translationY = pull * 0.08f
            }
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(
                Brush.verticalGradient(
                    0f to Color.Black.copy(alpha = .10f),
                    0.48f to LocalAccentColor.current.copy(alpha = .18f),
                    0.78f to Color(0xFF101419).copy(alpha = .76f),
                    1f to Color(0xFF08090B)
                )
            )
            .clickable(enabled = song != null, onClick = onOpenPlayer)
    ) {
        ArtworkImage(song, Modifier.fillMaxSize(), ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(
            listOf(Color.Black.copy(alpha = .08f), Color.Black.copy(alpha = .18f), Color.Black.copy(alpha = .58f))
        )))
        Column(
            Modifier.fillMaxSize().padding(start = 24.dp, end = 24.dp, bottom = 22.dp, top = 18.dp),
            verticalArrangement = Arrangement.Bottom
        ) {
            Text(
                "NOW PLAYING",
                color = Color.White.copy(alpha = 0.72f),
                fontSize = 11.sp,
                letterSpacing = 1.5.sp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                song?.artist?.takeIf { it.isNotBlank() } ?: "Your Music",
                color = Color.White,
                fontSize = 29.sp,
                fontWeight = FontWeight.Light,
                maxLines = 1
            )
            Text(
                song?.album?.takeIf { it.isNotBlank() } ?: "Music Library",
                color = Color.White.copy(alpha = 0.78f),
                fontSize = 14.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun TopBar(title: String, onMenu: () -> Unit, onSearch: () -> Unit, showOverflow: Boolean = true) {
    Row(
        // Keep the top controls visually floating over the artist/album image.
        // The image remains visible behind the menu, title, search and overflow areas.
        Modifier.fillMaxWidth().height(64.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onMenu) { Icon(Icons.Default.Menu, null, tint = Color.White) }
        Text(title, color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.weight(1f))
        IconButton(onSearch) { Icon(Icons.Default.Search, null, tint = Color.White) }
        if (showOverflow) {
            IconButton({}) { Icon(Icons.Default.MoreVert, null, tint = Color.White) }
        }
    }
}

@Composable
private fun SearchScreen(
    songs: List<MusicSong>,
    currentIndex: Int,
    onSongClick: (Int) -> Unit,
    onQueueAdd: (Int) -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val normalizedQuery = query.trim()
    val results = remember(normalizedQuery, songs) {
        if (normalizedQuery.isBlank()) emptyList() else songs.filter { song ->
            song.title.contains(normalizedQuery, ignoreCase = true) ||
            song.artist.contains(normalizedQuery, ignoreCase = true) ||
            song.album.contains(normalizedQuery, ignoreCase = true)
        }
    }
    val artistCount = remember(results) {
        results.map { it.artist.trim() }.filter { it.isNotBlank() }.distinct().size
    }
    val albumCount = remember(results) {
        results.map { it.album.trim() }.filter { it.isNotBlank() }.distinct().size
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 12.dp),
            placeholder = { Text("曲名・アーティスト・アルバムを検索") },
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) {
                        Icon(Icons.Default.Clear, "Clear")
                    }
                }
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = LocalAccentColor.current,
                unfocusedBorderColor = Color(0xFF3B4147),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                focusedPlaceholderColor = Color(0xFF777D83),
                unfocusedPlaceholderColor = Color(0xFF777D83),
                focusedLeadingIconColor = LocalAccentColor.current,
                unfocusedLeadingIconColor = Color(0xFF777D83),
                focusedTrailingIconColor = Color(0xFFB0B5BA),
                unfocusedTrailingIconColor = Color(0xFFB0B5BA)
            )
        )

        when {
            normalizedQuery.isBlank() -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 22.dp, vertical = 30.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = null,
                        tint = LocalAccentColor.current.copy(alpha = .75f),
                        modifier = Modifier.size(42.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text("音楽を検索", color = Color.White, fontSize = 18.sp)
                    Spacer(Modifier.height(5.dp))
                    Text(
                        "曲名・アーティスト・アルバムから検索できます",
                        color = Color(0xFF858C93),
                        fontSize = 13.sp
                    )
                }
            }
            results.isEmpty() -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 22.dp, vertical = 34.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.SearchOff,
                        contentDescription = null,
                        tint = Color(0xFF777D83),
                        modifier = Modifier.size(38.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("一致する曲がありません", color = Color.White, fontSize = 17.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("「$normalizedQuery」", color = Color(0xFF858C93), fontSize = 13.sp)
                }
            }
            else -> {
                Column(Modifier.fillMaxSize()) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 22.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "検索結果",
                            color = LocalAccentColor.current,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Light
                        )
                        Spacer(Modifier.weight(1f))
                        Text(
                            "${results.size}曲  •  ${artistCount}アーティスト  •  ${albumCount}アルバム",
                            color = Color(0xFF777D83),
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                    }
                    Text(
                        "${results.size} results",
                        color = Color(0xFF777D83),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 22.dp, vertical = 2.dp)
                    )
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        itemsIndexed(results) { _, song ->
                            val actualIndex = songs.indexOf(song)
                            SongRow(
                                song = song,
                                selected = actualIndex == currentIndex,
                                onAddToQueue = { if (actualIndex >= 0) onQueueAdd(actualIndex) },
                                playlistNames = playlistNames,
                                onAddToPlaylist = onAddToPlaylist
                            ) { if (actualIndex >= 0) onSongClick(actualIndex) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    songs: List<MusicSong>,
    currentIndex: Int,
    current: MusicSong?,
    listState: androidx.compose.foundation.lazy.LazyListState,
    pullConnection: NestedScrollConnection,
    heroPull: Float,
    onHeroOpen: () -> Unit,
    queueSongIndices: List<Int>,
    recentIds: List<String>,
    onNavigate: (String) -> Unit,
    onCycleRepeat: () -> Unit,
    onQueueAdd: (Int) -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit,
    onRecentSongClick: (Int) -> Unit,
    onSongClick: (Int) -> Unit
) {
    val recentSongs = remember(recentIds, songs) {
        recentIds.mapNotNull { id -> songs.firstOrNull { it.id.toString() == id } }
    }
    val newSongs = remember(songs) {
        songs.sortedByDescending { it.dateAdded }.take(9)
    }
    val queueEntries = remember(queueSongIndices, songs) {
        queueSongIndices.mapNotNull { index ->
            songs.getOrNull(index)?.let { index to it }
        }
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .nestedScroll(pullConnection),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            item {
                HomeHero(song = current, pull = heroPull, onOpenPlayer = onHeroOpen)
            }

            item {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(start = 24.dp, end = 18.dp, top = 22.dp, bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "再生待ちリスト",
                        color = Color.White,
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Light,
                        modifier = Modifier.weight(1f)
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(LocalAccentColor.current)
                            .clickable { onNavigate("Play Queue") }
                            .padding(horizontal = 18.dp, vertical = 9.dp)
                    ) {
                        Text("開く", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }

            if (queueEntries.isEmpty()) {
                item {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 18.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF202225))
                            .padding(22.dp)
                    ) {
                        Text("再生待ちの曲はありません", color = Color(0xFF9AA0A6), fontSize = 14.sp)
                    }
                }
            } else {
                item {
                    androidx.compose.foundation.lazy.LazyRow(
                        contentPadding = PaddingValues(horizontal = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        itemsIndexed(queueEntries.take(12)) { _, entry ->
                            val (actualIndex, song) = entry
                            HomeQueueCard(
                                song = song,
                                selected = song.id == current?.id,
                                onClick = { onSongClick(actualIndex) },
                                onAddToQueue = { onQueueAdd(actualIndex) },
                                playlistNames = playlistNames,
                                onAddToPlaylist = onAddToPlaylist
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    "最近再生した曲",
                    color = Color.White,
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Light,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 22.dp)
                )
            }

            if (recentSongs.isEmpty()) {
                item {
                    Text(
                        "最近再生した曲はありません",
                        color = Color(0xFF9AA0A6),
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                    )
                }
            } else {
                item {
                    Column(
                        Modifier.fillMaxWidth().padding(horizontal = 6.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        recentSongs.take(30).chunked(3).forEach { rowSongs ->
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                rowSongs.forEach { song ->
                                    val songIndex = songs.indexOfFirst { it.id == song.id }
                                    HomeRecentCard(
                                        song = song,
                                        onClick = { if (songIndex >= 0) onRecentSongClick(songIndex) },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                                repeat(3 - rowSongs.size) {
                                    Spacer(Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(start = 24.dp, end = 18.dp, top = 22.dp, bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "新規追加",
                        color = Color.White,
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Light,
                        modifier = Modifier.weight(1f)
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF2A2D31))
                            .clickable { onNavigate("Newly Added") }
                            .padding(horizontal = 18.dp, vertical = 9.dp)
                    ) {
                        Text("もっと見る", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }

            item {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    newSongs.chunked(3).forEach { rowSongs ->
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowSongs.forEach { song ->
                                val songIndex = songs.indexOfFirst { it.id == song.id }
                                HomeRecentCard(
                                    song = song,
                                    onClick = { if (songIndex >= 0) onRecentSongClick(songIndex) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            repeat(3 - rowSongs.size) {
                                Spacer(Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }

        // Small floating repeat control, matching the reference layout while
        // keeping the existing repeat functionality available from Home.
        FloatingActionButton(
            onClick = onCycleRepeat,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 18.dp, bottom = 94.dp),
            containerColor = LocalAccentColor.current,
            contentColor = Color.White,
            shape = androidx.compose.foundation.shape.CircleShape
        ) {
            Icon(Icons.Default.Repeat, contentDescription = "Repeat")
        }
    }
}

@Composable
private fun HomeQueueCard(
    song: MusicSong,
    selected: Boolean,
    onClick: () -> Unit,
    onAddToQueue: () -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit
) {
    var menuOpen by remember(song.id) { mutableStateOf(false) }
    Column(
        Modifier
            .width(112.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFF292A2C))
            .clickable(onClick = onClick)
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f)) {
            AlbumArt(song = song, size = 112.dp, modifier = Modifier.fillMaxSize())
            if (selected) {
                Box(
                    Modifier
                        .align(Alignment.BottomStart)
                        .padding(10.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Black.copy(alpha = .65f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(Icons.Default.Pause, null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(start = 11.dp, top = 9.dp, bottom = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    song.title.ifBlank { "Unknown title" },
                    color = Color.White,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
                Text(
                    song.artist.ifBlank { "Unknown artist" },
                    color = Color(0xFF9AA0A6),
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
            }
            Box {
                IconButton(
                    onClick = { menuOpen = true },
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        Icons.Default.MoreVert,
                        "More",
                        tint = Color(0xFF858A90),
                        modifier = Modifier.size(21.dp)
                    )
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("Add to Play Queue") },
                        leadingIcon = { Icon(Icons.Default.QueueMusic, null) },
                        onClick = { menuOpen = false; onAddToQueue() }
                    )
                    playlistNames.forEach { name ->
                        DropdownMenuItem(
                            text = { Text("Add to $name") },
                            leadingIcon = { Icon(Icons.Default.PlaylistAdd, null) },
                            onClick = { menuOpen = false; onAddToPlaylist(name, song) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeRecentCard(
    song: MusicSong,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier
            .clip(RoundedCornerShape(3.dp))
            .background(Color(0xFF292A2C))
            .clickable(onClick = onClick)
    ) {
        ArtworkImage(
            song = song,
            modifier = Modifier.fillMaxWidth().aspectRatio(1f),
            contentScale = ContentScale.Crop
        )
        Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text(song.title.ifBlank { "Unknown title" }, color = Color.White, fontSize = 15.sp, maxLines = 1)
            Text(song.artist.ifBlank { "Unknown artist" }, color = Color(0xFF9AA0A6), fontSize = 12.sp, maxLines = 1)
        }
    }
}

@Composable
private fun FolderBrowserScreen(
    songs: List<MusicSong>,
    onSongClick: (Int) -> Unit,
    onPlayFolder: (List<Int>) -> Unit,
    onExit: () -> Unit,
    onQueueAdd: (Int) -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit
) {
    var currentPath by remember { mutableStateOf<String?>(null) }

    BackHandler {
        if (currentPath != null) currentPath = null else onExit()
    }

    fun folderKey(song: MusicSong): String {
        return song.folderPath.trimEnd('/').ifBlank { "__UNKNOWN__" }
    }

    fun folderName(path: String): String {
        if (path == "__UNKNOWN__") return "その他"
        return path.substringAfterLast('/').ifBlank { path }
    }

    val folders = remember(songs) {
        songs.groupBy { folderKey(it) }
            .mapValues { it.value.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { s -> s.title }) }
            .toList()
            .sortedBy { folderName(it.first).lowercase() }
    }

    val visibleSongs = remember(songs, currentPath) {
        currentPath?.let { path -> songs.filter { folderKey(it) == path } } ?: emptyList()
    }

    val title = currentPath?.let { folderName(it) } ?: "フォルダ"
    val subtitle = if (currentPath == null) {
        "端末内の音楽フォルダ"
    } else {
        "${visibleSongs.size}曲"
    }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
            Text(title, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Light, maxLines = 2)
            Text(subtitle, color = Color(0xFF777D83), fontSize = 12.sp, maxLines = 1)
            if (visibleSongs.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val indices = visibleSongs.mapNotNull { song ->
                            songs.indexOfFirst { it.id == song.id }.takeIf { it >= 0 }
                        }
                        onPlayFolder(indices)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LocalAccentColor.current),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(5.dp))
                    Text("このフォルダを再生")
                }
            }
        }

        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            if (currentPath == null) {
                itemsIndexed(folders) { _, item ->
                    val (path, folderSongs) = item
                    Row(
                        Modifier.fillMaxWidth()
                            .clickable { currentPath = path }
                            .padding(horizontal = 18.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val folderArtworks = remember(folderSongs) {
                            folderSongs.distinctBy { it.artworkUriString ?: it.album.ifBlank { it.id.toString() } }.take(4)
                        }
                        FolderArtworkCollage(
                            songs = folderArtworks,
                            modifier = Modifier.size(58.dp)
                        )
                        Column(Modifier.weight(1f).padding(start = 15.dp)) {
                            Text(folderName(path), color = Color.White, fontSize = 16.sp, maxLines = 1)
                            Text("${folderSongs.size}曲", color = Color(0xFF8F969D), fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null, tint = Color(0xFF777D83))
                    }
                    HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
                }
            } else {
                itemsIndexed(visibleSongs) { _, song ->
                    val index = songs.indexOfFirst { it.id == song.id }
                    if (index >= 0) {
                        SongRow(
                            song = song,
                            selected = false,
                            onAddToQueue = { onQueueAdd(index) },
                            playlistNames = playlistNames,
                            onAddToPlaylist = onAddToPlaylist,
                            onClick = { onSongClick(index) }
                        )
                    }
                }
            }

            if (folders.isEmpty() && currentPath == null) {
                item {
                    Text(
                        "音楽フォルダが見つかりません",
                        color = Color(0xFF8F969D),
                        modifier = Modifier.padding(22.dp)
                    )
                }
            }
            if (visibleSongs.isEmpty() && currentPath != null) {
                item {
                    Text(
                        "このフォルダに音楽ファイルはありません",
                        color = Color(0xFF8F969D),
                        modifier = Modifier.padding(22.dp)
                    )
                }
            }
        }
    }
}


@Composable
private fun FolderArtworkCollage(
    songs: List<MusicSong>,
    modifier: Modifier = Modifier
) {
    val gap = 1.dp
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(LocalAccentColor.current.copy(alpha = .18f))
    ) {
        when (songs.size) {
            0 -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Folder, null, tint = LocalAccentColor.current, modifier = Modifier.size(28.dp))
            }
            1 -> FolderArtworkTile(songs[0], Modifier.fillMaxSize())
            2 -> Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                FolderArtworkTile(songs[0], Modifier.weight(1f).fillMaxHeight())
                FolderArtworkTile(songs[1], Modifier.weight(1f).fillMaxHeight())
            }
            3 -> Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                FolderArtworkTile(songs[0], Modifier.weight(1f).fillMaxHeight())
                Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(gap)) {
                    FolderArtworkTile(songs[1], Modifier.weight(1f).fillMaxWidth())
                    FolderArtworkTile(songs[2], Modifier.weight(1f).fillMaxWidth())
                }
            }
            else -> Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(gap)) {
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                    FolderArtworkTile(songs[0], Modifier.weight(1f).fillMaxHeight())
                    FolderArtworkTile(songs[1], Modifier.weight(1f).fillMaxHeight())
                }
                Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
                    FolderArtworkTile(songs[2], Modifier.weight(1f).fillMaxHeight())
                    FolderArtworkTile(songs[3], Modifier.weight(1f).fillMaxHeight())
                }
            }
        }
    }
}

@Composable
private fun FolderArtworkTile(song: MusicSong, modifier: Modifier = Modifier) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("pixelmusic_artwork", android.content.Context.MODE_PRIVATE) }
    val overridePath = remember(song.id) { prefs.getString("art_${song.id}", null) }
    val density = androidx.compose.ui.platform.LocalDensity.current.density
    val targetPx = (96f * density).roundToInt().coerceIn(96, 512)
    val bitmap = rememberArtworkBitmap(song, overridePath, targetPx)
    Box(
        modifier = modifier.background(Color(0xFF252A30)),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = song.album.ifBlank { song.title },
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Icon(Icons.Default.MusicNote, null, tint = Color.White.copy(alpha = .78f), modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun LibraryScreen(
    title: String,
    songs: List<MusicSong>,
    currentIndex: Int,
    favoriteIds: Set<String>,
    recentIds: List<String>,
    onSongClick: (Int) -> Unit,
    onNavigate: (String) -> Unit,
    onPlaySongList: (List<Int>) -> Unit,
    queueSongIndices: List<Int>,
    onQueueRemove: (Int) -> Unit,
    onQueueMove: (Int, Int) -> Unit,
    onQueueClear: () -> Unit,
    onQueueAdd: (Int) -> Unit,
    playlistNames: List<String>,
    playlists: Map<String, Set<String>>,
    onCreatePlaylist: (String) -> Unit,
    onAddToPlaylist: (String, MusicSong) -> Unit,
    onRemoveFromPlaylist: (String, MusicSong) -> Unit
) {
    val visibleSongs = remember(title, songs, favoriteIds, recentIds, playlists) {
        when {
            title == "Favorites" -> songs.filter { it.id.toString() in favoriteIds }
            title == "Recently Played" -> recentIds.mapNotNull { id -> songs.firstOrNull { it.id.toString() == id } }
            title.startsWith("Playlist::") -> {
                val name = title.removePrefix("Playlist::")
                playlists[name].orEmpty().mapNotNull { id -> songs.firstOrNull { it.id.toString() == id } }
            }
            title.startsWith("Artist::") -> {
                val name = title.removePrefix("Artist::")
                songs.filter { it.artist.ifBlank { "Unknown Artist" } == name }
            }
            title.startsWith("Album::") -> {
                val name = title.removePrefix("Album::")
                songs.filter { it.album.ifBlank { "Unknown Album" } == name }
            }
            else -> songs
        }
    }
    var showCreateDialog by remember { mutableStateOf(false) }
    var playlistNameInput by remember { mutableStateOf("") }

    val groups = remember(title, songs) {
        when (title) {
            "Artists" -> songs.groupBy { it.artist.ifBlank { "Unknown Artist" } }
            "Albums" -> songs.groupBy { it.album.ifBlank { "Unknown Album" } }
            else -> emptyMap()
        }
    }

    Column(Modifier.fillMaxSize()) {
        if (title == "Newly Added") {
            Column(Modifier.fillMaxSize()) {
                Text(
                    "新規追加",
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Light,
                    modifier = Modifier.padding(horizontal = 22.dp, vertical = 18.dp)
                )
                Text(
                    "追加された順",
                    color = Color(0xFF777D83),
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 22.dp, vertical = 2.dp)
                )
                Spacer(Modifier.height(10.dp))
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    itemsIndexed(visibleSongs) { _, song ->
                        val index = songs.indexOfFirst { it.id == song.id }
                        SongRow(
                            song = song,
                            selected = song.id == songs.getOrNull(currentIndex)?.id,
                            onAddToQueue = { if (index >= 0) onQueueAdd(index) },
                            playlistNames = playlistNames,
                            onAddToPlaylist = onAddToPlaylist,
                            onClick = { if (index >= 0) onSongClick(index) }
                        )
                    }
                }
            }
        } else if (title.startsWith("Artist::") || title.startsWith("Album::")) {
            val detailTitle = when {
                title.startsWith("Artist::") -> title.removePrefix("Artist::")
                else -> title.removePrefix("Album::")
            }
            val headerSong = visibleSongs.firstOrNull()
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (headerSong != null) {
                    AlbumArt(song = headerSong, size = 168.dp)
                    Spacer(Modifier.height(14.dp))
                }
                Text(
                    detailTitle,
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Light,
                    maxLines = 2
                )
                Text(
                    "${visibleSongs.size}曲",
                    color = Color(0xFF777D83),
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
                if (headerSong != null) {
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val firstIndex = songs.indexOf(headerSong)
                            if (firstIndex >= 0) onSongClick(firstIndex)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LocalAccentColor.current)
                    ) {
                        Icon(Icons.Default.PlayArrow, null)
                        Spacer(Modifier.width(6.dp))
                        Text("再生")
                    }
                }
            }
        } else if (title.startsWith("Playlist::")) {
            val playlistTitle = title.removePrefix("Playlist::")
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(64.dp).clip(RoundedCornerShape(10.dp))
                            .background(LocalAccentColor.current.copy(alpha = .18f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.QueueMusic,
                            contentDescription = null,
                            tint = LocalAccentColor.current,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Column(Modifier.padding(start = 16.dp).weight(1f)) {
                        Text(
                            playlistTitle,
                            color = Color.White,
                            fontSize = 27.sp,
                            fontWeight = FontWeight.Light,
                            maxLines = 2
                        )
                        Text(
                            "${visibleSongs.size}曲",
                            color = Color(0xFF777D83),
                            fontSize = 13.sp,
                            modifier = Modifier.padding(top = 3.dp)
                        )
                    }
                    IconButton(
                        onClick = {
                            val indices = visibleSongs.mapNotNull { song ->
                                val index = songs.indexOfFirst { it.id == song.id }
                                index.takeIf { it >= 0 }
                            }
                            if (indices.isNotEmpty()) onPlaySongList(indices)
                        },
                        enabled = visibleSongs.isNotEmpty()
                    ) {
                        Icon(
                            Icons.Default.PlayCircleFilled,
                            contentDescription = "再生",
                            tint = if (visibleSongs.isNotEmpty()) LocalAccentColor.current else Color(0xFF555A60),
                            modifier = Modifier.size(44.dp)
                        )
                    }
                }
            }
        } else {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    title,
                    color = Color.White,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Light
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    if (title == "Artists" || title == "Albums") "${groups.size}" else "${visibleSongs.size}",
                    color = Color(0xFF777D83),
                    fontSize = 13.sp,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }
        }

        if (visibleSongs.isEmpty() && title != "Play Queue" && title != "Playlists") {
            EmptyMessage(
                when {
                    title == "Favorites" -> "お気に入りはまだありません"
                    title == "Recently Played" -> "最近再生した曲はありません"
                    title.startsWith("Playlist::") -> "このプレイリストには曲がありません"
                    title.startsWith("Artist::") -> "このアーティストには曲がありません"
                    title.startsWith("Album::") -> "このアルバムには曲がありません"
                    else -> "音楽ファイルが見つかりません"
                }
            )
        } else {
            when {
                title.startsWith("Artist::") || title.startsWith("Album::") -> {
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        itemsIndexed(visibleSongs) { _, song ->
                            val actualIndex = songs.indexOf(song)
                            SongRow(
                                song = song,
                                selected = actualIndex == currentIndex,
                                onAddToQueue = { if (actualIndex >= 0) onQueueAdd(actualIndex) },
                                playlistNames = playlistNames,
                                onAddToPlaylist = onAddToPlaylist
                            ) { if (actualIndex >= 0) onSongClick(actualIndex) }
                        }
                    }
                }
                title.startsWith("Playlist::") -> {
                    val playlistName = title.removePrefix("Playlist::")
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        itemsIndexed(visibleSongs) { _, song ->
                            val actualIndex = songs.indexOf(song)
                            SongRow(
                                song = song,
                                selected = actualIndex == currentIndex,
                                onAddToQueue = { if (actualIndex >= 0) onQueueAdd(actualIndex) },
                                playlistNames = emptyList(),
                                onAddToPlaylist = { _, _ -> },
                                onRemoveFromPlaylist = { onRemoveFromPlaylist(playlistName, song) },
                                showRemoveFromPlaylist = true
                            ) { if (actualIndex >= 0) onSongClick(actualIndex) }
                        }
                    }
                }
                title == "Favorites" || title == "Recently Played" -> {
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        itemsIndexed(visibleSongs) { _, song ->
                            val actualIndex = songs.indexOf(song)
                            SongRow(
                                song = song,
                                selected = actualIndex == currentIndex,
                                onAddToQueue = { if (actualIndex >= 0) onQueueAdd(actualIndex) },
                                playlistNames = playlistNames,
                                onAddToPlaylist = onAddToPlaylist
                            ) { if (actualIndex >= 0) onSongClick(actualIndex) }
                        }
                    }
                }
                title == "Play Queue" -> {
                    val queueSongs = queueSongIndices.mapNotNull { songs.getOrNull(it) }
                    Column(Modifier.fillMaxSize()) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${queueSongs.size} songs", color = Color(0xFF858C93), fontSize = 13.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = onQueueClear, enabled = queueSongs.isNotEmpty()) {
                                Text("Clear", color = if (queueSongs.isNotEmpty()) LocalAccentColor.current else Color(0xFF555A60))
                            }
                        }
                        LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                            itemsIndexed(queueSongs) { index, song ->
                                val actualIndex = queueSongIndices.getOrNull(index) ?: -1
                                QueueSongRow(
                                    song = song,
                                    position = index + 1,
                                    selected = actualIndex == currentIndex,
                                    onClick = { if (actualIndex >= 0) onSongClick(actualIndex) },
                                    onRemove = { onQueueRemove(index) },
                                    onMoveUp = { if (index > 0) onQueueMove(index, index - 1) },
                                    onMoveDown = { if (index < queueSongs.lastIndex) onQueueMove(index, index + 1) }
                                )
                            }
                        }
                    }
                }
                title == "Playlists" -> {
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        item {
                            PlaylistRow("Favorites", "Your favorite songs", favoriteIds.size, Icons.Default.Favorite) { onNavigate("Favorites") }
                        }
                        item {
                            PlaylistRow("Recently Played", "Songs played on this device", recentIds.size, Icons.Default.History) { onNavigate("Recently Played") }
                        }
                        playlistNames.forEach { playlistName ->
                            item(key = "playlist_$playlistName") {
                                PlaylistRow(
                                    playlistName,
                                    "Custom playlist",
                                    playlists[playlistName].orEmpty().size,
                                    Icons.Default.QueueMusic
                                ) { onNavigate("Playlist::$playlistName") }
                            }
                        }
                        item {
                            PlaylistRow("New Playlist", "Create a playlist", null, Icons.Default.Add) { showCreateDialog = true }
                        }
                    }
                }
                title == "Artists" || title == "Albums" -> {
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        groups.entries.forEach { (name, groupedSongs) ->
                            item(key = name) {
                                LibraryGroupRow(
                                    title = name,
                                    subtitle = "${groupedSongs.size} ${if (title == "Artists") "songs" else "tracks"}",
                                    isArtist = title == "Artists",
                                    seed = groupedSongs.firstOrNull()?.title?.hashCode()?.let { kotlin.math.abs(it) } ?: 0
                                ) {
                                    onNavigate("${if (title == "Artists") "Artist::" else "Album::"}$name")
                                }
                            }
                        }
                    }
                }
                title == "Songs" -> {
                    LazyColumn(contentPadding = PaddingValues(bottom = 16.dp)) {
                        itemsIndexed(songs) { index, song ->
                            SongRow(
                                song = song,
                                selected = index == currentIndex,
                                onAddToQueue = { onQueueAdd(index) },
                                playlistNames = playlistNames,
                                onAddToPlaylist = onAddToPlaylist
                            ) { onSongClick(index) }
                        }
                    }
                }
                else -> SectionPlaceholder(title)
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false; playlistNameInput = "" },
            title = { Text("New Playlist") },
            text = {
                OutlinedTextField(
                    value = playlistNameInput,
                    onValueChange = { playlistNameInput = it },
                    label = { Text("Playlist name") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        onCreatePlaylist(playlistNameInput)
                        showCreateDialog = false
                        playlistNameInput = ""
                    },
                    enabled = playlistNameInput.trim().isNotBlank() && !playlistNames.contains(playlistNameInput.trim())
                ) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false; playlistNameInput = "" }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun QueueSongRow(
    song: MusicSong,
    position: Int,
    selected: Boolean,
    onClick: () -> Unit,
    onRemove: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            position.toString(),
            color = if (selected) LocalAccentColor.current else Color(0xFF70767C),
            fontSize = 12.sp,
            modifier = Modifier.width(28.dp)
        )
        AlbumArt(song = song, size = 50.dp)
        Column(Modifier.weight(1f).padding(start = 14.dp)) {
            Text(song.title, color = if (selected) LocalAccentColor.current else Color.White, maxLines = 1, fontSize = 15.sp)
            Text(song.artist, color = Color(0xFF9AA0A6), fontSize = 12.sp, maxLines = 1)
        }
        if (selected) {
            Icon(Icons.Default.GraphicEq, null, tint = LocalAccentColor.current)
        } else {
            Row {
                IconButton(onClick = onMoveUp, enabled = true) { Icon(Icons.Default.KeyboardArrowUp, null, tint = Color(0xFF777D83)) }
                IconButton(onClick = onMoveDown, enabled = true) { Icon(Icons.Default.KeyboardArrowDown, null, tint = Color(0xFF777D83)) }
                IconButton(onClick = onRemove) { Icon(Icons.Default.Close, null, tint = Color(0xFF999FA5)) }
            }
        }
    }
    HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
}

@Composable
private fun PlaylistRow(
    title: String,
    subtitle: String,
    count: Int?,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(58.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF20262C)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = LocalAccentColor.current, modifier = Modifier.size(28.dp))
        }
        Column(Modifier.weight(1f).padding(start = 16.dp)) {
            Text(title, color = Color.White, fontSize = 17.sp)
            Text(
                if (count == null) subtitle else "$subtitle • $count songs",
                color = Color(0xFF8F969D),
                fontSize = 13.sp,
                maxLines = 1
            )
        }
        Icon(Icons.Default.ChevronRight, null, tint = Color(0xFF777D83))
    }
    HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
}

@Composable
private fun LibraryGroupRow(title: String, subtitle: String, isArtist: Boolean, seed: Int, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (isArtist) ArtistArt(62.dp, seed) else AlbumArt(size = 62.dp)
        Column(Modifier.weight(1f).padding(start = 16.dp)) {
            Text(title, color = Color.White, fontSize = 17.sp, maxLines = 1)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, color = Color(0xFF8F969D), fontSize = 13.sp, maxLines = 1)
        }
        Icon(if (isArtist) Icons.Default.ChevronRight else Icons.Default.MoreVert, null, tint = Color(0xFF777D83))
    }
    HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
}

@Composable
private fun ArtistArt(size: Dp, seed: Int) {
    val palettes = listOf(
        listOf(Color(0xFF536778), Color(0xFF17212A)),
        listOf(Color(0xFF744C5C), Color(0xFF20151C)),
        listOf(Color(0xFF5B704E), Color(0xFF182017)),
        listOf(Color(0xFF6B5A82), Color(0xFF211B2B))
    )
    val palette = palettes[seed % palettes.size]
    Box(Modifier.size(size).clip(RoundedCornerShape(50)).background(Brush.linearGradient(palette)), contentAlignment = Alignment.Center) {
        Icon(Icons.Default.Person, null, tint = Color.White.copy(alpha = .82f), modifier = Modifier.size(size * .48f))
    }
}

@Composable
private fun SettingsScreen(
    selectedTheme: AppTheme,
    onThemeChange: (AppTheme) -> Unit
) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        item {
            Spacer(Modifier.height(18.dp))
            Text("Theme", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            Text("テーマカラー", color = Color(0xFF8F969D), fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
        }
        itemsIndexed(AppTheme.values().toList()) { _, theme ->
            val selected = theme == selectedTheme
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                    .background(if (selected) theme.accent.copy(alpha = .16f) else Color.Transparent)
                    .clickable { onThemeChange(theme) }
                    .padding(horizontal = 14.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(30.dp).clip(RoundedCornerShape(50)).background(theme.accent))
                Column(Modifier.weight(1f).padding(start = 14.dp)) {
                    Text(theme.label, color = Color.White, fontSize = 16.sp)
                    Text(theme.description, color = Color(0xFF8F969D), fontSize = 12.sp)
                }
                if (selected) Icon(Icons.Default.Check, null, tint = theme.accent)
            }
            Spacer(Modifier.height(5.dp))
        }
        item { Spacer(Modifier.height(20.dp)) }
    }
}

@Composable
private fun SectionPlaceholder(title: String) {
    Column(Modifier.fillMaxWidth().padding(22.dp)) {
        Text(
            when (title) {
                "Play Queue" -> "再生キュー"
                "Playlists" -> "プレイリスト"
                "Folders" -> "フォルダ"
                "Google Drive" -> "Google Drive"
                "New Releases" -> "新着リリース"
                "Charts" -> "チャート"
                "Settings" -> "設定"
                else -> title
            },
            color = Color.White,
            fontSize = 18.sp
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "この画面の詳細UIは次の段階で実装します。",
            color = Color(0xFF858C93),
            fontSize = 13.sp
        )
    }
}

@Composable
private fun EmptyMessage(message: String) {
    Text(
        message,
        color = Color(0xFF9AA0A6),
        modifier = Modifier.padding(horizontal = 22.dp)
    )
}

@Composable
private fun SongRow(
    song: MusicSong,
    selected: Boolean,
    onAddToQueue: () -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit,
    onRemoveFromPlaylist: () -> Unit = {},
    showRemoveFromPlaylist: Boolean = false,
    onClick: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AlbumArt(song = song, size = 56.dp)
            Column(Modifier.weight(1f).padding(start = 16.dp)) {
                Text(song.title.ifBlank { "Unknown title" }, color = if (selected) LocalAccentColor.current else Color.White, maxLines = 1, fontSize = 16.sp)
                Text(listOf(song.artist, song.album).filter { it.isNotBlank() }.joinToString(" • "), color = Color(0xFF9AA0A6), fontSize = 13.sp, maxLines = 1)
            }
            if (selected && song.title.isNotBlank()) {
                Icon(Icons.Default.GraphicEq, null, tint = LocalAccentColor.current)
            } else {
                Box {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.MoreVert, "More", tint = Color(0xFF777B80))
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("Add to Play Queue") },
                            leadingIcon = { Icon(Icons.Default.QueueMusic, null) },
                            onClick = {
                                menuOpen = false
                                onAddToQueue()
                            }
                        )
                        playlistNames.forEach { playlistName ->
                            DropdownMenuItem(
                                text = { Text("Add to $playlistName") },
                                leadingIcon = { Icon(Icons.Default.PlaylistAdd, null) },
                                onClick = {
                                    menuOpen = false
                                    onAddToPlaylist(playlistName, song)
                                }
                            )
                        }
                        if (playlistNames.isEmpty()) {
                            DropdownMenuItem(
                                text = { Text("No custom playlists yet") },
                                enabled = false,
                                onClick = { }
                            )
                        }
                        if (showRemoveFromPlaylist) {
                            DropdownMenuItem(
                                text = { Text("Remove from Playlist") },
                                leadingIcon = { Icon(Icons.Default.RemoveCircleOutline, null) },
                                onClick = {
                                    menuOpen = false
                                    onRemoveFromPlaylist()
                                }
                            )
                        }
                    }
                }
            }
        }
        HorizontalDivider(color = Color.White.copy(alpha = .055f), thickness = 1.dp)
    }
}

private object ArtworkBitmapCache {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    @Synchronized
    fun get(key: String): Bitmap? = cache.get(key)

    @Synchronized
    fun put(key: String, bitmap: Bitmap): Bitmap {
        cache.put(key, bitmap)
        return bitmap
    }
}

private val artworkLoadSemaphore = Semaphore(2)

private fun artworkCacheKey(song: MusicSong, overridePath: String?, targetPx: Int): String {
    val source = overridePath?.takeIf { it.isNotBlank() } ?: song.artworkUriString ?: song.uriString
    return "$source|${targetPx.coerceAtLeast(64)}"
}

private fun calculateSampleSize(width: Int, height: Int, targetPx: Int): Int {
    val target = targetPx.coerceAtLeast(64)
    var sample = 1
    while (width / sample > target * 2 || height / sample > target * 2) {
        sample *= 2
    }
    return sample
}

private fun decodeSampledFile(path: String, targetPx: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    val options = BitmapFactory.Options().apply {
        inSampleSize = calculateSampleSize(bounds.outWidth, bounds.outHeight, targetPx)
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    return BitmapFactory.decodeFile(path, options)
}

private fun decodeSampledBytes(bytes: ByteArray, targetPx: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    val options = BitmapFactory.Options().apply {
        inSampleSize = calculateSampleSize(bounds.outWidth, bounds.outHeight, targetPx)
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
}

private suspend fun loadArtworkBitmap(
    context: android.content.Context,
    song: MusicSong,
    overridePath: String?,
    targetPx: Int
): Bitmap? = withContext(Dispatchers.IO) {
    val key = artworkCacheKey(song, overridePath, targetPx)
    ArtworkBitmapCache.get(key)?.let { return@withContext it }

    artworkLoadSemaphore.withPermit {
        ArtworkBitmapCache.get(key)?.let { return@withPermit it }
        val bitmap = runCatching {
            // 1) User-selected artwork saved by the edit screen.
            if (!overridePath.isNullOrBlank() && File(overridePath).exists()) {
                decodeSampledFile(overridePath, targetPx)
            } else {
                // 2) MediaStore album artwork URI.
                var result: Bitmap? = null
                song.artworkUriString?.let { artworkUriString ->
                    result = runCatching {
                        context.contentResolver.openInputStream(Uri.parse(artworkUriString))?.use { input ->
                            input.readBytes().let { bytes -> decodeSampledBytes(bytes, targetPx) }
                        }
                    }.getOrNull()
                }

                // 3) Embedded artwork inside the audio file as a fallback.
                if (result == null) {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(context, Uri.parse(song.uriString))
                        retriever.embeddedPicture?.let { bytes ->
                            result = decodeSampledBytes(bytes, targetPx)
                        }
                    } finally {
                        retriever.release()
                    }
                }
                result
            }
        }.getOrNull()

        bitmap?.let { ArtworkBitmapCache.put(key, it) }
        bitmap
    }
}

@Composable
private fun rememberArtworkBitmap(song: MusicSong?, overridePath: String?, targetPx: Int): Bitmap? {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(song?.uriString, song?.artworkUriString, overridePath, targetPx) {
        mutableStateOf<Bitmap?>(null)
    }
    LaunchedEffect(song?.uriString, song?.artworkUriString, overridePath, targetPx) {
        bitmap = null
        if (song != null) {
            bitmap = loadArtworkBitmap(
                context = context,
                song = song,
                overridePath = overridePath,
                targetPx = targetPx
            )
        }
    }
    return bitmap
}

@Composable
private fun ArtworkImage(song: MusicSong?, modifier: Modifier, contentScale: ContentScale) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("pixelmusic_artwork", android.content.Context.MODE_PRIVATE) }
    val overridePath = song?.id?.let { prefs.getString("art_$it", null) }
    val density = androidx.compose.ui.platform.LocalDensity.current.density
    val targetPx = (420f * density).roundToInt().coerceAtMost(1024)
    val bitmap = rememberArtworkBitmap(song, overridePath, targetPx)

    Box(modifier.background(Brush.verticalGradient(listOf(LocalAccentColor.current.copy(alpha=.55f), Color(0xFF101419))))) {
        bitmap?.let {
            Image(bitmap = it.asImageBitmap(), contentDescription = song?.album ?: "Album artwork", modifier = Modifier.fillMaxSize(), contentScale = contentScale)
        }
    }
}

@Composable
private fun AlbumArt(
    song: MusicSong? = null,
    size: Dp,
    modifier: Modifier = Modifier,
    showFallback: Boolean = true
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("pixelmusic_artwork", android.content.Context.MODE_PRIVATE) }
    val overridePath = song?.id?.let { prefs.getString("art_$it", null) }
    val density = androidx.compose.ui.platform.LocalDensity.current.density
    val targetPx = (size.value * density).roundToInt().coerceAtLeast(96).coerceAtMost(1024)
    val bitmap = rememberArtworkBitmap(song, overridePath, targetPx)

    Box(
        modifier
            .then(Modifier.size(size))
            .clip(RoundedCornerShape(7.dp))
            .background(
                Brush.linearGradient(
                    listOf(LocalAccentColor.current.copy(alpha = .88f), Color(0xFF11151A), Color(0xFF20252B))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = song?.album ?: "Album artwork",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .08f)))
        } else if (showFallback) {
            Icon(Icons.Default.MusicNote, null, tint = Color.White.copy(alpha = .82f), modifier = Modifier.size(size * .43f))
        }
    }
}

@Composable
private fun MiniPlayer(
    song: MusicSong,
    playing: Boolean,
    onPlay: () -> Unit,
    onOpen: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long
) {
    var positionMs by remember(song.uriString) { mutableLongStateOf(positionProvider().coerceAtLeast(0L)) }
    var durationMs by remember(song.uriString) { mutableLongStateOf(durationProvider().coerceAtLeast(song.duration)) }

    LaunchedEffect(playing, song.uriString) {
        while (true) {
            positionMs = positionProvider().coerceAtLeast(0L)
            val latestDuration = durationProvider().coerceAtLeast(0L)
            if (latestDuration > 0L) durationMs = latestDuration
            if (!playing) break
            delay(500L)
        }
    }

    val progress = if (durationMs > 0L) (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f

    Column(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFF111418))
            .clickable(onClick = onOpen)
    ) {
        // Xperia-like thin progress indicator at the very top.
        Box(Modifier.fillMaxWidth().height(3.dp).background(Color.White.copy(alpha = .10f))) {
            Box(
                Modifier
                    .fillMaxWidth(progress)
                    .fillMaxHeight()
                    .background(LocalAccentColor.current)
            )
        }

        Row(
            Modifier
                .fillMaxWidth()
                .height(76.dp)
                .padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AlbumArt(song = song, size = 54.dp)

            Column(
                Modifier
                    .weight(1f)
                    .padding(start = 12.dp, end = 4.dp)
            ) {
                Text(
                    song.title,
                    color = Color.White,
                    maxLines = 1,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    song.artist,
                    color = Color(0xFF9AA0A6),
                    fontSize = 12.sp,
                    maxLines = 1
                )
                Text(
                    song.album,
                    color = Color(0xFF6F757B),
                    fontSize = 10.sp,
                    maxLines = 1
                )
            }

            IconButton(
                onClick = onPrevious,
                modifier = Modifier.size(42.dp)
            ) {
                Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(23.dp))
            }
            IconButton(
                onClick = onPlay,
                modifier = Modifier.size(46.dp)
            ) {
                Icon(
                    if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                    if (playing) "Pause" else "Play",
                    tint = LocalAccentColor.current,
                    modifier = Modifier.size(28.dp)
                )
            }
            IconButton(
                onClick = onNext,
                modifier = Modifier.size(42.dp)
            ) {
                Icon(Icons.Default.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(23.dp))
            }
        }
    }
}

@Composable
private fun NavigationDrawer(
    selected: String,
    onClose: () -> Unit,
    onSelect: (String) -> Unit
) {
    Row(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .width(300.dp)
                .fillMaxHeight()
                .background(Color(0xFF121417))
                .padding(top = 32.dp)
        ) {
            Text(
                "PIXEL MUSIC",
                color = LocalAccentColor.current,
                fontSize = 22.sp,
                fontWeight = FontWeight.Light,
                modifier = Modifier.padding(24.dp)
            )
            listOf(
                "Home", "Play Queue", "Playlists", "Artists", "Albums", "Songs",
                "Genres", "Folders", "Google Drive", "New Releases", "Charts", "Settings"
            ).forEach { item ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onSelect(item) }
                        .background(
                            if (item == selected) LocalAccentColor.current.copy(alpha = .16f) else Color.Transparent
                        )
                        .padding(horizontal = 24.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        item,
                        color = if (item == selected) LocalAccentColor.current else Color(0xFFE2E5E8),
                        fontSize = 15.sp
                    )
                }
            }
        }
        Spacer(
            Modifier
                .fillMaxSize()
                .weight(1f)
                .background(Color.Black.copy(alpha = .55f))
                .clickable(onClick = onClose)
        )
    }
}

@Composable
private fun FullPlayer(
    song: MusicSong,
    playing: Boolean,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    positionProvider: () -> Long,
    durationProvider: () -> Long,
    onSeekTo: (Long) -> Unit,
    shuffleEnabled: Boolean,
    repeatMode: Int,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    playlistNames: List<String>,
    onAddToPlaylist: (String, MusicSong) -> Unit,
    onEditInfo: () -> Unit,
    sleepTimerMinutes: Int? = null,
    onSetSleepTimer: (Int?) -> Unit = {},
    onNavigate: (String) -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var positionMs by remember(song.uriString) { mutableLongStateOf(positionProvider().coerceAtLeast(0L)) }
    var durationMs by remember(song.uriString) { mutableLongStateOf(durationProvider().coerceAtLeast(0L)) }
    var moreOpen by remember { mutableStateOf(false) }
    var sleepTimerDialog by remember { mutableStateOf(false) }
    var detailDialog by remember { mutableStateOf(false) }
    var addToPlaylistDialog by remember { mutableStateOf(false) }

    LaunchedEffect(playing, song.uriString) {
        while (true) {
            positionMs = positionProvider().coerceAtLeast(0L)
            val latestDuration = durationProvider().coerceAtLeast(0L)
            if (latestDuration > 0L) durationMs = latestDuration
            if (!playing) break
            delay(350L)
        }
    }

    val safeDuration = durationMs.coerceAtLeast(1L)
    val sliderValue = (positionMs.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)
    val remainingMs = (durationMs - positionMs).coerceAtLeast(0L)
    val repeatLabel = when (repeatMode) {
        androidx.media3.common.Player.REPEAT_MODE_ONE -> "1"
        androidx.media3.common.Player.REPEAT_MODE_ALL -> "ALL"
        else -> "OFF"
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        LocalAccentColor.current.copy(alpha = .82f),
                        Color(0xFF20262C),
                        Color(0xFF08090B),
                        Color(0xFF050607)
                    )
                )
            )
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 20.dp)
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onBack) {
                    Icon(Icons.Default.KeyboardArrowDown, "Close player", tint = Color.White)
                }
                Spacer(Modifier.weight(1f))
                Text(
                    "NOW PLAYING",
                    color = Color.White.copy(alpha = .72f),
                    fontSize = 11.sp,
                    letterSpacing = 1.4.sp
                )
                Spacer(Modifier.weight(1f))
                Box {
                    IconButton({ moreOpen = true }) {
                        Icon(Icons.Default.MoreVert, "More", tint = Color.White)
                    }
                    DropdownMenu(
                        expanded = moreOpen,
                        onDismissRequest = { moreOpen = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text(if (sleepTimerMinutes == null) "スリープタイマー" else "スリープタイマー（${sleepTimerMinutes}分）") },
                            leadingIcon = { Icon(Icons.Default.Timer, null) },
                            onClick = { moreOpen = false; sleepTimerDialog = true }
                        )
                        DropdownMenuItem(
                            text = { Text("アーティスト") },
                            leadingIcon = { Icon(Icons.Default.Person, null) },
                            onClick = { moreOpen = false; onBack(); onNavigate("Artist::${song.artist.ifBlank { "Unknown Artist" }}") }
                        )
                        DropdownMenuItem(
                            text = { Text("アルバム") },
                            leadingIcon = { Icon(Icons.Default.Album, null) },
                            onClick = { moreOpen = false; onBack(); onNavigate("Album::${song.album.ifBlank { "Unknown Album" }}") }
                        )
                        DropdownMenuItem(
                            text = { Text("共有") },
                            leadingIcon = { Icon(Icons.Default.Share, null) },
                            onClick = {
                                moreOpen = false
                                val sendIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(android.content.Intent.EXTRA_TEXT, "${song.title} — ${song.artist}")
                                }
                                context.startActivity(android.content.Intent.createChooser(sendIntent, "共有"))
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("ミュージック情報を編集") },
                            leadingIcon = { Icon(Icons.Default.Edit, null) },
                            onClick = { moreOpen = false; onEditInfo() }
                        )
                        DropdownMenuItem(
                            text = { Text("詳細情報") },
                            leadingIcon = { Icon(Icons.Default.Info, null) },
                            onClick = { moreOpen = false; detailDialog = true }
                        )
                    }
                }
            }

            if (sleepTimerDialog) {
                AlertDialog(
                    onDismissRequest = { sleepTimerDialog = false },
                    title = { Text("スリープタイマー") },
                    text = {
                        Column {
                            listOf(null, 15, 30, 60, 90).forEach { minutes ->
                                val label = if (minutes == null) "オフ" else "${minutes}分後"
                                Text(label, modifier = Modifier.fillMaxWidth().clickable { onSetSleepTimer(minutes); sleepTimerDialog = false }.padding(vertical = 12.dp), color = if (minutes == sleepTimerMinutes) LocalAccentColor.current else Color.Unspecified)
                            }
                        }
                    },
                    confirmButton = { TextButton(onClick = { sleepTimerDialog = false }) { Text("閉じる") } }
                )
            }

            if (addToPlaylistDialog) {
                AlertDialog(
                    onDismissRequest = { addToPlaylistDialog = false },
                    title = { Text("プレイリストに追加") },
                    text = {
                        if (playlistNames.isEmpty()) {
                            Text("プレイリストがありません。先にプレイリストを作成してください。")
                        } else {
                            Column {
                                playlistNames.forEach { name ->
                                    TextButton(
                                        onClick = {
                                            onAddToPlaylist(name, song)
                                            addToPlaylistDialog = false
                                            android.widget.Toast.makeText(context, "「$name」に追加しました", android.widget.Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(Icons.Default.PlaylistAdd, null)
                                        Spacer(Modifier.width(10.dp))
                                        Text(name, modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = { addToPlaylistDialog = false }) { Text("閉じる") }
                    }
                )
            }

            if (detailDialog) {
                AlertDialog(
                    onDismissRequest = { detailDialog = false },
                    title = { Text("詳細情報") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("タイトル: ${song.title.ifBlank { "Unknown" }}")
                            Text("アーティスト: ${song.artist.ifBlank { "Unknown" }}")
                            Text("アルバム: ${song.album.ifBlank { "Unknown" }}")
                            Text("ジャンル: —")
                            Text("年: —")
                            Text("トラック: —")
                            Text("ディスク: —")
                            Text("URI: ${song.uriString}", fontSize = 11.sp)
                        }
                    },
                    confirmButton = { TextButton(onClick = { detailDialog = false }) { Text("閉じる") } }
                )
            }

            Spacer(Modifier.height(4.dp))

            Box(
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                AlbumArt(song = song, size = 300.dp)
            }

            Spacer(Modifier.height(12.dp))

            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { addToPlaylistDialog = true },
                    enabled = playlistNames.isNotEmpty(),
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(
                        Icons.Default.Add,
                        "プレイリストに追加",
                        tint = if (playlistNames.isNotEmpty()) Color.White.copy(alpha = .9f) else Color.White.copy(alpha = .3f),
                        modifier = Modifier.size(27.dp)
                    )
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        song.title.ifBlank { "Unknown title" },
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1
                    )
                    Spacer(Modifier.height(2.dp))
                    Text(
                        song.artist.ifBlank { "Unknown Artist" },
                        color = LocalAccentColor.current,
                        fontSize = 15.sp,
                        maxLines = 1
                    )
                    Text(
                        song.album.ifBlank { "Unknown Album" },
                        color = Color(0xFFB4BAC0),
                        fontSize = 13.sp,
                        maxLines = 1
                    )
                }
                IconButton(onToggleFavorite, modifier = Modifier.size(44.dp)) {
                    Icon(
                        if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        "Favorite",
                        tint = if (isFavorite) LocalAccentColor.current else Color.White.copy(alpha = .88f),
                        modifier = Modifier.size(27.dp)
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            Slider(
                value = sliderValue,
                onValueChange = { fraction ->
                    positionMs = (safeDuration * fraction).toLong().coerceIn(0L, safeDuration)
                },
                onValueChangeFinished = {
                    onSeekTo(positionMs.coerceIn(0L, safeDuration))
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp),
                colors = SliderDefaults.colors(
                    thumbColor = LocalAccentColor.current,
                    activeTrackColor = LocalAccentColor.current,
                    inactiveTrackColor = Color.White.copy(alpha = .24f)
                )
            )

            Row(Modifier.fillMaxWidth()) {
                Text(formatDuration(positionMs), color = Color(0xFFB0B6BC), fontSize = 11.sp)
                Spacer(Modifier.weight(1f))
                Text("-${formatDuration(remainingMs)}", color = Color(0xFFB0B6BC), fontSize = 11.sp)
            }

            Spacer(Modifier.height(6.dp))

            Row(
                Modifier
                    .fillMaxWidth()
                    .height(76.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                IconButton(onToggleShuffle) {
                    Icon(
                        Icons.Default.Shuffle,
                        "Shuffle",
                        tint = if (shuffleEnabled) LocalAccentColor.current else Color.White.copy(alpha = .82f)
                    )
                }
                IconButton(onPrevious, modifier = Modifier.size(52.dp)) {
                    Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White, modifier = Modifier.size(31.dp))
                }
                FilledIconButton(
                    onClick = onPlay,
                    modifier = Modifier.size(72.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = LocalAccentColor.current,
                        contentColor = Color(0xFF111316)
                    )
                ) {
                    Icon(
                        if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                        "Play or pause",
                        modifier = Modifier.size(37.dp)
                    )
                }
                IconButton(onNext, modifier = Modifier.size(52.dp)) {
                    Icon(Icons.Default.SkipNext, "Next", tint = Color.White, modifier = Modifier.size(31.dp))
                }
                IconButton(onCycleRepeat) {
                    Icon(
                        if (repeatMode == androidx.media3.common.Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        "Repeat $repeatLabel",
                        tint = if (repeatMode != androidx.media3.common.Player.REPEAT_MODE_OFF) LocalAccentColor.current else Color.White.copy(alpha = .82f)
                    )
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .height(26.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    buildString {
                        if (shuffleEnabled) append("SHUFFLE")
                        if (shuffleEnabled && repeatMode != androidx.media3.common.Player.REPEAT_MODE_OFF) append("  •  ")
                        if (repeatMode != androidx.media3.common.Player.REPEAT_MODE_OFF) append("REPEAT $repeatLabel")
                        if (isEmpty()) append("NOW PLAYING")
                    },
                    color = Color.White.copy(alpha = .48f),
                    fontSize = 10.sp,
                    letterSpacing = 1.0.sp
                )
            }

            Spacer(Modifier.height(4.dp))
        }
    }
}

@Composable
private fun EditMusicInfoScreen(
    song: MusicSong,
    onBack: () -> Unit,
    onSave: (MusicSong) -> Unit
) {
    var title by remember(song.uriString) { mutableStateOf(song.title) }
    var artist by remember(song.uriString) { mutableStateOf(song.artist) }
    var album by remember(song.uriString) { mutableStateOf(song.album) }
    var disc by remember(song.uriString) { mutableStateOf("1") }
    var track by remember(song.uriString) { mutableStateOf("") }
    var year by remember(song.uriString) { mutableStateOf("") }
    var genre by remember(song.uriString) { mutableStateOf("") }
    var artworkSet by remember(song.uriString) { mutableStateOf(false) }
    var selectedImageUri by remember(song.uriString) { mutableStateOf<Uri?>(null) }
    var cropScreen by remember(song.uriString) { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("pixelmusic_artwork", android.content.Context.MODE_PRIVATE) }
    var customArtworkPath by remember(song.uriString) { mutableStateOf(prefs.getString("art_${song.id}", null)) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedImageUri = uri
            artworkSet = true
            cropScreen = true
        }
    }

    if (cropScreen && selectedImageUri != null) {
        CropArtworkScreen(
            uri = selectedImageUri!!,
            onBack = { cropScreen = false },
            onDone = { cropped ->
                customArtworkPath = cropped
                prefs.edit().putString("art_${song.id}", cropped).apply()
                cropScreen = false
                artworkSet = true
            }
        )
        return
    }

    Box(
        Modifier.fillMaxSize().background(Color(0xFF08090B))
    ) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(
                Modifier.fillMaxWidth().height(64.dp).background(Color(0xFF0A0B0D)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onBack) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
                }
                Text("ミュージック情報を編集", color = Color.White, fontSize = 19.sp)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = {
                    onSave(song.copy(title = title, artist = artist, album = album))
                }) {
                    Text("保存", color = LocalAccentColor.current)
                }
            }

            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(20.dp)
            ) {
                item {
                    Row(
                        Modifier.fillMaxWidth().padding(bottom = 22.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AlbumArt(song = song, size = 108.dp)
                        Column(Modifier.padding(start = 18.dp)) {
                            Text("アートワーク", color = Color.White, fontSize = 17.sp)
                            Spacer(Modifier.height(10.dp))
                            Row {
                                OutlinedButton(onClick = { imagePicker.launch("image/*") }) {
                                    Text("画像を設定")
                                }
                                Spacer(Modifier.width(8.dp))
                                OutlinedButton(onClick = {
                                    artworkSet = false
                                    customArtworkPath = null
                                    prefs.edit().remove("art_${song.id}").apply()
                                }) {
                                    Text("画像を削除")
                                }
                            }
                            if (artworkSet) {
                                Text(
                                    if (selectedImageUri != null) "選択した画像を使用します。" else "画像が設定されています。",
                                    color = Color(0xFF858C93),
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(top = 7.dp)
                                )
                            }
                        }
                    }
                }
                item { EditField("タイトル", title) { title = it } }
                item { EditField("アーティスト", artist) { artist = it } }
                item { EditField("アルバム", album) { album = it } }
                item { EditField("ディスク", disc) { disc = it } }
                item { EditField("トラック", track) { track = it } }
                item { EditField("年", year) { year = it } }
                item { EditField("ジャンル", genre) { genre = it } }
                item {
                    Text(
                        "※ v0.14では編集画面の骨格を実装しています。保存処理と画像トリミングは次の段階で接続します。",
                        color = Color(0xFF777D83),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 18.dp, bottom = 20.dp)
                    )
                }
            }
        }
    }
}


@Composable
private fun CropArtworkScreen(
    uri: Uri,
    onBack: () -> Unit,
    onDone: (String) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var bitmap by remember(uri) { mutableStateOf<android.graphics.Bitmap?>(null) }
    var zoom by remember(uri) { mutableFloatStateOf(1f) }
    LaunchedEffect(uri) {
        bitmap = withContext(Dispatchers.IO) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }.getOrNull()
        }
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF08090B))) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(Modifier.fillMaxWidth().height(64.dp).background(Color(0xFF0A0B0D)), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
                Text("トリミング（フレーミング）", color = Color.White, fontSize = 18.sp)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = {
                    val source = bitmap
                    if (source != null) {
                        val side = minOf(source.width, source.height)
                        val left = (source.width - side) / 2
                        val top = (source.height - side) / 2
                        val square = Bitmap.createBitmap(source, left, top, side, side)
                        val file = File(context.filesDir, "artwork_${uri.toString().hashCode().absoluteValue}.jpg")
                        file.outputStream().use { out -> square.compress(Bitmap.CompressFormat.JPEG, 94, out) }
                        onDone(file.absolutePath)
                    }
                }) { Text("完了", color = LocalAccentColor.current) }
            }
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Box(Modifier.size(310.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF15181C)), contentAlignment = Alignment.Center) {
                    bitmap?.let {
                        Image(
                            bitmap = it.asImageBitmap(),
                            contentDescription = "Selected artwork",
                            modifier = Modifier.fillMaxSize().graphicsLayer { scaleX = zoom; scaleY = zoom },
                            contentScale = ContentScale.Crop
                        )
                    } ?: Text("画像を読み込み中…", color = Color(0xFF858C93))
                    Box(Modifier.size(310.dp).border(2.dp, Color.White.copy(alpha = .85f), RoundedCornerShape(8.dp)))
                }
            }
            Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 18.dp)) {
                Text("フレーミング", color = Color.White, fontSize = 15.sp)
                Slider(value = zoom, onValueChange = { zoom = it }, valueRange = 1f..2.2f, colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White, inactiveTrackColor = Color.White.copy(alpha = .25f)))
                Text("画像を拡大してジャケットの見え方を調整できます。", color = Color(0xFF858C93), fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun EditField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            focusedBorderColor = LocalAccentColor.current,
            unfocusedBorderColor = Color(0xFF4B5157),
            focusedLabelColor = LocalAccentColor.current,
            unfocusedLabelColor = Color(0xFF858C93),
            cursorColor = LocalAccentColor.current
        )
    )
}

private fun formatDuration(milliseconds: Long): String {
    val totalSeconds = (milliseconds / 1000L).coerceAtLeast(0L)
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return "%d:%02d".format(minutes, seconds)
}
