package com.example.pixelmusic

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Foreground media playback service.
 * - MediaSession drives the system media notification (QS / lock screen)
 * - Explicit PARTIAL_WAKE_LOCK while play is requested (OEM-safe)
 * - START_STICKY so the process can be restarted if the system reclaims memory
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {

    companion object {
        const val CHANNEL_ID = "pixelmusic_playback"
        const val NOTIFICATION_ID = 0x504D01 // 'PM' + 1
    }

    private var mediaSession: MediaSession? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var playerListener: Player.Listener? = null

    override fun onCreate() {
        super.onCreate()
        ensureNotificationChannel()

        val player: ExoPlayer = PlayerHolder.getOrCreate(this)

        val sessionActivity = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_NEW_TASK
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(sessionActivity)
            .build()

        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) = syncWakeLock()
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) = syncWakeLock()
            override fun onPlaybackStateChanged(playbackState: Int) = syncWakeLock()
        }
        playerListener = listener
        player.addListener(listener)
        syncWakeLock()

        // If we were started via startForegroundService, post a notification
        // immediately so Android 12+ does not ANR/stop us within ~5s.
        promoteToForegroundPlaceholder()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        // Always sticky: if the process is reclaimed, Android restarts the service.
        return START_STICKY
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    /**
     * Force the Media3 notification pipeline to keep us in the foreground while
     * the user wants audio to continue.
     */
    override fun onUpdateNotification(session: MediaSession, startInForegroundRequired: Boolean) {
        val player = session.player
        val wantForeground = player.playWhenReady &&
            player.playbackState != Player.STATE_IDLE &&
            player.playbackState != Player.STATE_ENDED
        super.onUpdateNotification(session, startInForegroundRequired || wantForeground)
        syncWakeLock()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = PlayerHolder.get()
        // Keep playing after swipe-away from Recents.
        if (player == null || player.mediaItemCount == 0 ||
            (!player.isPlaying && !player.playWhenReady)
        ) {
            stopSelf()
        }
        // Do not call super — default Media3 behavior may pause playback.
    }

    override fun onDestroy() {
        val player = PlayerHolder.get()
        playerListener?.let { listener ->
            player?.removeListener(listener)
        }
        playerListener = null
        releaseWakeLock()
        mediaSession?.run {
            release()
            mediaSession = null
        }
        super.onDestroy()
    }

    private fun syncWakeLock() {
        val player = PlayerHolder.get()
        val need = player != null && player.playWhenReady &&
            player.playbackState != Player.STATE_ENDED &&
            player.mediaItemCount > 0
        if (need) acquireWakeLock() else releaseWakeLock()
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val lock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "PixelMusic:Playback"
        )
        lock.setReferenceCounted(false)
        lock.acquire(4 * 60 * 60 * 1000L) // up to 4 hours; refreshed while playing
        wakeLock = lock
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: RuntimeException) {
            // ignore
        }
        wakeLock = null
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val manager = getSystemService(NotificationManager::class.java) ?: return
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "再生中",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "音楽のバックグラウンド再生"
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    /**
     * Shows a minimal foreground notification immediately so Android 12+ does not
     * kill the service for failing to call startForeground in time. Media3 will
     * replace this with the rich media notification once playback metadata is ready.
     */
    private fun promoteToForegroundPlaceholder() {
        val player = PlayerHolder.get()
        if (player == null) return
        // Only needed when we were started via startForegroundService and Media3
        // has not posted its notification yet.
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Pixel Music")
            .setContentText("再生準備中…")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .setSilent(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
        try {
            startForeground(NOTIFICATION_ID, notification)
        } catch (_: Exception) {
            // Media3 may already own the foreground slot — safe to ignore.
        }
    }
}
